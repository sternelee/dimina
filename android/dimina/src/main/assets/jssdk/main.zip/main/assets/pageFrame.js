const scriptRel = /* @__PURE__ */ function detectScriptRel() {
  const relList = typeof document !== "undefined" && document.createElement("link").relList;
  return relList && relList.supports && relList.supports("modulepreload") ? "modulepreload" : "preload";
}();
const assetsURL = function(dep) {
  return "/" + dep;
};
const seen = {};
const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (deps && deps.length > 0) {
    let allSettled2 = function(promises) {
      return Promise.all(
        promises.map(
          (p2) => Promise.resolve(p2).then(
            (value) => ({ status: "fulfilled", value }),
            (reason) => ({ status: "rejected", reason })
          )
        )
      );
    };
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = (cspNonceMeta == null ? void 0 : cspNonceMeta.nonce) || (cspNonceMeta == null ? void 0 : cspNonceMeta.getAttribute("nonce"));
    promise = allSettled2(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};
new Set("0123456789");
function isFunction$3(value) {
  return typeof value === "function";
}
(() => {
  if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) {
    return true;
  } else {
    return false;
  }
})();
const JSModules = {};
const MODULES_STATUS_UNLOAD = 1;
const MODULES_STATUS_LOADED = 2;
function modDefine(id, factory) {
  if (!JSModules[id]) {
    JSModules[id] = {
      factory,
      status: MODULES_STATUS_UNLOAD,
      exports: void 0
    };
  }
}
const modRequire = function(id, callback2, errorCallback) {
  if (typeof id !== "string") {
    throw new TypeError("require args must be a string");
  }
  const mod = JSModules[id];
  if (!mod) {
    throw new Error(`module ${id} not found`);
  }
  if (mod.status === MODULES_STATUS_UNLOAD) {
    mod.status = MODULES_STATUS_LOADED;
    const module = {
      exports: {}
    };
    let res;
    try {
      if (mod.factory) {
        res = mod.factory.call(null, modRequire, module, module.exports);
      }
    } catch (e) {
      mod.status = MODULES_STATUS_UNLOAD;
      const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
      console.error(`require ${id} error: ${em}`);
      if (isFunction$3(errorCallback)) {
        errorCallback({ mod: id, errMsg: e.message });
      }
    }
    mod.exports = module.exports === void 0 ? res : module.exports;
  }
  if (isFunction$3(callback2)) {
    callback2(mod.exports);
  }
  return mod.exports;
};
modRequire.async = async (id) => {
  return new Promise((resolve2, reject) => {
    try {
      resolve2(modRequire(id));
    } catch (e) {
      reject(new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
    }
  });
};
if (!window.DiminaRenderBridge) {
  window.DiminaRenderBridge = {};
}
const isObject$1 = (value) => {
  const type2 = typeof value;
  return value !== null && (type2 === "object" || type2 === "function");
};
const disallowedKeys = /* @__PURE__ */ new Set([
  "__proto__",
  "prototype",
  "constructor"
]);
const digits = new Set("0123456789");
function getPathSegments(path) {
  const parts = [];
  let currentSegment = "";
  let currentPart = "start";
  let isIgnoring = false;
  for (const character of path) {
    switch (character) {
      case "\\": {
        if (currentPart === "index") {
          throw new Error("Invalid character in an index");
        }
        if (currentPart === "indexEnd") {
          throw new Error("Invalid character after an index");
        }
        if (isIgnoring) {
          currentSegment += character;
        }
        currentPart = "property";
        isIgnoring = !isIgnoring;
        break;
      }
      case ".": {
        if (currentPart === "index") {
          throw new Error("Invalid character in an index");
        }
        if (currentPart === "indexEnd") {
          currentPart = "property";
          break;
        }
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += character;
          break;
        }
        if (disallowedKeys.has(currentSegment)) {
          return [];
        }
        parts.push(currentSegment);
        currentSegment = "";
        currentPart = "property";
        break;
      }
      case "[": {
        if (currentPart === "index") {
          throw new Error("Invalid character in an index");
        }
        if (currentPart === "indexEnd") {
          currentPart = "index";
          break;
        }
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += character;
          break;
        }
        if (currentPart === "property") {
          if (disallowedKeys.has(currentSegment)) {
            return [];
          }
          parts.push(currentSegment);
          currentSegment = "";
        }
        currentPart = "index";
        break;
      }
      case "]": {
        if (currentPart === "index") {
          parts.push(Number.parseInt(currentSegment, 10));
          currentSegment = "";
          currentPart = "indexEnd";
          break;
        }
        if (currentPart === "indexEnd") {
          throw new Error("Invalid character after an index");
        }
      }
      default: {
        if (currentPart === "index" && !digits.has(character)) {
          throw new Error("Invalid character in an index");
        }
        if (currentPart === "indexEnd") {
          throw new Error("Invalid character after an index");
        }
        if (currentPart === "start") {
          currentPart = "property";
        }
        if (isIgnoring) {
          isIgnoring = false;
          currentSegment += "\\";
        }
        currentSegment += character;
      }
    }
  }
  if (isIgnoring) {
    currentSegment += "\\";
  }
  switch (currentPart) {
    case "property": {
      if (disallowedKeys.has(currentSegment)) {
        return [];
      }
      parts.push(currentSegment);
      break;
    }
    case "index": {
      throw new Error("Index was not closed");
    }
    case "start": {
      parts.push("");
      break;
    }
  }
  return parts;
}
function isStringIndex(object, key) {
  if (typeof key !== "number" && Array.isArray(object)) {
    const index2 = Number.parseInt(key, 10);
    return Number.isInteger(index2) && object[index2] === object[key];
  }
  return false;
}
function assertNotStringIndex(object, key) {
  if (isStringIndex(object, key)) {
    throw new Error("Cannot use string index");
  }
}
function setProperty(object, path, value) {
  if (!isObject$1(object) || typeof path !== "string") {
    return object;
  }
  const root = object;
  const pathArray = getPathSegments(path);
  for (let index2 = 0; index2 < pathArray.length; index2++) {
    const key = pathArray[index2];
    assertNotStringIndex(object, key);
    if (index2 === pathArray.length - 1) {
      object[key] = value;
    } else if (!isObject$1(object[key])) {
      object[key] = typeof pathArray[index2 + 1] === "number" ? [] : {};
    }
    object = object[key];
  }
  return root;
}
function isFunction$2(value) {
  return typeof value === "function";
}
function set(data, path, value) {
  setProperty(data, path, value);
}
function uuid() {
  return Math.random().toString(36).slice(2, 7);
}
function toCamelCase$1(attr) {
  return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
    return group.toUpperCase();
  });
}
function getDataAttributes$1(attrs, handler) {
  if (!attrs) {
    return;
  }
  const result = {};
  for (const attr in attrs) {
    if (!attr.startsWith("data-")) {
      continue;
    }
    const theAfter = attr.replace(/^data-/, "");
    const transAttr = toCamelCase$1(theAfter);
    result[transAttr] = handler(attrs[attr]);
  }
  return result;
}
const isAndroid$1 = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
const isIOS$1 = typeof navigator !== "undefined" && /iPad|iPhone|iPod/.test(navigator.userAgent);
(() => {
  if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) {
    return true;
  } else {
    return false;
  }
})();
class Callback {
  constructor() {
    this.callbacks = {};
  }
  store(callback2, keep) {
    if (keep) {
      for (const [k, v] of Object.entries(this.callbacks)) {
        if (v.callback === callback2) {
          return k;
        }
      }
    }
    const id = uuid();
    this.callbacks[id] = { callback: callback2, keep };
    return id;
  }
  /**
   * [Container] triggerCallback -> [Service] invoke
   * @param {*} id
   * @param {*} args
   */
  invoke(id, args) {
    if (id === void 0) {
      return;
    }
    const obj = this.callbacks[id];
    if (obj && isFunction$2(obj.callback)) {
      obj.callback(args);
      if (!obj.keep) {
        delete this.callbacks[id];
      }
    }
  }
  remove(id) {
    if (id) {
      Object.keys(this.callbacks).forEach((k) => {
        if (id === k) {
          delete this.callbacks[k];
        }
      });
    } else {
      Object.entries(this.callbacks).forEach(([k, v]) => {
        if (v.keep) {
          delete this.callbacks[k];
        }
      });
    }
  }
}
const callback = new Callback();
const TYPE_MAPS = {
  s: String,
  n: Number,
  b: Boolean,
  o: Object,
  a: Array,
  f: Function
};
class Module {
  constructor(moduleInfo) {
    this.moduleInfo = moduleInfo;
  }
  setInitialData(props) {
    this.props = this.unSerializeProps(props);
  }
  unSerializeProps(properties) {
    if (!properties) {
      return;
    }
    for (const key in properties) {
      const types = properties[key].type.map((item) => this.convertStringToType(item));
      properties[key].type = types.length === 1 ? types[0] : types;
    }
    return properties;
  }
  /**
   * 将字符串转换成实际类型
   * @param {*} type
   */
  convertStringToType(type2) {
    if (type2 === null) {
      return null;
    }
    const result = TYPE_MAPS[type2];
    if (!result) {
      console.warn(`[Render] unknown props type ${type2}`);
    }
    return result;
  }
}
function mitt(n) {
  return { all: n = n || /* @__PURE__ */ new Map(), on: function(t, e) {
    var i = n.get(t);
    i ? i.push(e) : n.set(t, [e]);
  }, off: function(t, e) {
    var i = n.get(t);
    i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
  }, emit: function(t, e) {
    var i = n.get(t);
    i && i.slice().map(function(n2) {
      n2(e);
    }), (i = n.get("*")) && i.slice().map(function(n2) {
      n2(t, e);
    });
  } };
}
class Message {
  constructor() {
    this.event = mitt();
    this.init();
  }
  init() {
    window.DiminaRenderBridge.onMessage = (msg) => {
      console.log("[Render] receive msg: ", msg);
      const { type: type2, body } = msg;
      this.event.emit(type2, body);
    };
  }
  // 向渲染层注册消息监听
  on(type2, callback2) {
    this.event.on(type2, callback2);
  }
  // 渲染层经过容器层中转向逻辑层发送消息
  send(msg) {
    window.DiminaRenderBridge.publish(JSON.stringify(msg));
  }
  // 渲染层向容器层发送消息
  invoke(msg) {
    if (isAndroid$1 || isIOS$1) {
      Message.prototype.invoke = function(msg2) {
        window.DiminaRenderBridge.invoke(JSON.stringify(msg2));
      };
    } else {
      Message.prototype.invoke = function(msg2) {
        window.DiminaRenderBridge.invoke(msg2);
      };
    }
    return this.invoke(msg);
  }
  off(type2) {
    this.event.off(type2);
  }
  wait(eventName) {
    return new Promise((resolve2) => {
      this.on(eventName, (msg) => {
        resolve2(msg.data);
        this.off(eventName);
      });
    });
  }
}
const message = new Message();
class Loader {
  constructor() {
    this.staticModules = {};
  }
  loadResource(opts) {
    const { bridgeId, appId, pagePath, root } = opts;
    const filename = pagePath.replace(/\//g, "_");
    const appStyleResourcePath = `/${appId}/main/app.css`;
    const styleResourcePath = `/${appId}/${root}/${filename}.css`;
    const viewResourcePath = `/${appId}/${root}/${filename}.js`;
    Promise.allSettled([
      this.loadStyleFile(appStyleResourcePath),
      this.loadStyleFile(styleResourcePath),
      this.loadScriptFile(viewResourcePath)
    ]).then(
      (results) => {
        window.modRequire(pagePath);
        message.invoke({
          type: "renderResourceLoaded",
          target: "service",
          body: {
            bridgeId
          }
        });
        const errors = results.filter((result) => result.status === "rejected").map((result) => result.reason);
        if (errors.length) {
          console.error("[Render] 资源加载失败:", errors);
        }
      }
    );
  }
  loadStyleFile(path) {
    return new Promise((resolve2, reject) => {
      const style = document.createElement("link");
      style.rel = "stylesheet";
      style.href = path;
      style.onload = () => {
        resolve2();
      };
      style.onerror = () => {
        reject(new Error(`样式文件加载失败: ${path}`));
      };
      document.head.append(style);
    });
  }
  loadScriptFile(path) {
    return new Promise((resolve2, reject) => {
      const script = document.createElement("script");
      script.src = path;
      script.onload = () => {
        resolve2();
      };
      script.onerror = () => {
        reject(new Error(`脚本文件加载失败: ${path}`));
      };
      document.head.append(script);
    });
  }
  /**
   * 创建渲染层映射实例
   * window.Module -> create
   * @param {{path: string, scopeId: string, usingComponents: object, render: Function}} moduleInfo
   */
  createModule(moduleInfo) {
    const { path, usingComponents } = moduleInfo;
    if (this.staticModules[path]) {
      return;
    }
    this.staticModules[path] = new Module(moduleInfo);
    for (const componentPath of Object.values(usingComponents)) {
      window.modRequire(componentPath);
    }
  }
  /**
   * serviceResourceLoaded && renderResourceLoaded ->
   * [Container]resourceLoaded -> [Service]resourceLoaded -> [Service]initialDataReady -> [Container]initialDataReady -> [Render]setInitialData
   * @param {*} initialData
   */
  setInitialData(initialData) {
    for (const [path, data] of Object.entries(initialData)) {
      if (!data) {
        continue;
      }
      const module = this.staticModules[path];
      if (!module) {
        continue;
      }
      module.setInitialData(data);
    }
  }
  getModuleByPath(path) {
    return this.staticModules[path];
  }
}
const loader = new Loader();
class Env {
  constructor() {
    this.init();
  }
  init() {
    window.Module = (moduleInfo) => loader.createModule(moduleInfo);
  }
}
const env = new Env();
/**
* @vue/shared v3.5.13
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function makeMap(str) {
  const map2 = /* @__PURE__ */ Object.create(null);
  for (const key of str.split(",")) map2[key] = 1;
  return (val) => val in map2;
}
const EMPTY_OBJ = {};
const EMPTY_ARR = [];
const NOOP = () => {
};
const NO = () => false;
const isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // uppercase letter
(key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
const isModelListener = (key) => key.startsWith("onUpdate:");
const extend = Object.assign;
const remove = (arr, el) => {
  const i = arr.indexOf(el);
  if (i > -1) {
    arr.splice(i, 1);
  }
};
const hasOwnProperty$1 = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
const isArray = Array.isArray;
const isMap = (val) => toTypeString(val) === "[object Map]";
const isSet = (val) => toTypeString(val) === "[object Set]";
const isFunction$1 = (val) => typeof val === "function";
const isString$1 = (val) => typeof val === "string";
const isSymbol = (val) => typeof val === "symbol";
const isObject = (val) => val !== null && typeof val === "object";
const isPromise = (val) => {
  return (isObject(val) || isFunction$1(val)) && isFunction$1(val.then) && isFunction$1(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const toRawType = (value) => {
  return toTypeString(value).slice(8, -1);
};
const isPlainObject = (val) => toTypeString(val) === "[object Object]";
const isIntegerKey = (key) => isString$1(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
const isReservedProp = /* @__PURE__ */ makeMap(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
);
const cacheStringFunction = (fn) => {
  const cache = /* @__PURE__ */ Object.create(null);
  return (str) => {
    const hit = cache[str];
    return hit || (cache[str] = fn(str));
  };
};
const camelizeRE = /-(\w)/g;
const camelize = cacheStringFunction(
  (str) => {
    return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : "");
  }
);
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction(
  (str) => str.replace(hyphenateRE, "-$1").toLowerCase()
);
const capitalize = cacheStringFunction((str) => {
  return str.charAt(0).toUpperCase() + str.slice(1);
});
const toHandlerKey = cacheStringFunction(
  (str) => {
    const s = str ? `on${capitalize(str)}` : ``;
    return s;
  }
);
const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
const invokeArrayFns = (fns, ...arg) => {
  for (let i = 0; i < fns.length; i++) {
    fns[i](...arg);
  }
};
const def = (obj, key, value, writable = false) => {
  Object.defineProperty(obj, key, {
    configurable: true,
    enumerable: false,
    writable,
    value
  });
};
const looseToNumber = (val) => {
  const n = parseFloat(val);
  return isNaN(n) ? val : n;
};
const toNumber = (val) => {
  const n = isString$1(val) ? Number(val) : NaN;
  return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = () => {
  return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
};
function normalizeStyle(value) {
  if (isArray(value)) {
    const res = {};
    for (let i = 0; i < value.length; i++) {
      const item = value[i];
      const normalized = isString$1(item) ? parseStringStyle(item) : normalizeStyle(item);
      if (normalized) {
        for (const key in normalized) {
          res[key] = normalized[key];
        }
      }
    }
    return res;
  } else if (isString$1(value) || isObject(value)) {
    return value;
  }
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:([^]+)/;
const styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
  const ret = {};
  cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item) => {
    if (item) {
      const tmp = item.split(propertyDelimiterRE);
      tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
    }
  });
  return ret;
}
function normalizeClass(value) {
  let res = "";
  if (isString$1(value)) {
    res = value;
  } else if (isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const normalized = normalizeClass(value[i]);
      if (normalized) {
        res += normalized + " ";
      }
    }
  } else if (isObject(value)) {
    for (const name in value) {
      if (value[name]) {
        res += name + " ";
      }
    }
  }
  return res.trim();
}
function normalizeProps(props) {
  if (!props) return null;
  let { class: klass, style } = props;
  if (klass && !isString$1(klass)) {
    props.class = normalizeClass(klass);
  }
  if (style) {
    props.style = normalizeStyle(style);
  }
  return props;
}
const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
function includeBooleanAttr(value) {
  return !!value || value === "";
}
const isRef$1 = (val) => {
  return !!(val && val["__v_isRef"] === true);
};
const toDisplayString = (val) => {
  return isString$1(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString || !isFunction$1(val.toString)) ? isRef$1(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
};
const replacer = (_key, val) => {
  if (isRef$1(val)) {
    return replacer(_key, val.value);
  } else if (isMap(val)) {
    return {
      [`Map(${val.size})`]: [...val.entries()].reduce(
        (entries, [key, val2], i) => {
          entries[stringifySymbol(key, i) + " =>"] = val2;
          return entries;
        },
        {}
      )
    };
  } else if (isSet(val)) {
    return {
      [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v))
    };
  } else if (isSymbol(val)) {
    return stringifySymbol(val);
  } else if (isObject(val) && !isArray(val) && !isPlainObject(val)) {
    return String(val);
  }
  return val;
};
const stringifySymbol = (v, i = "") => {
  var _a;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v
  );
};
let activeEffectScope;
class EffectScope {
  constructor(detached = false) {
    this.detached = detached;
    this._active = true;
    this.effects = [];
    this.cleanups = [];
    this._isPaused = false;
    this.parent = activeEffectScope;
    if (!detached && activeEffectScope) {
      this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(
        this
      ) - 1;
    }
  }
  get active() {
    return this._active;
  }
  pause() {
    if (this._active) {
      this._isPaused = true;
      let i, l;
      if (this.scopes) {
        for (i = 0, l = this.scopes.length; i < l; i++) {
          this.scopes[i].pause();
        }
      }
      for (i = 0, l = this.effects.length; i < l; i++) {
        this.effects[i].pause();
      }
    }
  }
  /**
   * Resumes the effect scope, including all child scopes and effects.
   */
  resume() {
    if (this._active) {
      if (this._isPaused) {
        this._isPaused = false;
        let i, l;
        if (this.scopes) {
          for (i = 0, l = this.scopes.length; i < l; i++) {
            this.scopes[i].resume();
          }
        }
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].resume();
        }
      }
    }
  }
  run(fn) {
    if (this._active) {
      const currentEffectScope = activeEffectScope;
      try {
        activeEffectScope = this;
        return fn();
      } finally {
        activeEffectScope = currentEffectScope;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    activeEffectScope = this;
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    activeEffectScope = this.parent;
  }
  stop(fromParent) {
    if (this._active) {
      this._active = false;
      let i, l;
      for (i = 0, l = this.effects.length; i < l; i++) {
        this.effects[i].stop();
      }
      this.effects.length = 0;
      for (i = 0, l = this.cleanups.length; i < l; i++) {
        this.cleanups[i]();
      }
      this.cleanups.length = 0;
      if (this.scopes) {
        for (i = 0, l = this.scopes.length; i < l; i++) {
          this.scopes[i].stop(true);
        }
        this.scopes.length = 0;
      }
      if (!this.detached && this.parent && !fromParent) {
        const last = this.parent.scopes.pop();
        if (last && last !== this) {
          this.parent.scopes[this.index] = last;
          last.index = this.index;
        }
      }
      this.parent = void 0;
    }
  }
}
function getCurrentScope() {
  return activeEffectScope;
}
let activeSub;
const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
class ReactiveEffect {
  constructor(fn) {
    this.fn = fn;
    this.deps = void 0;
    this.depsTail = void 0;
    this.flags = 1 | 4;
    this.next = void 0;
    this.cleanup = void 0;
    this.scheduler = void 0;
    if (activeEffectScope && activeEffectScope.active) {
      activeEffectScope.effects.push(this);
    }
  }
  pause() {
    this.flags |= 64;
  }
  resume() {
    if (this.flags & 64) {
      this.flags &= -65;
      if (pausedQueueEffects.has(this)) {
        pausedQueueEffects.delete(this);
        this.trigger();
      }
    }
  }
  /**
   * @internal
   */
  notify() {
    if (this.flags & 2 && !(this.flags & 32)) {
      return;
    }
    if (!(this.flags & 8)) {
      batch(this);
    }
  }
  run() {
    if (!(this.flags & 1)) {
      return this.fn();
    }
    this.flags |= 2;
    cleanupEffect(this);
    prepareDeps(this);
    const prevEffect = activeSub;
    const prevShouldTrack = shouldTrack;
    activeSub = this;
    shouldTrack = true;
    try {
      return this.fn();
    } finally {
      cleanupDeps(this);
      activeSub = prevEffect;
      shouldTrack = prevShouldTrack;
      this.flags &= -3;
    }
  }
  stop() {
    if (this.flags & 1) {
      for (let link = this.deps; link; link = link.nextDep) {
        removeSub(link);
      }
      this.deps = this.depsTail = void 0;
      cleanupEffect(this);
      this.onStop && this.onStop();
      this.flags &= -2;
    }
  }
  trigger() {
    if (this.flags & 64) {
      pausedQueueEffects.add(this);
    } else if (this.scheduler) {
      this.scheduler();
    } else {
      this.runIfDirty();
    }
  }
  /**
   * @internal
   */
  runIfDirty() {
    if (isDirty(this)) {
      this.run();
    }
  }
  get dirty() {
    return isDirty(this);
  }
}
let batchDepth = 0;
let batchedSub;
let batchedComputed;
function batch(sub, isComputed = false) {
  sub.flags |= 8;
  if (isComputed) {
    sub.next = batchedComputed;
    batchedComputed = sub;
    return;
  }
  sub.next = batchedSub;
  batchedSub = sub;
}
function startBatch() {
  batchDepth++;
}
function endBatch() {
  if (--batchDepth > 0) {
    return;
  }
  if (batchedComputed) {
    let e = batchedComputed;
    batchedComputed = void 0;
    while (e) {
      const next = e.next;
      e.next = void 0;
      e.flags &= -9;
      e = next;
    }
  }
  let error;
  while (batchedSub) {
    let e = batchedSub;
    batchedSub = void 0;
    while (e) {
      const next = e.next;
      e.next = void 0;
      e.flags &= -9;
      if (e.flags & 1) {
        try {
          ;
          e.trigger();
        } catch (err) {
          if (!error) error = err;
        }
      }
      e = next;
    }
  }
  if (error) throw error;
}
function prepareDeps(sub) {
  for (let link = sub.deps; link; link = link.nextDep) {
    link.version = -1;
    link.prevActiveLink = link.dep.activeLink;
    link.dep.activeLink = link;
  }
}
function cleanupDeps(sub) {
  let head;
  let tail = sub.depsTail;
  let link = tail;
  while (link) {
    const prev = link.prevDep;
    if (link.version === -1) {
      if (link === tail) tail = prev;
      removeSub(link);
      removeDep(link);
    } else {
      head = link;
    }
    link.dep.activeLink = link.prevActiveLink;
    link.prevActiveLink = void 0;
    link = prev;
  }
  sub.deps = head;
  sub.depsTail = tail;
}
function isDirty(sub) {
  for (let link = sub.deps; link; link = link.nextDep) {
    if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) {
      return true;
    }
  }
  if (sub._dirty) {
    return true;
  }
  return false;
}
function refreshComputed(computed2) {
  if (computed2.flags & 4 && !(computed2.flags & 16)) {
    return;
  }
  computed2.flags &= -17;
  if (computed2.globalVersion === globalVersion) {
    return;
  }
  computed2.globalVersion = globalVersion;
  const dep = computed2.dep;
  computed2.flags |= 2;
  if (dep.version > 0 && !computed2.isSSR && computed2.deps && !isDirty(computed2)) {
    computed2.flags &= -3;
    return;
  }
  const prevSub = activeSub;
  const prevShouldTrack = shouldTrack;
  activeSub = computed2;
  shouldTrack = true;
  try {
    prepareDeps(computed2);
    const value = computed2.fn(computed2._value);
    if (dep.version === 0 || hasChanged(value, computed2._value)) {
      computed2._value = value;
      dep.version++;
    }
  } catch (err) {
    dep.version++;
    throw err;
  } finally {
    activeSub = prevSub;
    shouldTrack = prevShouldTrack;
    cleanupDeps(computed2);
    computed2.flags &= -3;
  }
}
function removeSub(link, soft = false) {
  const { dep, prevSub, nextSub } = link;
  if (prevSub) {
    prevSub.nextSub = nextSub;
    link.prevSub = void 0;
  }
  if (nextSub) {
    nextSub.prevSub = prevSub;
    link.nextSub = void 0;
  }
  if (dep.subs === link) {
    dep.subs = prevSub;
    if (!prevSub && dep.computed) {
      dep.computed.flags &= -5;
      for (let l = dep.computed.deps; l; l = l.nextDep) {
        removeSub(l, true);
      }
    }
  }
  if (!soft && !--dep.sc && dep.map) {
    dep.map.delete(dep.key);
  }
}
function removeDep(link) {
  const { prevDep, nextDep } = link;
  if (prevDep) {
    prevDep.nextDep = nextDep;
    link.prevDep = void 0;
  }
  if (nextDep) {
    nextDep.prevDep = prevDep;
    link.nextDep = void 0;
  }
}
let shouldTrack = true;
const trackStack = [];
function pauseTracking() {
  trackStack.push(shouldTrack);
  shouldTrack = false;
}
function resetTracking() {
  const last = trackStack.pop();
  shouldTrack = last === void 0 ? true : last;
}
function cleanupEffect(e) {
  const { cleanup } = e;
  e.cleanup = void 0;
  if (cleanup) {
    const prevSub = activeSub;
    activeSub = void 0;
    try {
      cleanup();
    } finally {
      activeSub = prevSub;
    }
  }
}
let globalVersion = 0;
class Link {
  constructor(sub, dep) {
    this.sub = sub;
    this.dep = dep;
    this.version = dep.version;
    this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
  }
}
class Dep {
  constructor(computed2) {
    this.computed = computed2;
    this.version = 0;
    this.activeLink = void 0;
    this.subs = void 0;
    this.map = void 0;
    this.key = void 0;
    this.sc = 0;
  }
  track(debugInfo) {
    if (!activeSub || !shouldTrack || activeSub === this.computed) {
      return;
    }
    let link = this.activeLink;
    if (link === void 0 || link.sub !== activeSub) {
      link = this.activeLink = new Link(activeSub, this);
      if (!activeSub.deps) {
        activeSub.deps = activeSub.depsTail = link;
      } else {
        link.prevDep = activeSub.depsTail;
        activeSub.depsTail.nextDep = link;
        activeSub.depsTail = link;
      }
      addSub(link);
    } else if (link.version === -1) {
      link.version = this.version;
      if (link.nextDep) {
        const next = link.nextDep;
        next.prevDep = link.prevDep;
        if (link.prevDep) {
          link.prevDep.nextDep = next;
        }
        link.prevDep = activeSub.depsTail;
        link.nextDep = void 0;
        activeSub.depsTail.nextDep = link;
        activeSub.depsTail = link;
        if (activeSub.deps === link) {
          activeSub.deps = next;
        }
      }
    }
    return link;
  }
  trigger(debugInfo) {
    this.version++;
    globalVersion++;
    this.notify(debugInfo);
  }
  notify(debugInfo) {
    startBatch();
    try {
      if (false) ;
      for (let link = this.subs; link; link = link.prevSub) {
        if (link.sub.notify()) {
          ;
          link.sub.dep.notify();
        }
      }
    } finally {
      endBatch();
    }
  }
}
function addSub(link) {
  link.dep.sc++;
  if (link.sub.flags & 4) {
    const computed2 = link.dep.computed;
    if (computed2 && !link.dep.subs) {
      computed2.flags |= 4 | 16;
      for (let l = computed2.deps; l; l = l.nextDep) {
        addSub(l);
      }
    }
    const currentTail = link.dep.subs;
    if (currentTail !== link) {
      link.prevSub = currentTail;
      if (currentTail) currentTail.nextSub = link;
    }
    link.dep.subs = link;
  }
}
const targetMap = /* @__PURE__ */ new WeakMap();
const ITERATE_KEY = Symbol(
  ""
);
const MAP_KEY_ITERATE_KEY = Symbol(
  ""
);
const ARRAY_ITERATE_KEY = Symbol(
  ""
);
function track(target, type2, key) {
  if (shouldTrack && activeSub) {
    let depsMap = targetMap.get(target);
    if (!depsMap) {
      targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
    }
    let dep = depsMap.get(key);
    if (!dep) {
      depsMap.set(key, dep = new Dep());
      dep.map = depsMap;
      dep.key = key;
    }
    {
      dep.track();
    }
  }
}
function trigger(target, type2, key, newValue, oldValue, oldTarget) {
  const depsMap = targetMap.get(target);
  if (!depsMap) {
    globalVersion++;
    return;
  }
  const run = (dep) => {
    if (dep) {
      {
        dep.trigger();
      }
    }
  };
  startBatch();
  if (type2 === "clear") {
    depsMap.forEach(run);
  } else {
    const targetIsArray = isArray(target);
    const isArrayIndex = targetIsArray && isIntegerKey(key);
    if (targetIsArray && key === "length") {
      const newLength = Number(newValue);
      depsMap.forEach((dep, key2) => {
        if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) {
          run(dep);
        }
      });
    } else {
      if (key !== void 0 || depsMap.has(void 0)) {
        run(depsMap.get(key));
      }
      if (isArrayIndex) {
        run(depsMap.get(ARRAY_ITERATE_KEY));
      }
      switch (type2) {
        case "add":
          if (!targetIsArray) {
            run(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              run(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          } else if (isArrayIndex) {
            run(depsMap.get("length"));
          }
          break;
        case "delete":
          if (!targetIsArray) {
            run(depsMap.get(ITERATE_KEY));
            if (isMap(target)) {
              run(depsMap.get(MAP_KEY_ITERATE_KEY));
            }
          }
          break;
        case "set":
          if (isMap(target)) {
            run(depsMap.get(ITERATE_KEY));
          }
          break;
      }
    }
  }
  endBatch();
}
function reactiveReadArray(array) {
  const raw = toRaw(array);
  if (raw === array) return raw;
  track(raw, "iterate", ARRAY_ITERATE_KEY);
  return isShallow(array) ? raw : raw.map(toReactive);
}
function shallowReadArray(arr) {
  track(arr = toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
  return arr;
}
const arrayInstrumentations = {
  __proto__: null,
  [Symbol.iterator]() {
    return iterator(this, Symbol.iterator, toReactive);
  },
  concat(...args) {
    return reactiveReadArray(this).concat(
      ...args.map((x) => isArray(x) ? reactiveReadArray(x) : x)
    );
  },
  entries() {
    return iterator(this, "entries", (value) => {
      value[1] = toReactive(value[1]);
      return value;
    });
  },
  every(fn, thisArg) {
    return apply(this, "every", fn, thisArg, void 0, arguments);
  },
  filter(fn, thisArg) {
    return apply(this, "filter", fn, thisArg, (v) => v.map(toReactive), arguments);
  },
  find(fn, thisArg) {
    return apply(this, "find", fn, thisArg, toReactive, arguments);
  },
  findIndex(fn, thisArg) {
    return apply(this, "findIndex", fn, thisArg, void 0, arguments);
  },
  findLast(fn, thisArg) {
    return apply(this, "findLast", fn, thisArg, toReactive, arguments);
  },
  findLastIndex(fn, thisArg) {
    return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
  },
  // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
  forEach(fn, thisArg) {
    return apply(this, "forEach", fn, thisArg, void 0, arguments);
  },
  includes(...args) {
    return searchProxy(this, "includes", args);
  },
  indexOf(...args) {
    return searchProxy(this, "indexOf", args);
  },
  join(separator) {
    return reactiveReadArray(this).join(separator);
  },
  // keys() iterator only reads `length`, no optimisation required
  lastIndexOf(...args) {
    return searchProxy(this, "lastIndexOf", args);
  },
  map(fn, thisArg) {
    return apply(this, "map", fn, thisArg, void 0, arguments);
  },
  pop() {
    return noTracking(this, "pop");
  },
  push(...args) {
    return noTracking(this, "push", args);
  },
  reduce(fn, ...args) {
    return reduce(this, "reduce", fn, args);
  },
  reduceRight(fn, ...args) {
    return reduce(this, "reduceRight", fn, args);
  },
  shift() {
    return noTracking(this, "shift");
  },
  // slice could use ARRAY_ITERATE but also seems to beg for range tracking
  some(fn, thisArg) {
    return apply(this, "some", fn, thisArg, void 0, arguments);
  },
  splice(...args) {
    return noTracking(this, "splice", args);
  },
  toReversed() {
    return reactiveReadArray(this).toReversed();
  },
  toSorted(comparer) {
    return reactiveReadArray(this).toSorted(comparer);
  },
  toSpliced(...args) {
    return reactiveReadArray(this).toSpliced(...args);
  },
  unshift(...args) {
    return noTracking(this, "unshift", args);
  },
  values() {
    return iterator(this, "values", toReactive);
  }
};
function iterator(self2, method, wrapValue) {
  const arr = shallowReadArray(self2);
  const iter = arr[method]();
  if (arr !== self2 && !isShallow(self2)) {
    iter._next = iter.next;
    iter.next = () => {
      const result = iter._next();
      if (result.value) {
        result.value = wrapValue(result.value);
      }
      return result;
    };
  }
  return iter;
}
const arrayProto = Array.prototype;
function apply(self2, method, fn, thisArg, wrappedRetFn, args) {
  const arr = shallowReadArray(self2);
  const needsWrap = arr !== self2 && !isShallow(self2);
  const methodFn = arr[method];
  if (methodFn !== arrayProto[method]) {
    const result2 = methodFn.apply(self2, args);
    return needsWrap ? toReactive(result2) : result2;
  }
  let wrappedFn = fn;
  if (arr !== self2) {
    if (needsWrap) {
      wrappedFn = function(item, index2) {
        return fn.call(this, toReactive(item), index2, self2);
      };
    } else if (fn.length > 2) {
      wrappedFn = function(item, index2) {
        return fn.call(this, item, index2, self2);
      };
    }
  }
  const result = methodFn.call(arr, wrappedFn, thisArg);
  return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
}
function reduce(self2, method, fn, args) {
  const arr = shallowReadArray(self2);
  let wrappedFn = fn;
  if (arr !== self2) {
    if (!isShallow(self2)) {
      wrappedFn = function(acc, item, index2) {
        return fn.call(this, acc, toReactive(item), index2, self2);
      };
    } else if (fn.length > 3) {
      wrappedFn = function(acc, item, index2) {
        return fn.call(this, acc, item, index2, self2);
      };
    }
  }
  return arr[method](wrappedFn, ...args);
}
function searchProxy(self2, method, args) {
  const arr = toRaw(self2);
  track(arr, "iterate", ARRAY_ITERATE_KEY);
  const res = arr[method](...args);
  if ((res === -1 || res === false) && isProxy(args[0])) {
    args[0] = toRaw(args[0]);
    return arr[method](...args);
  }
  return res;
}
function noTracking(self2, method, args = []) {
  pauseTracking();
  startBatch();
  const res = toRaw(self2)[method].apply(self2, args);
  endBatch();
  resetTracking();
  return res;
}
const isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
const builtInSymbols = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
);
function hasOwnProperty(key) {
  if (!isSymbol(key)) key = String(key);
  const obj = toRaw(this);
  track(obj, "has", key);
  return obj.hasOwnProperty(key);
}
class BaseReactiveHandler {
  constructor(_isReadonly = false, _isShallow = false) {
    this._isReadonly = _isReadonly;
    this._isShallow = _isShallow;
  }
  get(target, key, receiver) {
    if (key === "__v_skip") return target["__v_skip"];
    const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
    if (key === "__v_isReactive") {
      return !isReadonly2;
    } else if (key === "__v_isReadonly") {
      return isReadonly2;
    } else if (key === "__v_isShallow") {
      return isShallow2;
    } else if (key === "__v_raw") {
      if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) {
        return target;
      }
      return;
    }
    const targetIsArray = isArray(target);
    if (!isReadonly2) {
      let fn;
      if (targetIsArray && (fn = arrayInstrumentations[key])) {
        return fn;
      }
      if (key === "hasOwnProperty") {
        return hasOwnProperty;
      }
    }
    const res = Reflect.get(
      target,
      key,
      // if this is a proxy wrapping a ref, return methods using the raw ref
      // as receiver so that we don't have to call `toRaw` on the ref in all
      // its class methods
      isRef(target) ? target : receiver
    );
    if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
      return res;
    }
    if (!isReadonly2) {
      track(target, "get", key);
    }
    if (isShallow2) {
      return res;
    }
    if (isRef(res)) {
      return targetIsArray && isIntegerKey(key) ? res : res.value;
    }
    if (isObject(res)) {
      return isReadonly2 ? readonly(res) : reactive(res);
    }
    return res;
  }
}
class MutableReactiveHandler extends BaseReactiveHandler {
  constructor(isShallow2 = false) {
    super(false, isShallow2);
  }
  set(target, key, value, receiver) {
    let oldValue = target[key];
    if (!this._isShallow) {
      const isOldValueReadonly = isReadonly(oldValue);
      if (!isShallow(value) && !isReadonly(value)) {
        oldValue = toRaw(oldValue);
        value = toRaw(value);
      }
      if (!isArray(target) && isRef(oldValue) && !isRef(value)) {
        if (isOldValueReadonly) {
          return false;
        } else {
          oldValue.value = value;
          return true;
        }
      }
    }
    const hadKey = isArray(target) && isIntegerKey(key) ? Number(key) < target.length : hasOwn(target, key);
    const result = Reflect.set(
      target,
      key,
      value,
      isRef(target) ? target : receiver
    );
    if (target === toRaw(receiver)) {
      if (!hadKey) {
        trigger(target, "add", key, value);
      } else if (hasChanged(value, oldValue)) {
        trigger(target, "set", key, value);
      }
    }
    return result;
  }
  deleteProperty(target, key) {
    const hadKey = hasOwn(target, key);
    target[key];
    const result = Reflect.deleteProperty(target, key);
    if (result && hadKey) {
      trigger(target, "delete", key, void 0);
    }
    return result;
  }
  has(target, key) {
    const result = Reflect.has(target, key);
    if (!isSymbol(key) || !builtInSymbols.has(key)) {
      track(target, "has", key);
    }
    return result;
  }
  ownKeys(target) {
    track(
      target,
      "iterate",
      isArray(target) ? "length" : ITERATE_KEY
    );
    return Reflect.ownKeys(target);
  }
}
class ReadonlyReactiveHandler extends BaseReactiveHandler {
  constructor(isShallow2 = false) {
    super(true, isShallow2);
  }
  set(target, key) {
    return true;
  }
  deleteProperty(target, key) {
    return true;
  }
}
const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);
const toShallow = (value) => value;
const getProto = (v) => Reflect.getPrototypeOf(v);
function createIterableMethod(method, isReadonly2, isShallow2) {
  return function(...args) {
    const target = this["__v_raw"];
    const rawTarget = toRaw(target);
    const targetIsMap = isMap(rawTarget);
    const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
    const isKeyOnly = method === "keys" && targetIsMap;
    const innerIterator = target[method](...args);
    const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
    !isReadonly2 && track(
      rawTarget,
      "iterate",
      isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY
    );
    return {
      // iterator protocol
      next() {
        const { value, done } = innerIterator.next();
        return done ? { value, done } : {
          value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
          done
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function createReadonlyMethod(type2) {
  return function(...args) {
    return type2 === "delete" ? false : type2 === "clear" ? void 0 : this;
  };
}
function createInstrumentations(readonly2, shallow) {
  const instrumentations = {
    get(key) {
      const target = this["__v_raw"];
      const rawTarget = toRaw(target);
      const rawKey = toRaw(key);
      if (!readonly2) {
        if (hasChanged(key, rawKey)) {
          track(rawTarget, "get", key);
        }
        track(rawTarget, "get", rawKey);
      }
      const { has } = getProto(rawTarget);
      const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
      if (has.call(rawTarget, key)) {
        return wrap(target.get(key));
      } else if (has.call(rawTarget, rawKey)) {
        return wrap(target.get(rawKey));
      } else if (target !== rawTarget) {
        target.get(key);
      }
    },
    get size() {
      const target = this["__v_raw"];
      !readonly2 && track(toRaw(target), "iterate", ITERATE_KEY);
      return Reflect.get(target, "size", target);
    },
    has(key) {
      const target = this["__v_raw"];
      const rawTarget = toRaw(target);
      const rawKey = toRaw(key);
      if (!readonly2) {
        if (hasChanged(key, rawKey)) {
          track(rawTarget, "has", key);
        }
        track(rawTarget, "has", rawKey);
      }
      return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
    },
    forEach(callback2, thisArg) {
      const observed = this;
      const target = observed["__v_raw"];
      const rawTarget = toRaw(target);
      const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
      !readonly2 && track(rawTarget, "iterate", ITERATE_KEY);
      return target.forEach((value, key) => {
        return callback2.call(thisArg, wrap(value), wrap(key), observed);
      });
    }
  };
  extend(
    instrumentations,
    readonly2 ? {
      add: createReadonlyMethod("add"),
      set: createReadonlyMethod("set"),
      delete: createReadonlyMethod("delete"),
      clear: createReadonlyMethod("clear")
    } : {
      add(value) {
        if (!shallow && !isShallow(value) && !isReadonly(value)) {
          value = toRaw(value);
        }
        const target = toRaw(this);
        const proto = getProto(target);
        const hadKey = proto.has.call(target, value);
        if (!hadKey) {
          target.add(value);
          trigger(target, "add", value, value);
        }
        return this;
      },
      set(key, value) {
        if (!shallow && !isShallow(value) && !isReadonly(value)) {
          value = toRaw(value);
        }
        const target = toRaw(this);
        const { has, get } = getProto(target);
        let hadKey = has.call(target, key);
        if (!hadKey) {
          key = toRaw(key);
          hadKey = has.call(target, key);
        }
        const oldValue = get.call(target, key);
        target.set(key, value);
        if (!hadKey) {
          trigger(target, "add", key, value);
        } else if (hasChanged(value, oldValue)) {
          trigger(target, "set", key, value);
        }
        return this;
      },
      delete(key) {
        const target = toRaw(this);
        const { has, get } = getProto(target);
        let hadKey = has.call(target, key);
        if (!hadKey) {
          key = toRaw(key);
          hadKey = has.call(target, key);
        }
        get ? get.call(target, key) : void 0;
        const result = target.delete(key);
        if (hadKey) {
          trigger(target, "delete", key, void 0);
        }
        return result;
      },
      clear() {
        const target = toRaw(this);
        const hadItems = target.size !== 0;
        const result = target.clear();
        if (hadItems) {
          trigger(
            target,
            "clear",
            void 0,
            void 0
          );
        }
        return result;
      }
    }
  );
  const iteratorMethods = [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ];
  iteratorMethods.forEach((method) => {
    instrumentations[method] = createIterableMethod(method, readonly2, shallow);
  });
  return instrumentations;
}
function createInstrumentationGetter(isReadonly2, shallow) {
  const instrumentations = createInstrumentations(isReadonly2, shallow);
  return (target, key, receiver) => {
    if (key === "__v_isReactive") {
      return !isReadonly2;
    } else if (key === "__v_isReadonly") {
      return isReadonly2;
    } else if (key === "__v_raw") {
      return target;
    }
    return Reflect.get(
      hasOwn(instrumentations, key) && key in target ? instrumentations : target,
      key,
      receiver
    );
  };
}
const mutableCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(false, false)
};
const shallowCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(false, true)
};
const readonlyCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(true, false)
};
const shallowReadonlyCollectionHandlers = {
  get: /* @__PURE__ */ createInstrumentationGetter(true, true)
};
const reactiveMap = /* @__PURE__ */ new WeakMap();
const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
const readonlyMap = /* @__PURE__ */ new WeakMap();
const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
  switch (rawType) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function getTargetType(value) {
  return value["__v_skip"] || !Object.isExtensible(value) ? 0 : targetTypeMap(toRawType(value));
}
function reactive(target) {
  if (isReadonly(target)) {
    return target;
  }
  return createReactiveObject(
    target,
    false,
    mutableHandlers,
    mutableCollectionHandlers,
    reactiveMap
  );
}
function shallowReactive(target) {
  return createReactiveObject(
    target,
    false,
    shallowReactiveHandlers,
    shallowCollectionHandlers,
    shallowReactiveMap
  );
}
function readonly(target) {
  return createReactiveObject(
    target,
    true,
    readonlyHandlers,
    readonlyCollectionHandlers,
    readonlyMap
  );
}
function shallowReadonly(target) {
  return createReactiveObject(
    target,
    true,
    shallowReadonlyHandlers,
    shallowReadonlyCollectionHandlers,
    shallowReadonlyMap
  );
}
function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
  if (!isObject(target)) {
    return target;
  }
  if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
    return target;
  }
  const existingProxy = proxyMap.get(target);
  if (existingProxy) {
    return existingProxy;
  }
  const targetType = getTargetType(target);
  if (targetType === 0) {
    return target;
  }
  const proxy = new Proxy(
    target,
    targetType === 2 ? collectionHandlers : baseHandlers
  );
  proxyMap.set(target, proxy);
  return proxy;
}
function isReactive(value) {
  if (isReadonly(value)) {
    return isReactive(value["__v_raw"]);
  }
  return !!(value && value["__v_isReactive"]);
}
function isReadonly(value) {
  return !!(value && value["__v_isReadonly"]);
}
function isShallow(value) {
  return !!(value && value["__v_isShallow"]);
}
function isProxy(value) {
  return value ? !!value["__v_raw"] : false;
}
function toRaw(observed) {
  const raw = observed && observed["__v_raw"];
  return raw ? toRaw(raw) : observed;
}
function markRaw(value) {
  if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
    def(value, "__v_skip", true);
  }
  return value;
}
const toReactive = (value) => isObject(value) ? reactive(value) : value;
const toReadonly = (value) => isObject(value) ? readonly(value) : value;
function isRef(r) {
  return r ? r["__v_isRef"] === true : false;
}
function ref(value) {
  return createRef(value, false);
}
function createRef(rawValue, shallow) {
  if (isRef(rawValue)) {
    return rawValue;
  }
  return new RefImpl(rawValue, shallow);
}
class RefImpl {
  constructor(value, isShallow2) {
    this.dep = new Dep();
    this["__v_isRef"] = true;
    this["__v_isShallow"] = false;
    this._rawValue = isShallow2 ? value : toRaw(value);
    this._value = isShallow2 ? value : toReactive(value);
    this["__v_isShallow"] = isShallow2;
  }
  get value() {
    {
      this.dep.track();
    }
    return this._value;
  }
  set value(newValue) {
    const oldValue = this._rawValue;
    const useDirectValue = this["__v_isShallow"] || isShallow(newValue) || isReadonly(newValue);
    newValue = useDirectValue ? newValue : toRaw(newValue);
    if (hasChanged(newValue, oldValue)) {
      this._rawValue = newValue;
      this._value = useDirectValue ? newValue : toReactive(newValue);
      {
        this.dep.trigger();
      }
    }
  }
}
function unref(ref2) {
  return isRef(ref2) ? ref2.value : ref2;
}
const shallowUnwrapHandlers = {
  get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
  set: (target, key, value, receiver) => {
    const oldValue = target[key];
    if (isRef(oldValue) && !isRef(value)) {
      oldValue.value = value;
      return true;
    } else {
      return Reflect.set(target, key, value, receiver);
    }
  }
};
function proxyRefs(objectWithRefs) {
  return isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
class ComputedRefImpl {
  constructor(fn, setter, isSSR) {
    this.fn = fn;
    this.setter = setter;
    this._value = void 0;
    this.dep = new Dep(this);
    this.__v_isRef = true;
    this.deps = void 0;
    this.depsTail = void 0;
    this.flags = 16;
    this.globalVersion = globalVersion - 1;
    this.next = void 0;
    this.effect = this;
    this["__v_isReadonly"] = !setter;
    this.isSSR = isSSR;
  }
  /**
   * @internal
   */
  notify() {
    this.flags |= 16;
    if (!(this.flags & 8) && // avoid infinite self recursion
    activeSub !== this) {
      batch(this, true);
      return true;
    }
  }
  get value() {
    const link = this.dep.track();
    refreshComputed(this);
    if (link) {
      link.version = this.dep.version;
    }
    return this._value;
  }
  set value(newValue) {
    if (this.setter) {
      this.setter(newValue);
    }
  }
}
function computed$1(getterOrOptions, debugOptions, isSSR = false) {
  let getter;
  let setter;
  if (isFunction$1(getterOrOptions)) {
    getter = getterOrOptions;
  } else {
    getter = getterOrOptions.get;
    setter = getterOrOptions.set;
  }
  const cRef = new ComputedRefImpl(getter, setter, isSSR);
  return cRef;
}
const INITIAL_WATCHER_VALUE = {};
const cleanupMap = /* @__PURE__ */ new WeakMap();
let activeWatcher = void 0;
function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
  if (owner) {
    let cleanups = cleanupMap.get(owner);
    if (!cleanups) cleanupMap.set(owner, cleanups = []);
    cleanups.push(cleanupFn);
  }
}
function watch$1(source, cb, options = EMPTY_OBJ) {
  const { immediate, deep, once, scheduler, augmentJob, call } = options;
  const reactiveGetter = (source2) => {
    if (deep) return source2;
    if (isShallow(source2) || deep === false || deep === 0)
      return traverse(source2, 1);
    return traverse(source2);
  };
  let effect;
  let getter;
  let cleanup;
  let boundCleanup;
  let forceTrigger = false;
  let isMultiSource = false;
  if (isRef(source)) {
    getter = () => source.value;
    forceTrigger = isShallow(source);
  } else if (isReactive(source)) {
    getter = () => reactiveGetter(source);
    forceTrigger = true;
  } else if (isArray(source)) {
    isMultiSource = true;
    forceTrigger = source.some((s) => isReactive(s) || isShallow(s));
    getter = () => source.map((s) => {
      if (isRef(s)) {
        return s.value;
      } else if (isReactive(s)) {
        return reactiveGetter(s);
      } else if (isFunction$1(s)) {
        return call ? call(s, 2) : s();
      } else ;
    });
  } else if (isFunction$1(source)) {
    if (cb) {
      getter = call ? () => call(source, 2) : source;
    } else {
      getter = () => {
        if (cleanup) {
          pauseTracking();
          try {
            cleanup();
          } finally {
            resetTracking();
          }
        }
        const currentEffect = activeWatcher;
        activeWatcher = effect;
        try {
          return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
        } finally {
          activeWatcher = currentEffect;
        }
      };
    }
  } else {
    getter = NOOP;
  }
  if (cb && deep) {
    const baseGetter = getter;
    const depth = deep === true ? Infinity : deep;
    getter = () => traverse(baseGetter(), depth);
  }
  const scope = getCurrentScope();
  const watchHandle = () => {
    effect.stop();
    if (scope && scope.active) {
      remove(scope.effects, effect);
    }
  };
  if (once && cb) {
    const _cb = cb;
    cb = (...args) => {
      _cb(...args);
      watchHandle();
    };
  }
  let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
  const job = (immediateFirstRun) => {
    if (!(effect.flags & 1) || !effect.dirty && !immediateFirstRun) {
      return;
    }
    if (cb) {
      const newValue = effect.run();
      if (deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
        if (cleanup) {
          cleanup();
        }
        const currentWatcher = activeWatcher;
        activeWatcher = effect;
        try {
          const args = [
            newValue,
            // pass undefined as the old value when it's changed for the first time
            oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
            boundCleanup
          ];
          call ? call(cb, 3, args) : (
            // @ts-expect-error
            cb(...args)
          );
          oldValue = newValue;
        } finally {
          activeWatcher = currentWatcher;
        }
      }
    } else {
      effect.run();
    }
  };
  if (augmentJob) {
    augmentJob(job);
  }
  effect = new ReactiveEffect(getter);
  effect.scheduler = scheduler ? () => scheduler(job, false) : job;
  boundCleanup = (fn) => onWatcherCleanup(fn, false, effect);
  cleanup = effect.onStop = () => {
    const cleanups = cleanupMap.get(effect);
    if (cleanups) {
      if (call) {
        call(cleanups, 4);
      } else {
        for (const cleanup2 of cleanups) cleanup2();
      }
      cleanupMap.delete(effect);
    }
  };
  if (cb) {
    if (immediate) {
      job(true);
    } else {
      oldValue = effect.run();
    }
  } else if (scheduler) {
    scheduler(job.bind(null, true), true);
  } else {
    effect.run();
  }
  watchHandle.pause = effect.pause.bind(effect);
  watchHandle.resume = effect.resume.bind(effect);
  watchHandle.stop = watchHandle;
  return watchHandle;
}
function traverse(value, depth = Infinity, seen2) {
  if (depth <= 0 || !isObject(value) || value["__v_skip"]) {
    return value;
  }
  seen2 = seen2 || /* @__PURE__ */ new Set();
  if (seen2.has(value)) {
    return value;
  }
  seen2.add(value);
  depth--;
  if (isRef(value)) {
    traverse(value.value, depth, seen2);
  } else if (isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      traverse(value[i], depth, seen2);
    }
  } else if (isSet(value) || isMap(value)) {
    value.forEach((v) => {
      traverse(v, depth, seen2);
    });
  } else if (isPlainObject(value)) {
    for (const key in value) {
      traverse(value[key], depth, seen2);
    }
    for (const key of Object.getOwnPropertySymbols(value)) {
      if (Object.prototype.propertyIsEnumerable.call(value, key)) {
        traverse(value[key], depth, seen2);
      }
    }
  }
  return value;
}
/**
* @vue/runtime-core v3.5.13
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
const stack = [];
let isWarning = false;
function warn$1(msg, ...args) {
  if (isWarning) return;
  isWarning = true;
  pauseTracking();
  const instance = stack.length ? stack[stack.length - 1].component : null;
  const appWarnHandler = instance && instance.appContext.config.warnHandler;
  const trace = getComponentTrace();
  if (appWarnHandler) {
    callWithErrorHandling(
      appWarnHandler,
      instance,
      11,
      [
        // eslint-disable-next-line no-restricted-syntax
        msg + args.map((a) => {
          var _a, _b;
          return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
        }).join(""),
        instance && instance.proxy,
        trace.map(
          ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
        ).join("\n"),
        trace
      ]
    );
  } else {
    const warnArgs = [`[Vue warn]: ${msg}`, ...args];
    if (trace.length && // avoid spamming console during tests
    true) {
      warnArgs.push(`
`, ...formatTrace(trace));
    }
    console.warn(...warnArgs);
  }
  resetTracking();
  isWarning = false;
}
function getComponentTrace() {
  let currentVNode = stack[stack.length - 1];
  if (!currentVNode) {
    return [];
  }
  const normalizedStack = [];
  while (currentVNode) {
    const last = normalizedStack[0];
    if (last && last.vnode === currentVNode) {
      last.recurseCount++;
    } else {
      normalizedStack.push({
        vnode: currentVNode,
        recurseCount: 0
      });
    }
    const parentInstance = currentVNode.component && currentVNode.component.parent;
    currentVNode = parentInstance && parentInstance.vnode;
  }
  return normalizedStack;
}
function formatTrace(trace) {
  const logs = [];
  trace.forEach((entry, i) => {
    logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
  });
  return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
  const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
  const isRoot = vnode.component ? vnode.component.parent == null : false;
  const open = ` at <${formatComponentName(
    vnode.component,
    vnode.type,
    isRoot
  )}`;
  const close = `>` + postfix;
  return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
}
function formatProps(props) {
  const res = [];
  const keys = Object.keys(props);
  keys.slice(0, 3).forEach((key) => {
    res.push(...formatProp(key, props[key]));
  });
  if (keys.length > 3) {
    res.push(` ...`);
  }
  return res;
}
function formatProp(key, value, raw) {
  if (isString$1(value)) {
    value = JSON.stringify(value);
    return raw ? value : [`${key}=${value}`];
  } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
    return raw ? value : [`${key}=${value}`];
  } else if (isRef(value)) {
    value = formatProp(key, toRaw(value.value), true);
    return raw ? value : [`${key}=Ref<`, value, `>`];
  } else if (isFunction$1(value)) {
    return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
  } else {
    value = toRaw(value);
    return raw ? value : [`${key}=`, value];
  }
}
function callWithErrorHandling(fn, instance, type2, args) {
  try {
    return args ? fn(...args) : fn();
  } catch (err) {
    handleError(err, instance, type2);
  }
}
function callWithAsyncErrorHandling(fn, instance, type2, args) {
  if (isFunction$1(fn)) {
    const res = callWithErrorHandling(fn, instance, type2, args);
    if (res && isPromise(res)) {
      res.catch((err) => {
        handleError(err, instance, type2);
      });
    }
    return res;
  }
  if (isArray(fn)) {
    const values = [];
    for (let i = 0; i < fn.length; i++) {
      values.push(callWithAsyncErrorHandling(fn[i], instance, type2, args));
    }
    return values;
  }
}
function handleError(err, instance, type2, throwInDev = true) {
  const contextVNode = instance ? instance.vnode : null;
  const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
  if (instance) {
    let cur = instance.parent;
    const exposedInstance = instance.proxy;
    const errorInfo = `https://vuejs.org/error-reference/#runtime-${type2}`;
    while (cur) {
      const errorCapturedHooks = cur.ec;
      if (errorCapturedHooks) {
        for (let i = 0; i < errorCapturedHooks.length; i++) {
          if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
            return;
          }
        }
      }
      cur = cur.parent;
    }
    if (errorHandler) {
      pauseTracking();
      callWithErrorHandling(errorHandler, null, 10, [
        err,
        exposedInstance,
        errorInfo
      ]);
      resetTracking();
      return;
    }
  }
  logError(err, type2, contextVNode, throwInDev, throwUnhandledErrorInProduction);
}
function logError(err, type2, contextVNode, throwInDev = true, throwInProd = false) {
  if (throwInProd) {
    throw err;
  } else {
    console.error(err);
  }
}
const queue = [];
let flushIndex = -1;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
function nextTick(fn) {
  const p2 = currentFlushPromise || resolvedPromise;
  return fn ? p2.then(this ? fn.bind(this) : fn) : p2;
}
function findInsertionIndex(id) {
  let start = flushIndex + 1;
  let end = queue.length;
  while (start < end) {
    const middle = start + end >>> 1;
    const middleJob = queue[middle];
    const middleJobId = getId(middleJob);
    if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
      start = middle + 1;
    } else {
      end = middle;
    }
  }
  return start;
}
function queueJob(job) {
  if (!(job.flags & 1)) {
    const jobId = getId(job);
    const lastJob = queue[queue.length - 1];
    if (!lastJob || // fast path when the job id is larger than the tail
    !(job.flags & 2) && jobId >= getId(lastJob)) {
      queue.push(job);
    } else {
      queue.splice(findInsertionIndex(jobId), 0, job);
    }
    job.flags |= 1;
    queueFlush();
  }
}
function queueFlush() {
  if (!currentFlushPromise) {
    currentFlushPromise = resolvedPromise.then(flushJobs);
  }
}
function queuePostFlushCb(cb) {
  if (!isArray(cb)) {
    if (activePostFlushCbs && cb.id === -1) {
      activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
    } else if (!(cb.flags & 1)) {
      pendingPostFlushCbs.push(cb);
      cb.flags |= 1;
    }
  } else {
    pendingPostFlushCbs.push(...cb);
  }
  queueFlush();
}
function flushPreFlushCbs(instance, seen2, i = flushIndex + 1) {
  for (; i < queue.length; i++) {
    const cb = queue[i];
    if (cb && cb.flags & 2) {
      if (instance && cb.id !== instance.uid) {
        continue;
      }
      queue.splice(i, 1);
      i--;
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      cb();
      if (!(cb.flags & 4)) {
        cb.flags &= -2;
      }
    }
  }
}
function flushPostFlushCbs(seen2) {
  if (pendingPostFlushCbs.length) {
    const deduped = [...new Set(pendingPostFlushCbs)].sort(
      (a, b) => getId(a) - getId(b)
    );
    pendingPostFlushCbs.length = 0;
    if (activePostFlushCbs) {
      activePostFlushCbs.push(...deduped);
      return;
    }
    activePostFlushCbs = deduped;
    for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
      const cb = activePostFlushCbs[postFlushIndex];
      if (cb.flags & 4) {
        cb.flags &= -2;
      }
      if (!(cb.flags & 8)) cb();
      cb.flags &= -2;
    }
    activePostFlushCbs = null;
    postFlushIndex = 0;
  }
}
const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
function flushJobs(seen2) {
  try {
    for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job && !(job.flags & 8)) {
        if (false) ;
        if (job.flags & 4) {
          job.flags &= ~1;
        }
        callWithErrorHandling(
          job,
          job.i,
          job.i ? 15 : 14
        );
        if (!(job.flags & 4)) {
          job.flags &= ~1;
        }
      }
    }
  } finally {
    for (; flushIndex < queue.length; flushIndex++) {
      const job = queue[flushIndex];
      if (job) {
        job.flags &= -2;
      }
    }
    flushIndex = -1;
    queue.length = 0;
    flushPostFlushCbs();
    currentFlushPromise = null;
    if (queue.length || pendingPostFlushCbs.length) {
      flushJobs();
    }
  }
}
let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
  const prev = currentRenderingInstance;
  currentRenderingInstance = instance;
  currentScopeId = instance && instance.type.__scopeId || null;
  return prev;
}
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
  if (!ctx) return fn;
  if (fn._n) {
    return fn;
  }
  const renderFnWithContext = (...args) => {
    if (renderFnWithContext._d) {
      setBlockTracking(-1);
    }
    const prevInstance = setCurrentRenderingInstance(ctx);
    let res;
    try {
      res = fn(...args);
    } finally {
      setCurrentRenderingInstance(prevInstance);
      if (renderFnWithContext._d) {
        setBlockTracking(1);
      }
    }
    return res;
  };
  renderFnWithContext._n = true;
  renderFnWithContext._c = true;
  renderFnWithContext._d = true;
  return renderFnWithContext;
}
function withDirectives(vnode, directives) {
  if (currentRenderingInstance === null) {
    return vnode;
  }
  const instance = getComponentPublicInstance(currentRenderingInstance);
  const bindings = vnode.dirs || (vnode.dirs = []);
  for (let i = 0; i < directives.length; i++) {
    let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
    if (dir) {
      if (isFunction$1(dir)) {
        dir = {
          mounted: dir,
          updated: dir
        };
      }
      if (dir.deep) {
        traverse(value);
      }
      bindings.push({
        dir,
        instance,
        value,
        oldValue: void 0,
        arg,
        modifiers
      });
    }
  }
  return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
  const bindings = vnode.dirs;
  const oldBindings = prevVNode && prevVNode.dirs;
  for (let i = 0; i < bindings.length; i++) {
    const binding = bindings[i];
    if (oldBindings) {
      binding.oldValue = oldBindings[i].value;
    }
    let hook = binding.dir[name];
    if (hook) {
      pauseTracking();
      callWithAsyncErrorHandling(hook, instance, 8, [
        vnode.el,
        binding,
        vnode,
        prevVNode
      ]);
      resetTracking();
    }
  }
}
const TeleportEndKey = Symbol("_vte");
const isTeleport = (type2) => type2.__isTeleport;
function setTransitionHooks(vnode, hooks) {
  if (vnode.shapeFlag & 6 && vnode.component) {
    vnode.transition = hooks;
    setTransitionHooks(vnode.component.subTree, hooks);
  } else if (vnode.shapeFlag & 128) {
    vnode.ssContent.transition = hooks.clone(vnode.ssContent);
    vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
  } else {
    vnode.transition = hooks;
  }
}
function markAsyncBoundary(instance) {
  instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
}
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
  if (isArray(rawRef)) {
    rawRef.forEach(
      (r, i) => setRef(
        r,
        oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
        parentSuspense,
        vnode,
        isUnmount
      )
    );
    return;
  }
  if (isAsyncWrapper(vnode) && !isUnmount) {
    if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
      setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
    }
    return;
  }
  const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
  const value = isUnmount ? null : refValue;
  const { i: owner, r: ref3 } = rawRef;
  const oldRef = oldRawRef && oldRawRef.r;
  const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
  const setupState = owner.setupState;
  const rawSetupState = toRaw(setupState);
  const canSetSetupRef = setupState === EMPTY_OBJ ? () => false : (key) => {
    return hasOwn(rawSetupState, key);
  };
  if (oldRef != null && oldRef !== ref3) {
    if (isString$1(oldRef)) {
      refs[oldRef] = null;
      if (canSetSetupRef(oldRef)) {
        setupState[oldRef] = null;
      }
    } else if (isRef(oldRef)) {
      oldRef.value = null;
    }
  }
  if (isFunction$1(ref3)) {
    callWithErrorHandling(ref3, owner, 12, [value, refs]);
  } else {
    const _isString = isString$1(ref3);
    const _isRef = isRef(ref3);
    if (_isString || _isRef) {
      const doSet = () => {
        if (rawRef.f) {
          const existing = _isString ? canSetSetupRef(ref3) ? setupState[ref3] : refs[ref3] : ref3.value;
          if (isUnmount) {
            isArray(existing) && remove(existing, refValue);
          } else {
            if (!isArray(existing)) {
              if (_isString) {
                refs[ref3] = [refValue];
                if (canSetSetupRef(ref3)) {
                  setupState[ref3] = refs[ref3];
                }
              } else {
                ref3.value = [refValue];
                if (rawRef.k) refs[rawRef.k] = ref3.value;
              }
            } else if (!existing.includes(refValue)) {
              existing.push(refValue);
            }
          }
        } else if (_isString) {
          refs[ref3] = value;
          if (canSetSetupRef(ref3)) {
            setupState[ref3] = value;
          }
        } else if (_isRef) {
          ref3.value = value;
          if (rawRef.k) refs[rawRef.k] = value;
        } else ;
      };
      if (value) {
        doSet.id = -1;
        queuePostRenderEffect(doSet, parentSuspense);
      } else {
        doSet();
      }
    }
  }
}
getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
function onActivated(hook, target) {
  registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
  registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type2, target = currentInstance) {
  const wrappedHook = hook.__wdc || (hook.__wdc = () => {
    let current = target;
    while (current) {
      if (current.isDeactivated) {
        return;
      }
      current = current.parent;
    }
    return hook();
  });
  injectHook(type2, wrappedHook, target);
  if (target) {
    let current = target.parent;
    while (current && current.parent) {
      if (isKeepAlive(current.parent.vnode)) {
        injectToKeepAliveRoot(wrappedHook, type2, target, current);
      }
      current = current.parent;
    }
  }
}
function injectToKeepAliveRoot(hook, type2, target, keepAliveRoot) {
  const injected = injectHook(
    type2,
    hook,
    keepAliveRoot,
    true
    /* prepend */
  );
  onUnmounted(() => {
    remove(keepAliveRoot[type2], injected);
  }, target);
}
function injectHook(type2, hook, target = currentInstance, prepend = false) {
  if (target) {
    const hooks = target[type2] || (target[type2] = []);
    const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
      pauseTracking();
      const reset = setCurrentInstance(target);
      const res = callWithAsyncErrorHandling(hook, target, type2, args);
      reset();
      resetTracking();
      return res;
    });
    if (prepend) {
      hooks.unshift(wrappedHook);
    } else {
      hooks.push(wrappedHook);
    }
    return wrappedHook;
  }
}
const createHook = (lifecycle) => (hook, target = currentInstance) => {
  if (!isInSSRComponentSetup || lifecycle === "sp") {
    injectHook(lifecycle, (...args) => hook(...args), target);
  }
};
const onBeforeMount = createHook("bm");
const onMounted = createHook("m");
const onBeforeUpdate = createHook(
  "bu"
);
const onUpdated = createHook("u");
const onBeforeUnmount = createHook(
  "bum"
);
const onUnmounted = createHook("um");
const onServerPrefetch = createHook(
  "sp"
);
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
  injectHook("ec", hook, target);
}
const COMPONENTS = "components";
const DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
  return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
const NULL_DYNAMIC_COMPONENT = Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
  if (isString$1(component)) {
    return resolveAsset(COMPONENTS, component, false) || component;
  } else {
    return component || NULL_DYNAMIC_COMPONENT;
  }
}
function resolveDirective(name) {
  return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type2, name, warnMissing = true, maybeSelfReference = false) {
  const instance = currentRenderingInstance || currentInstance;
  if (instance) {
    const Component = instance.type;
    if (type2 === COMPONENTS) {
      const selfName = getComponentName(
        Component,
        false
      );
      if (selfName && (selfName === name || selfName === camelize(name) || selfName === capitalize(camelize(name)))) {
        return Component;
      }
    }
    const res = (
      // local registration
      // check instance[type] first which is resolved for options API
      resolve(instance[type2] || Component[type2], name) || // global registration
      resolve(instance.appContext[type2], name)
    );
    if (!res && maybeSelfReference) {
      return Component;
    }
    return res;
  }
}
function resolve(registry, name) {
  return registry && (registry[name] || registry[camelize(name)] || registry[capitalize(camelize(name))]);
}
function renderList(source, renderItem, cache, index2) {
  let ret;
  const cached = cache && cache[index2];
  const sourceIsArray = isArray(source);
  if (sourceIsArray || isString$1(source)) {
    const sourceIsReactiveArray = sourceIsArray && isReactive(source);
    let needsWrap = false;
    if (sourceIsReactiveArray) {
      needsWrap = !isShallow(source);
      source = shallowReadArray(source);
    }
    ret = new Array(source.length);
    for (let i = 0, l = source.length; i < l; i++) {
      ret[i] = renderItem(
        needsWrap ? toReactive(source[i]) : source[i],
        i,
        void 0,
        cached && cached[i]
      );
    }
  } else if (typeof source === "number") {
    ret = new Array(source);
    for (let i = 0; i < source; i++) {
      ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
    }
  } else if (isObject(source)) {
    if (source[Symbol.iterator]) {
      ret = Array.from(
        source,
        (item, i) => renderItem(item, i, void 0, cached && cached[i])
      );
    } else {
      const keys = Object.keys(source);
      ret = new Array(keys.length);
      for (let i = 0, l = keys.length; i < l; i++) {
        const key = keys[i];
        ret[i] = renderItem(source[key], key, i, cached && cached[i]);
      }
    }
  } else {
    ret = [];
  }
  if (cache) {
    cache[index2] = ret;
  }
  return ret;
}
function createSlots(slots, dynamicSlots) {
  for (let i = 0; i < dynamicSlots.length; i++) {
    const slot = dynamicSlots[i];
    if (isArray(slot)) {
      for (let j = 0; j < slot.length; j++) {
        slots[slot[j].name] = slot[j].fn;
      }
    } else if (slot) {
      slots[slot.name] = slot.key ? (...args) => {
        const res = slot.fn(...args);
        if (res) res.key = slot.key;
        return res;
      } : slot.fn;
    }
  }
  return slots;
}
function renderSlot(slots, name, props = {}, fallback, noSlotted) {
  if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
    if (name !== "default") props.name = name;
    return openBlock(), createBlock(
      Fragment,
      null,
      [createVNode("slot", props, fallback && fallback())],
      64
    );
  }
  let slot = slots[name];
  if (slot && slot._c) {
    slot._d = false;
  }
  openBlock();
  const validSlotContent = slot && ensureValidVNode(slot(props));
  const slotKey = props.key || // slot content array of a dynamic conditional slot may have a branch
  // key attached in the `createSlots` helper, respect that
  validSlotContent && validSlotContent.key;
  const rendered = createBlock(
    Fragment,
    {
      key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + // #7256 force differentiate fallback content from actual content
      (!validSlotContent && fallback ? "_fb" : "")
    },
    validSlotContent || (fallback ? fallback() : []),
    validSlotContent && slots._ === 1 ? 64 : -2
  );
  if (!noSlotted && rendered.scopeId) {
    rendered.slotScopeIds = [rendered.scopeId + "-s"];
  }
  if (slot && slot._c) {
    slot._d = true;
  }
  return rendered;
}
function ensureValidVNode(vnodes) {
  return vnodes.some((child) => {
    if (!isVNode(child)) return true;
    if (child.type === Comment) return false;
    if (child.type === Fragment && !ensureValidVNode(child.children))
      return false;
    return true;
  }) ? vnodes : null;
}
const getPublicInstance = (i) => {
  if (!i) return null;
  if (isStatefulComponent(i)) return getComponentPublicInstance(i);
  return getPublicInstance(i.parent);
};
const publicPropertiesMap = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
    $: (i) => i,
    $el: (i) => i.vnode.el,
    $data: (i) => i.data,
    $props: (i) => i.props,
    $attrs: (i) => i.attrs,
    $slots: (i) => i.slots,
    $refs: (i) => i.refs,
    $parent: (i) => getPublicInstance(i.parent),
    $root: (i) => getPublicInstance(i.root),
    $host: (i) => i.ce,
    $emit: (i) => i.emit,
    $options: (i) => resolveMergedOptions(i),
    $forceUpdate: (i) => i.f || (i.f = () => {
      queueJob(i.update);
    }),
    $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
    $watch: (i) => instanceWatch.bind(i)
  })
);
const hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
const PublicInstanceProxyHandlers = {
  get({ _: instance }, key) {
    if (key === "__v_skip") {
      return true;
    }
    const { ctx, setupState, data, props, accessCache, type: type2, appContext } = instance;
    let normalizedProps;
    if (key[0] !== "$") {
      const n = accessCache[key];
      if (n !== void 0) {
        switch (n) {
          case 1:
            return setupState[key];
          case 2:
            return data[key];
          case 4:
            return ctx[key];
          case 3:
            return props[key];
        }
      } else if (hasSetupBinding(setupState, key)) {
        accessCache[key] = 1;
        return setupState[key];
      } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
        accessCache[key] = 2;
        return data[key];
      } else if (
        // only cache other properties when instance has declared (thus stable)
        // props
        (normalizedProps = instance.propsOptions[0]) && hasOwn(normalizedProps, key)
      ) {
        accessCache[key] = 3;
        return props[key];
      } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4;
        return ctx[key];
      } else if (shouldCacheAccess) {
        accessCache[key] = 0;
      }
    }
    const publicGetter = publicPropertiesMap[key];
    let cssModule, globalProperties;
    if (publicGetter) {
      if (key === "$attrs") {
        track(instance.attrs, "get", "");
      }
      return publicGetter(instance);
    } else if (
      // css module (injected by vue-loader)
      (cssModule = type2.__cssModules) && (cssModule = cssModule[key])
    ) {
      return cssModule;
    } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
      accessCache[key] = 4;
      return ctx[key];
    } else if (
      // global properties
      globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
    ) {
      {
        return globalProperties[key];
      }
    } else ;
  },
  set({ _: instance }, key, value) {
    const { data, setupState, ctx } = instance;
    if (hasSetupBinding(setupState, key)) {
      setupState[key] = value;
      return true;
    } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
      data[key] = value;
      return true;
    } else if (hasOwn(instance.props, key)) {
      return false;
    }
    if (key[0] === "$" && key.slice(1) in instance) {
      return false;
    } else {
      {
        ctx[key] = value;
      }
    }
    return true;
  },
  has({
    _: { data, setupState, accessCache, ctx, appContext, propsOptions }
  }, key) {
    let normalizedProps;
    return !!accessCache[key] || data !== EMPTY_OBJ && hasOwn(data, key) || hasSetupBinding(setupState, key) || (normalizedProps = propsOptions[0]) && hasOwn(normalizedProps, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key);
  },
  defineProperty(target, key, descriptor) {
    if (descriptor.get != null) {
      target._.accessCache[key] = 0;
    } else if (hasOwn(descriptor, "value")) {
      this.set(target, key, descriptor.value, null);
    }
    return Reflect.defineProperty(target, key, descriptor);
  }
};
function useSlots() {
  return getContext().slots;
}
function useAttrs() {
  return getContext().attrs;
}
function getContext() {
  const i = getCurrentInstance();
  return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
  return isArray(props) ? props.reduce(
    (normalized, p2) => (normalized[p2] = null, normalized),
    {}
  ) : props;
}
let shouldCacheAccess = true;
function applyOptions(instance) {
  const options = resolveMergedOptions(instance);
  const publicThis = instance.proxy;
  const ctx = instance.ctx;
  shouldCacheAccess = false;
  if (options.beforeCreate) {
    callHook(options.beforeCreate, instance, "bc");
  }
  const {
    // state
    data: dataOptions,
    computed: computedOptions,
    methods,
    watch: watchOptions,
    provide: provideOptions,
    inject: injectOptions,
    // lifecycle
    created,
    beforeMount,
    mounted,
    beforeUpdate,
    updated,
    activated,
    deactivated,
    beforeDestroy,
    beforeUnmount,
    destroyed,
    unmounted,
    render,
    renderTracked,
    renderTriggered,
    errorCaptured,
    serverPrefetch,
    // public API
    expose,
    inheritAttrs,
    // assets
    components: components2,
    directives,
    filters
  } = options;
  const checkDuplicateProperties = null;
  if (injectOptions) {
    resolveInjections(injectOptions, ctx, checkDuplicateProperties);
  }
  if (methods) {
    for (const key in methods) {
      const methodHandler = methods[key];
      if (isFunction$1(methodHandler)) {
        {
          ctx[key] = methodHandler.bind(publicThis);
        }
      }
    }
  }
  if (dataOptions) {
    const data = dataOptions.call(publicThis, publicThis);
    if (!isObject(data)) ;
    else {
      instance.data = reactive(data);
    }
  }
  shouldCacheAccess = true;
  if (computedOptions) {
    for (const key in computedOptions) {
      const opt = computedOptions[key];
      const get = isFunction$1(opt) ? opt.bind(publicThis, publicThis) : isFunction$1(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP;
      const set2 = !isFunction$1(opt) && isFunction$1(opt.set) ? opt.set.bind(publicThis) : NOOP;
      const c = computed({
        get,
        set: set2
      });
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => c.value,
        set: (v) => c.value = v
      });
    }
  }
  if (watchOptions) {
    for (const key in watchOptions) {
      createWatcher(watchOptions[key], ctx, publicThis, key);
    }
  }
  if (provideOptions) {
    const provides = isFunction$1(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
    Reflect.ownKeys(provides).forEach((key) => {
      provide(key, provides[key]);
    });
  }
  if (created) {
    callHook(created, instance, "c");
  }
  function registerLifecycleHook(register, hook) {
    if (isArray(hook)) {
      hook.forEach((_hook) => register(_hook.bind(publicThis)));
    } else if (hook) {
      register(hook.bind(publicThis));
    }
  }
  registerLifecycleHook(onBeforeMount, beforeMount);
  registerLifecycleHook(onMounted, mounted);
  registerLifecycleHook(onBeforeUpdate, beforeUpdate);
  registerLifecycleHook(onUpdated, updated);
  registerLifecycleHook(onActivated, activated);
  registerLifecycleHook(onDeactivated, deactivated);
  registerLifecycleHook(onErrorCaptured, errorCaptured);
  registerLifecycleHook(onRenderTracked, renderTracked);
  registerLifecycleHook(onRenderTriggered, renderTriggered);
  registerLifecycleHook(onBeforeUnmount, beforeUnmount);
  registerLifecycleHook(onUnmounted, unmounted);
  registerLifecycleHook(onServerPrefetch, serverPrefetch);
  if (isArray(expose)) {
    if (expose.length) {
      const exposed = instance.exposed || (instance.exposed = {});
      expose.forEach((key) => {
        Object.defineProperty(exposed, key, {
          get: () => publicThis[key],
          set: (val) => publicThis[key] = val
        });
      });
    } else if (!instance.exposed) {
      instance.exposed = {};
    }
  }
  if (render && instance.render === NOOP) {
    instance.render = render;
  }
  if (inheritAttrs != null) {
    instance.inheritAttrs = inheritAttrs;
  }
  if (components2) instance.components = components2;
  if (directives) instance.directives = directives;
  if (serverPrefetch) {
    markAsyncBoundary(instance);
  }
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
  if (isArray(injectOptions)) {
    injectOptions = normalizeInject(injectOptions);
  }
  for (const key in injectOptions) {
    const opt = injectOptions[key];
    let injected;
    if (isObject(opt)) {
      if ("default" in opt) {
        injected = inject(
          opt.from || key,
          opt.default,
          true
        );
      } else {
        injected = inject(opt.from || key);
      }
    } else {
      injected = inject(opt);
    }
    if (isRef(injected)) {
      Object.defineProperty(ctx, key, {
        enumerable: true,
        configurable: true,
        get: () => injected.value,
        set: (v) => injected.value = v
      });
    } else {
      ctx[key] = injected;
    }
  }
}
function callHook(hook, instance, type2) {
  callWithAsyncErrorHandling(
    isArray(hook) ? hook.map((h2) => h2.bind(instance.proxy)) : hook.bind(instance.proxy),
    instance,
    type2
  );
}
function createWatcher(raw, ctx, publicThis, key) {
  let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
  if (isString$1(raw)) {
    const handler = ctx[raw];
    if (isFunction$1(handler)) {
      {
        watch(getter, handler);
      }
    }
  } else if (isFunction$1(raw)) {
    {
      watch(getter, raw.bind(publicThis));
    }
  } else if (isObject(raw)) {
    if (isArray(raw)) {
      raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
    } else {
      const handler = isFunction$1(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
      if (isFunction$1(handler)) {
        watch(getter, handler, raw);
      }
    }
  } else ;
}
function resolveMergedOptions(instance) {
  const base = instance.type;
  const { mixins, extends: extendsOptions } = base;
  const {
    mixins: globalMixins,
    optionsCache: cache,
    config: { optionMergeStrategies }
  } = instance.appContext;
  const cached = cache.get(base);
  let resolved;
  if (cached) {
    resolved = cached;
  } else if (!globalMixins.length && !mixins && !extendsOptions) {
    {
      resolved = base;
    }
  } else {
    resolved = {};
    if (globalMixins.length) {
      globalMixins.forEach(
        (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
      );
    }
    mergeOptions(resolved, base, optionMergeStrategies);
  }
  if (isObject(base)) {
    cache.set(base, resolved);
  }
  return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
  const { mixins, extends: extendsOptions } = from;
  if (extendsOptions) {
    mergeOptions(to, extendsOptions, strats, true);
  }
  if (mixins) {
    mixins.forEach(
      (m) => mergeOptions(to, m, strats, true)
    );
  }
  for (const key in from) {
    if (asMixin && key === "expose") ;
    else {
      const strat = internalOptionMergeStrats[key] || strats && strats[key];
      to[key] = strat ? strat(to[key], from[key]) : from[key];
    }
  }
  return to;
}
const internalOptionMergeStrats = {
  data: mergeDataFn,
  props: mergeEmitsOrPropsOptions,
  emits: mergeEmitsOrPropsOptions,
  // objects
  methods: mergeObjectOptions,
  computed: mergeObjectOptions,
  // lifecycle
  beforeCreate: mergeAsArray,
  created: mergeAsArray,
  beforeMount: mergeAsArray,
  mounted: mergeAsArray,
  beforeUpdate: mergeAsArray,
  updated: mergeAsArray,
  beforeDestroy: mergeAsArray,
  beforeUnmount: mergeAsArray,
  destroyed: mergeAsArray,
  unmounted: mergeAsArray,
  activated: mergeAsArray,
  deactivated: mergeAsArray,
  errorCaptured: mergeAsArray,
  serverPrefetch: mergeAsArray,
  // assets
  components: mergeObjectOptions,
  directives: mergeObjectOptions,
  // watch
  watch: mergeWatchOptions,
  // provide / inject
  provide: mergeDataFn,
  inject: mergeInject
};
function mergeDataFn(to, from) {
  if (!from) {
    return to;
  }
  if (!to) {
    return from;
  }
  return function mergedDataFn() {
    return extend(
      isFunction$1(to) ? to.call(this, this) : to,
      isFunction$1(from) ? from.call(this, this) : from
    );
  };
}
function mergeInject(to, from) {
  return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
  if (isArray(raw)) {
    const res = {};
    for (let i = 0; i < raw.length; i++) {
      res[raw[i]] = raw[i];
    }
    return res;
  }
  return raw;
}
function mergeAsArray(to, from) {
  return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
  return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
  if (to) {
    if (isArray(to) && isArray(from)) {
      return [.../* @__PURE__ */ new Set([...to, ...from])];
    }
    return extend(
      /* @__PURE__ */ Object.create(null),
      normalizePropsOrEmits(to),
      normalizePropsOrEmits(from != null ? from : {})
    );
  } else {
    return from;
  }
}
function mergeWatchOptions(to, from) {
  if (!to) return from;
  if (!from) return to;
  const merged = extend(/* @__PURE__ */ Object.create(null), to);
  for (const key in from) {
    merged[key] = mergeAsArray(to[key], from[key]);
  }
  return merged;
}
function createAppContext() {
  return {
    app: null,
    config: {
      isNativeTag: NO,
      performance: false,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
  return function createApp2(rootComponent, rootProps = null) {
    if (!isFunction$1(rootComponent)) {
      rootComponent = extend({}, rootComponent);
    }
    if (rootProps != null && !isObject(rootProps)) {
      rootProps = null;
    }
    const context = createAppContext();
    const installedPlugins = /* @__PURE__ */ new WeakSet();
    const pluginCleanupFns = [];
    let isMounted = false;
    const app = context.app = {
      _uid: uid$1++,
      _component: rootComponent,
      _props: rootProps,
      _container: null,
      _context: context,
      _instance: null,
      version,
      get config() {
        return context.config;
      },
      set config(v) {
      },
      use(plugin, ...options) {
        if (installedPlugins.has(plugin)) ;
        else if (plugin && isFunction$1(plugin.install)) {
          installedPlugins.add(plugin);
          plugin.install(app, ...options);
        } else if (isFunction$1(plugin)) {
          installedPlugins.add(plugin);
          plugin(app, ...options);
        } else ;
        return app;
      },
      mixin(mixin) {
        {
          if (!context.mixins.includes(mixin)) {
            context.mixins.push(mixin);
          }
        }
        return app;
      },
      component(name, component) {
        if (!component) {
          return context.components[name];
        }
        context.components[name] = component;
        return app;
      },
      directive(name, directive) {
        if (!directive) {
          return context.directives[name];
        }
        context.directives[name] = directive;
        return app;
      },
      mount(rootContainer, isHydrate, namespace) {
        if (!isMounted) {
          const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
          vnode.appContext = context;
          if (namespace === true) {
            namespace = "svg";
          } else if (namespace === false) {
            namespace = void 0;
          }
          {
            render(vnode, rootContainer, namespace);
          }
          isMounted = true;
          app._container = rootContainer;
          rootContainer.__vue_app__ = app;
          return getComponentPublicInstance(vnode.component);
        }
      },
      onUnmount(cleanupFn) {
        pluginCleanupFns.push(cleanupFn);
      },
      unmount() {
        if (isMounted) {
          callWithAsyncErrorHandling(
            pluginCleanupFns,
            app._instance,
            16
          );
          render(null, app._container);
          delete app._container.__vue_app__;
        }
      },
      provide(key, value) {
        context.provides[key] = value;
        return app;
      },
      runWithContext(fn) {
        const lastApp = currentApp;
        currentApp = app;
        try {
          return fn();
        } finally {
          currentApp = lastApp;
        }
      }
    };
    return app;
  };
}
let currentApp = null;
function provide(key, value) {
  if (!currentInstance) ;
  else {
    let provides = currentInstance.provides;
    const parentProvides = currentInstance.parent && currentInstance.parent.provides;
    if (parentProvides === provides) {
      provides = currentInstance.provides = Object.create(parentProvides);
    }
    provides[key] = value;
  }
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
  const instance = currentInstance || currentRenderingInstance;
  if (instance || currentApp) {
    const provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
    if (provides && key in provides) {
      return provides[key];
    } else if (arguments.length > 1) {
      return treatDefaultAsFactory && isFunction$1(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
    } else ;
  }
}
const internalObjectProto = {};
const createInternalObject = () => Object.create(internalObjectProto);
const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
function initProps(instance, rawProps, isStateful, isSSR = false) {
  const props = {};
  const attrs = createInternalObject();
  instance.propsDefaults = /* @__PURE__ */ Object.create(null);
  setFullProps(instance, rawProps, props, attrs);
  for (const key in instance.propsOptions[0]) {
    if (!(key in props)) {
      props[key] = void 0;
    }
  }
  if (isStateful) {
    instance.props = isSSR ? props : shallowReactive(props);
  } else {
    if (!instance.type.props) {
      instance.props = attrs;
    } else {
      instance.props = props;
    }
  }
  instance.attrs = attrs;
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
  const {
    props,
    attrs,
    vnode: { patchFlag }
  } = instance;
  const rawCurrentProps = toRaw(props);
  const [options] = instance.propsOptions;
  let hasAttrsChanged = false;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (optimized || patchFlag > 0) && !(patchFlag & 16)
  ) {
    if (patchFlag & 8) {
      const propsToUpdate = instance.vnode.dynamicProps;
      for (let i = 0; i < propsToUpdate.length; i++) {
        let key = propsToUpdate[i];
        if (isEmitListener(instance.emitsOptions, key)) {
          continue;
        }
        const value = rawProps[key];
        if (options) {
          if (hasOwn(attrs, key)) {
            if (value !== attrs[key]) {
              attrs[key] = value;
              hasAttrsChanged = true;
            }
          } else {
            const camelizedKey = camelize(key);
            props[camelizedKey] = resolvePropValue(
              options,
              rawCurrentProps,
              camelizedKey,
              value,
              instance,
              false
            );
          }
        } else {
          if (value !== attrs[key]) {
            attrs[key] = value;
            hasAttrsChanged = true;
          }
        }
      }
    }
  } else {
    if (setFullProps(instance, rawProps, props, attrs)) {
      hasAttrsChanged = true;
    }
    let kebabKey;
    for (const key in rawCurrentProps) {
      if (!rawProps || // for camelCase
      !hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
        if (options) {
          if (rawPrevProps && // for camelCase
          (rawPrevProps[key] !== void 0 || // for kebab-case
          rawPrevProps[kebabKey] !== void 0)) {
            props[key] = resolvePropValue(
              options,
              rawCurrentProps,
              key,
              void 0,
              instance,
              true
            );
          }
        } else {
          delete props[key];
        }
      }
    }
    if (attrs !== rawCurrentProps) {
      for (const key in attrs) {
        if (!rawProps || !hasOwn(rawProps, key) && true) {
          delete attrs[key];
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (hasAttrsChanged) {
    trigger(instance.attrs, "set", "");
  }
}
function setFullProps(instance, rawProps, props, attrs) {
  const [options, needCastKeys] = instance.propsOptions;
  let hasAttrsChanged = false;
  let rawCastValues;
  if (rawProps) {
    for (let key in rawProps) {
      if (isReservedProp(key)) {
        continue;
      }
      const value = rawProps[key];
      let camelKey;
      if (options && hasOwn(options, camelKey = camelize(key))) {
        if (!needCastKeys || !needCastKeys.includes(camelKey)) {
          props[camelKey] = value;
        } else {
          (rawCastValues || (rawCastValues = {}))[camelKey] = value;
        }
      } else if (!isEmitListener(instance.emitsOptions, key)) {
        if (!(key in attrs) || value !== attrs[key]) {
          attrs[key] = value;
          hasAttrsChanged = true;
        }
      }
    }
  }
  if (needCastKeys) {
    const rawCurrentProps = toRaw(props);
    const castValues = rawCastValues || EMPTY_OBJ;
    for (let i = 0; i < needCastKeys.length; i++) {
      const key = needCastKeys[i];
      props[key] = resolvePropValue(
        options,
        rawCurrentProps,
        key,
        castValues[key],
        instance,
        !hasOwn(castValues, key)
      );
    }
  }
  return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
  const opt = options[key];
  if (opt != null) {
    const hasDefault = hasOwn(opt, "default");
    if (hasDefault && value === void 0) {
      const defaultValue = opt.default;
      if (opt.type !== Function && !opt.skipFactory && isFunction$1(defaultValue)) {
        const { propsDefaults } = instance;
        if (key in propsDefaults) {
          value = propsDefaults[key];
        } else {
          const reset = setCurrentInstance(instance);
          value = propsDefaults[key] = defaultValue.call(
            null,
            props
          );
          reset();
        }
      } else {
        value = defaultValue;
      }
      if (instance.ce) {
        instance.ce._setProp(key, value);
      }
    }
    if (opt[
      0
      /* shouldCast */
    ]) {
      if (isAbsent && !hasDefault) {
        value = false;
      } else if (opt[
        1
        /* shouldCastTrue */
      ] && (value === "" || value === hyphenate(key))) {
        value = true;
      }
    }
  }
  return value;
}
const mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
  const cache = asMixin ? mixinPropsCache : appContext.propsCache;
  const cached = cache.get(comp);
  if (cached) {
    return cached;
  }
  const raw = comp.props;
  const normalized = {};
  const needCastKeys = [];
  let hasExtends = false;
  if (!isFunction$1(comp)) {
    const extendProps = (raw2) => {
      hasExtends = true;
      const [props, keys] = normalizePropsOptions(raw2, appContext, true);
      extend(normalized, props);
      if (keys) needCastKeys.push(...keys);
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendProps);
    }
    if (comp.extends) {
      extendProps(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendProps);
    }
  }
  if (!raw && !hasExtends) {
    if (isObject(comp)) {
      cache.set(comp, EMPTY_ARR);
    }
    return EMPTY_ARR;
  }
  if (isArray(raw)) {
    for (let i = 0; i < raw.length; i++) {
      const normalizedKey = camelize(raw[i]);
      if (validatePropName(normalizedKey)) {
        normalized[normalizedKey] = EMPTY_OBJ;
      }
    }
  } else if (raw) {
    for (const key in raw) {
      const normalizedKey = camelize(key);
      if (validatePropName(normalizedKey)) {
        const opt = raw[key];
        const prop = normalized[normalizedKey] = isArray(opt) || isFunction$1(opt) ? { type: opt } : extend({}, opt);
        const propType = prop.type;
        let shouldCast = false;
        let shouldCastTrue = true;
        if (isArray(propType)) {
          for (let index2 = 0; index2 < propType.length; ++index2) {
            const type2 = propType[index2];
            const typeName = isFunction$1(type2) && type2.name;
            if (typeName === "Boolean") {
              shouldCast = true;
              break;
            } else if (typeName === "String") {
              shouldCastTrue = false;
            }
          }
        } else {
          shouldCast = isFunction$1(propType) && propType.name === "Boolean";
        }
        prop[
          0
          /* shouldCast */
        ] = shouldCast;
        prop[
          1
          /* shouldCastTrue */
        ] = shouldCastTrue;
        if (shouldCast || hasOwn(prop, "default")) {
          needCastKeys.push(normalizedKey);
        }
      }
    }
  }
  const res = [normalized, needCastKeys];
  if (isObject(comp)) {
    cache.set(comp, res);
  }
  return res;
}
function validatePropName(key) {
  if (key[0] !== "$" && !isReservedProp(key)) {
    return true;
  }
  return false;
}
const isInternalKey = (key) => key[0] === "_" || key === "$stable";
const normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
const normalizeSlot = (key, rawSlot, ctx) => {
  if (rawSlot._n) {
    return rawSlot;
  }
  const normalized = withCtx((...args) => {
    if (false) ;
    return normalizeSlotValue(rawSlot(...args));
  }, ctx);
  normalized._c = false;
  return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance) => {
  const ctx = rawSlots._ctx;
  for (const key in rawSlots) {
    if (isInternalKey(key)) continue;
    const value = rawSlots[key];
    if (isFunction$1(value)) {
      slots[key] = normalizeSlot(key, value, ctx);
    } else if (value != null) {
      const normalized = normalizeSlotValue(value);
      slots[key] = () => normalized;
    }
  }
};
const normalizeVNodeSlots = (instance, children) => {
  const normalized = normalizeSlotValue(children);
  instance.slots.default = () => normalized;
};
const assignSlots = (slots, children, optimized) => {
  for (const key in children) {
    if (optimized || key !== "_") {
      slots[key] = children[key];
    }
  }
};
const initSlots = (instance, children, optimized) => {
  const slots = instance.slots = createInternalObject();
  if (instance.vnode.shapeFlag & 32) {
    const type2 = children._;
    if (type2) {
      assignSlots(slots, children, optimized);
      if (optimized) {
        def(slots, "_", type2, true);
      }
    } else {
      normalizeObjectSlots(children, slots);
    }
  } else if (children) {
    normalizeVNodeSlots(instance, children);
  }
};
const updateSlots = (instance, children, optimized) => {
  const { vnode, slots } = instance;
  let needDeletionCheck = true;
  let deletionComparisonTarget = EMPTY_OBJ;
  if (vnode.shapeFlag & 32) {
    const type2 = children._;
    if (type2) {
      if (optimized && type2 === 1) {
        needDeletionCheck = false;
      } else {
        assignSlots(slots, children, optimized);
      }
    } else {
      needDeletionCheck = !children.$stable;
      normalizeObjectSlots(children, slots);
    }
    deletionComparisonTarget = children;
  } else if (children) {
    normalizeVNodeSlots(instance, children);
    deletionComparisonTarget = { default: 1 };
  }
  if (needDeletionCheck) {
    for (const key in slots) {
      if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
        delete slots[key];
      }
    }
  }
};
const queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
  return baseCreateRenderer(options);
}
function baseCreateRenderer(options, createHydrationFns) {
  const target = getGlobalThis();
  target.__VUE__ = true;
  const {
    insert: hostInsert,
    remove: hostRemove,
    patchProp: hostPatchProp,
    createElement: hostCreateElement,
    createText: hostCreateText,
    createComment: hostCreateComment,
    setText: hostSetText,
    setElementText: hostSetElementText,
    parentNode: hostParentNode,
    nextSibling: hostNextSibling,
    setScopeId: hostSetScopeId = NOOP,
    insertStaticContent: hostInsertStaticContent
  } = options;
  const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!n2.dynamicChildren) => {
    if (n1 === n2) {
      return;
    }
    if (n1 && !isSameVNodeType(n1, n2)) {
      anchor = getNextHostNode(n1);
      unmount(n1, parentComponent, parentSuspense, true);
      n1 = null;
    }
    if (n2.patchFlag === -2) {
      optimized = false;
      n2.dynamicChildren = null;
    }
    const { type: type2, ref: ref3, shapeFlag } = n2;
    switch (type2) {
      case Text:
        processText(n1, n2, container, anchor);
        break;
      case Comment:
        processCommentNode(n1, n2, container, anchor);
        break;
      case Static:
        if (n1 == null) {
          mountStaticNode(n2, container, anchor, namespace);
        }
        break;
      case Fragment:
        processFragment(
          n1,
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        break;
      default:
        if (shapeFlag & 1) {
          processElement(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 6) {
          processComponent(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (shapeFlag & 64) {
          type2.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else if (shapeFlag & 128) {
          type2.process(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized,
            internals
          );
        } else ;
    }
    if (ref3 != null && parentComponent) {
      setRef(ref3, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
    }
  };
  const processText = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateText(n2.children),
        container,
        anchor
      );
    } else {
      const el = n2.el = n1.el;
      if (n2.children !== n1.children) {
        hostSetText(el, n2.children);
      }
    }
  };
  const processCommentNode = (n1, n2, container, anchor) => {
    if (n1 == null) {
      hostInsert(
        n2.el = hostCreateComment(n2.children || ""),
        container,
        anchor
      );
    } else {
      n2.el = n1.el;
    }
  };
  const mountStaticNode = (n2, container, anchor, namespace) => {
    [n2.el, n2.anchor] = hostInsertStaticContent(
      n2.children,
      container,
      anchor,
      namespace,
      n2.el,
      n2.anchor
    );
  };
  const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostInsert(el, container, nextSibling);
      el = next;
    }
    hostInsert(anchor, container, nextSibling);
  };
  const removeStaticNode = ({ el, anchor }) => {
    let next;
    while (el && el !== anchor) {
      next = hostNextSibling(el);
      hostRemove(el);
      el = next;
    }
    hostRemove(anchor);
  };
  const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    if (n2.type === "svg") {
      namespace = "svg";
    } else if (n2.type === "math") {
      namespace = "mathml";
    }
    if (n1 == null) {
      mountElement(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      patchElement(
        n1,
        n2,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
  };
  const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let el;
    let vnodeHook;
    const { props, shapeFlag, transition, dirs } = vnode;
    el = vnode.el = hostCreateElement(
      vnode.type,
      namespace,
      props && props.is,
      props
    );
    if (shapeFlag & 8) {
      hostSetElementText(el, vnode.children);
    } else if (shapeFlag & 16) {
      mountChildren(
        vnode.children,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(vnode, namespace),
        slotScopeIds,
        optimized
      );
    }
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "created");
    }
    setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
    if (props) {
      for (const key in props) {
        if (key !== "value" && !isReservedProp(key)) {
          hostPatchProp(el, key, null, props[key], namespace, parentComponent);
        }
      }
      if ("value" in props) {
        hostPatchProp(el, "value", null, props.value, namespace);
      }
      if (vnodeHook = props.onVnodeBeforeMount) {
        invokeVNodeHook(vnodeHook, parentComponent, vnode);
      }
    }
    if (dirs) {
      invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
    }
    const needCallTransitionHooks = needTransition(parentSuspense, transition);
    if (needCallTransitionHooks) {
      transition.beforeEnter(el);
    }
    hostInsert(el, container, anchor);
    if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
        needCallTransitionHooks && transition.enter(el);
        dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
      }, parentSuspense);
    }
  };
  const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
    if (scopeId) {
      hostSetScopeId(el, scopeId);
    }
    if (slotScopeIds) {
      for (let i = 0; i < slotScopeIds.length; i++) {
        hostSetScopeId(el, slotScopeIds[i]);
      }
    }
    if (parentComponent) {
      let subTree = parentComponent.subTree;
      if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
        const parentVNode = parentComponent.vnode;
        setScopeId(
          el,
          parentVNode,
          parentVNode.scopeId,
          parentVNode.slotScopeIds,
          parentComponent.parent
        );
      }
    }
  };
  const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
    for (let i = start; i < children.length; i++) {
      const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
      patch(
        null,
        child,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
  };
  const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const el = n2.el = n1.el;
    let { patchFlag, dynamicChildren, dirs } = n2;
    patchFlag |= n1.patchFlag & 16;
    const oldProps = n1.props || EMPTY_OBJ;
    const newProps = n2.props || EMPTY_OBJ;
    let vnodeHook;
    parentComponent && toggleRecurse(parentComponent, false);
    if (vnodeHook = newProps.onVnodeBeforeUpdate) {
      invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
    }
    if (dirs) {
      invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
    }
    parentComponent && toggleRecurse(parentComponent, true);
    if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
      hostSetElementText(el, "");
    }
    if (dynamicChildren) {
      patchBlockChildren(
        n1.dynamicChildren,
        dynamicChildren,
        el,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds
      );
    } else if (!optimized) {
      patchChildren(
        n1,
        n2,
        el,
        null,
        parentComponent,
        parentSuspense,
        resolveChildrenNamespace(n2, namespace),
        slotScopeIds,
        false
      );
    }
    if (patchFlag > 0) {
      if (patchFlag & 16) {
        patchProps(el, oldProps, newProps, parentComponent, namespace);
      } else {
        if (patchFlag & 2) {
          if (oldProps.class !== newProps.class) {
            hostPatchProp(el, "class", null, newProps.class, namespace);
          }
        }
        if (patchFlag & 4) {
          hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
        }
        if (patchFlag & 8) {
          const propsToUpdate = n2.dynamicProps;
          for (let i = 0; i < propsToUpdate.length; i++) {
            const key = propsToUpdate[i];
            const prev = oldProps[key];
            const next = newProps[key];
            if (next !== prev || key === "value") {
              hostPatchProp(el, key, prev, next, namespace, parentComponent);
            }
          }
        }
      }
      if (patchFlag & 1) {
        if (n1.children !== n2.children) {
          hostSetElementText(el, n2.children);
        }
      }
    } else if (!optimized && dynamicChildren == null) {
      patchProps(el, oldProps, newProps, parentComponent, namespace);
    }
    if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
        dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
      }, parentSuspense);
    }
  };
  const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
    for (let i = 0; i < newChildren.length; i++) {
      const oldVNode = oldChildren[i];
      const newVNode = newChildren[i];
      const container = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
        oldVNode.shapeFlag & (6 | 64)) ? hostParentNode(oldVNode.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          fallbackContainer
        )
      );
      patch(
        oldVNode,
        newVNode,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        true
      );
    }
  };
  const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
    if (oldProps !== newProps) {
      if (oldProps !== EMPTY_OBJ) {
        for (const key in oldProps) {
          if (!isReservedProp(key) && !(key in newProps)) {
            hostPatchProp(
              el,
              key,
              oldProps[key],
              null,
              namespace,
              parentComponent
            );
          }
        }
      }
      for (const key in newProps) {
        if (isReservedProp(key)) continue;
        const next = newProps[key];
        const prev = oldProps[key];
        if (next !== prev && key !== "value") {
          hostPatchProp(el, key, prev, next, namespace, parentComponent);
        }
      }
      if ("value" in newProps) {
        hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
      }
    }
  };
  const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
    const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
    let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
    if (fragmentSlotScopeIds) {
      slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
    }
    if (n1 == null) {
      hostInsert(fragmentStartAnchor, container, anchor);
      hostInsert(fragmentEndAnchor, container, anchor);
      mountChildren(
        // #10007
        // such fragment like `<></>` will be compiled into
        // a fragment which doesn't have a children.
        // In this case fallback to an empty array
        n2.children || [],
        container,
        fragmentEndAnchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    } else {
      if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
      // of renderSlot() with no valid children
      n1.dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          container,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds
        );
        if (
          // #2080 if the stable fragment has a key, it's a <template v-for> that may
          //  get moved around. Make sure all root level vnodes inherit el.
          // #2134 or if it's a component root, it may also get moved around
          // as the component is being moved.
          n2.key != null || parentComponent && n2 === parentComponent.subTree
        ) {
          traverseStaticChildren(
            n1,
            n2,
            true
            /* shallow */
          );
        }
      } else {
        patchChildren(
          n1,
          n2,
          container,
          fragmentEndAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    }
  };
  const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    n2.slotScopeIds = slotScopeIds;
    if (n1 == null) {
      if (n2.shapeFlag & 512) {
        parentComponent.ctx.activate(
          n2,
          container,
          anchor,
          namespace,
          optimized
        );
      } else {
        mountComponent(
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          optimized
        );
      }
    } else {
      updateComponent(n1, n2, optimized);
    }
  };
  const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
    const instance = initialVNode.component = createComponentInstance(
      initialVNode,
      parentComponent,
      parentSuspense
    );
    if (isKeepAlive(initialVNode)) {
      instance.ctx.renderer = internals;
    }
    {
      setupComponent(instance, false, optimized);
    }
    if (instance.asyncDep) {
      parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
      if (!initialVNode.el) {
        const placeholder = instance.subTree = createVNode(Comment);
        processCommentNode(null, placeholder, container, anchor);
      }
    } else {
      setupRenderEffect(
        instance,
        initialVNode,
        container,
        anchor,
        parentSuspense,
        namespace,
        optimized
      );
    }
  };
  const updateComponent = (n1, n2, optimized) => {
    const instance = n2.component = n1.component;
    if (shouldUpdateComponent(n1, n2, optimized)) {
      if (instance.asyncDep && !instance.asyncResolved) {
        updateComponentPreRender(instance, n2, optimized);
        return;
      } else {
        instance.next = n2;
        instance.update();
      }
    } else {
      n2.el = n1.el;
      instance.vnode = n2;
    }
  };
  const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
    const componentUpdateFn = () => {
      if (!instance.isMounted) {
        let vnodeHook;
        const { el, props } = initialVNode;
        const { bm, m, parent, root, type: type2 } = instance;
        const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
        toggleRecurse(instance, false);
        if (bm) {
          invokeArrayFns(bm);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
          invokeVNodeHook(vnodeHook, parent, initialVNode);
        }
        toggleRecurse(instance, true);
        {
          if (root.ce) {
            root.ce._injectChildStyle(type2);
          }
          const subTree = instance.subTree = renderComponentRoot(instance);
          patch(
            null,
            subTree,
            container,
            anchor,
            instance,
            parentSuspense,
            namespace
          );
          initialVNode.el = subTree.el;
        }
        if (m) {
          queuePostRenderEffect(m, parentSuspense);
        }
        if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
          const scopedInitialVNode = initialVNode;
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode),
            parentSuspense
          );
        }
        if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
          instance.a && queuePostRenderEffect(instance.a, parentSuspense);
        }
        instance.isMounted = true;
        initialVNode = container = anchor = null;
      } else {
        let { next, bu, u, parent, vnode } = instance;
        {
          const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
          if (nonHydratedAsyncRoot) {
            if (next) {
              next.el = vnode.el;
              updateComponentPreRender(instance, next, optimized);
            }
            nonHydratedAsyncRoot.asyncDep.then(() => {
              if (!instance.isUnmounted) {
                componentUpdateFn();
              }
            });
            return;
          }
        }
        let originNext = next;
        let vnodeHook;
        toggleRecurse(instance, false);
        if (next) {
          next.el = vnode.el;
          updateComponentPreRender(instance, next, optimized);
        } else {
          next = vnode;
        }
        if (bu) {
          invokeArrayFns(bu);
        }
        if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
          invokeVNodeHook(vnodeHook, parent, next, vnode);
        }
        toggleRecurse(instance, true);
        const nextTree = renderComponentRoot(instance);
        const prevTree = instance.subTree;
        instance.subTree = nextTree;
        patch(
          prevTree,
          nextTree,
          // parent may have changed if it's in a teleport
          hostParentNode(prevTree.el),
          // anchor may have changed if it's in a fragment
          getNextHostNode(prevTree),
          instance,
          parentSuspense,
          namespace
        );
        next.el = nextTree.el;
        if (originNext === null) {
          updateHOCHostEl(instance, nextTree.el);
        }
        if (u) {
          queuePostRenderEffect(u, parentSuspense);
        }
        if (vnodeHook = next.props && next.props.onVnodeUpdated) {
          queuePostRenderEffect(
            () => invokeVNodeHook(vnodeHook, parent, next, vnode),
            parentSuspense
          );
        }
      }
    };
    instance.scope.on();
    const effect2 = instance.effect = new ReactiveEffect(componentUpdateFn);
    instance.scope.off();
    const update = instance.update = effect2.run.bind(effect2);
    const job = instance.job = effect2.runIfDirty.bind(effect2);
    job.i = instance;
    job.id = instance.uid;
    effect2.scheduler = () => queueJob(job);
    toggleRecurse(instance, true);
    update();
  };
  const updateComponentPreRender = (instance, nextVNode, optimized) => {
    nextVNode.component = instance;
    const prevProps = instance.vnode.props;
    instance.vnode = nextVNode;
    instance.next = null;
    updateProps(instance, nextVNode.props, prevProps, optimized);
    updateSlots(instance, nextVNode.children, optimized);
    pauseTracking();
    flushPreFlushCbs(instance);
    resetTracking();
  };
  const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
    const c1 = n1 && n1.children;
    const prevShapeFlag = n1 ? n1.shapeFlag : 0;
    const c2 = n2.children;
    const { patchFlag, shapeFlag } = n2;
    if (patchFlag > 0) {
      if (patchFlag & 128) {
        patchKeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      } else if (patchFlag & 256) {
        patchUnkeyedChildren(
          c1,
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
        return;
      }
    }
    if (shapeFlag & 8) {
      if (prevShapeFlag & 16) {
        unmountChildren(c1, parentComponent, parentSuspense);
      }
      if (c2 !== c1) {
        hostSetElementText(container, c2);
      }
    } else {
      if (prevShapeFlag & 16) {
        if (shapeFlag & 16) {
          patchKeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          unmountChildren(c1, parentComponent, parentSuspense, true);
        }
      } else {
        if (prevShapeFlag & 8) {
          hostSetElementText(container, "");
        }
        if (shapeFlag & 16) {
          mountChildren(
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      }
    }
  };
  const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    c1 = c1 || EMPTY_ARR;
    c2 = c2 || EMPTY_ARR;
    const oldLength = c1.length;
    const newLength = c2.length;
    const commonLength = Math.min(oldLength, newLength);
    let i;
    for (i = 0; i < commonLength; i++) {
      const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      patch(
        c1[i],
        nextChild,
        container,
        null,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized
      );
    }
    if (oldLength > newLength) {
      unmountChildren(
        c1,
        parentComponent,
        parentSuspense,
        true,
        false,
        commonLength
      );
    } else {
      mountChildren(
        c2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        commonLength
      );
    }
  };
  const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
    let i = 0;
    const l2 = c2.length;
    let e1 = c1.length - 1;
    let e2 = l2 - 1;
    while (i <= e1 && i <= e2) {
      const n1 = c1[i];
      const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      i++;
    }
    while (i <= e1 && i <= e2) {
      const n1 = c1[e1];
      const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
      if (isSameVNodeType(n1, n2)) {
        patch(
          n1,
          n2,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        break;
      }
      e1--;
      e2--;
    }
    if (i > e1) {
      if (i <= e2) {
        const nextPos = e2 + 1;
        const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
        while (i <= e2) {
          patch(
            null,
            c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]),
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          i++;
        }
      }
    } else if (i > e2) {
      while (i <= e1) {
        unmount(c1[i], parentComponent, parentSuspense, true);
        i++;
      }
    } else {
      const s1 = i;
      const s2 = i;
      const keyToNewIndexMap = /* @__PURE__ */ new Map();
      for (i = s2; i <= e2; i++) {
        const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        if (nextChild.key != null) {
          keyToNewIndexMap.set(nextChild.key, i);
        }
      }
      let j;
      let patched = 0;
      const toBePatched = e2 - s2 + 1;
      let moved = false;
      let maxNewIndexSoFar = 0;
      const newIndexToOldIndexMap = new Array(toBePatched);
      for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
      for (i = s1; i <= e1; i++) {
        const prevChild = c1[i];
        if (patched >= toBePatched) {
          unmount(prevChild, parentComponent, parentSuspense, true);
          continue;
        }
        let newIndex;
        if (prevChild.key != null) {
          newIndex = keyToNewIndexMap.get(prevChild.key);
        } else {
          for (j = s2; j <= e2; j++) {
            if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
              newIndex = j;
              break;
            }
          }
        }
        if (newIndex === void 0) {
          unmount(prevChild, parentComponent, parentSuspense, true);
        } else {
          newIndexToOldIndexMap[newIndex - s2] = i + 1;
          if (newIndex >= maxNewIndexSoFar) {
            maxNewIndexSoFar = newIndex;
          } else {
            moved = true;
          }
          patch(
            prevChild,
            c2[newIndex],
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          patched++;
        }
      }
      const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
      j = increasingNewIndexSequence.length - 1;
      for (i = toBePatched - 1; i >= 0; i--) {
        const nextIndex = s2 + i;
        const nextChild = c2[nextIndex];
        const anchor = nextIndex + 1 < l2 ? c2[nextIndex + 1].el : parentAnchor;
        if (newIndexToOldIndexMap[i] === 0) {
          patch(
            null,
            nextChild,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else if (moved) {
          if (j < 0 || i !== increasingNewIndexSequence[j]) {
            move(nextChild, container, anchor, 2);
          } else {
            j--;
          }
        }
      }
    }
  };
  const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
    const { el, type: type2, transition, children, shapeFlag } = vnode;
    if (shapeFlag & 6) {
      move(vnode.component.subTree, container, anchor, moveType);
      return;
    }
    if (shapeFlag & 128) {
      vnode.suspense.move(container, anchor, moveType);
      return;
    }
    if (shapeFlag & 64) {
      type2.move(vnode, container, anchor, internals);
      return;
    }
    if (type2 === Fragment) {
      hostInsert(el, container, anchor);
      for (let i = 0; i < children.length; i++) {
        move(children[i], container, anchor, moveType);
      }
      hostInsert(vnode.anchor, container, anchor);
      return;
    }
    if (type2 === Static) {
      moveStaticNode(vnode, container, anchor);
      return;
    }
    const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
    if (needTransition2) {
      if (moveType === 0) {
        transition.beforeEnter(el);
        hostInsert(el, container, anchor);
        queuePostRenderEffect(() => transition.enter(el), parentSuspense);
      } else {
        const { leave, delayLeave, afterLeave } = transition;
        const remove22 = () => hostInsert(el, container, anchor);
        const performLeave = () => {
          leave(el, () => {
            remove22();
            afterLeave && afterLeave();
          });
        };
        if (delayLeave) {
          delayLeave(el, remove22, performLeave);
        } else {
          performLeave();
        }
      }
    } else {
      hostInsert(el, container, anchor);
    }
  };
  const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
    const {
      type: type2,
      props,
      ref: ref3,
      children,
      dynamicChildren,
      shapeFlag,
      patchFlag,
      dirs,
      cacheIndex
    } = vnode;
    if (patchFlag === -2) {
      optimized = false;
    }
    if (ref3 != null) {
      setRef(ref3, null, parentSuspense, vnode, true);
    }
    if (cacheIndex != null) {
      parentComponent.renderCache[cacheIndex] = void 0;
    }
    if (shapeFlag & 256) {
      parentComponent.ctx.deactivate(vnode);
      return;
    }
    const shouldInvokeDirs = shapeFlag & 1 && dirs;
    const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
    let vnodeHook;
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
      invokeVNodeHook(vnodeHook, parentComponent, vnode);
    }
    if (shapeFlag & 6) {
      unmountComponent(vnode.component, parentSuspense, doRemove);
    } else {
      if (shapeFlag & 128) {
        vnode.suspense.unmount(parentSuspense, doRemove);
        return;
      }
      if (shouldInvokeDirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
      }
      if (shapeFlag & 64) {
        vnode.type.remove(
          vnode,
          parentComponent,
          parentSuspense,
          internals,
          doRemove
        );
      } else if (dynamicChildren && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (type2 !== Fragment || patchFlag > 0 && patchFlag & 64)) {
        unmountChildren(
          dynamicChildren,
          parentComponent,
          parentSuspense,
          false,
          true
        );
      } else if (type2 === Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
        unmountChildren(children, parentComponent, parentSuspense);
      }
      if (doRemove) {
        remove2(vnode);
      }
    }
    if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs) {
      queuePostRenderEffect(() => {
        vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
        shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
      }, parentSuspense);
    }
  };
  const remove2 = (vnode) => {
    const { type: type2, el, anchor, transition } = vnode;
    if (type2 === Fragment) {
      {
        removeFragment(el, anchor);
      }
      return;
    }
    if (type2 === Static) {
      removeStaticNode(vnode);
      return;
    }
    const performRemove = () => {
      hostRemove(el);
      if (transition && !transition.persisted && transition.afterLeave) {
        transition.afterLeave();
      }
    };
    if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
      const { leave, delayLeave } = transition;
      const performLeave = () => leave(el, performRemove);
      if (delayLeave) {
        delayLeave(vnode.el, performRemove, performLeave);
      } else {
        performLeave();
      }
    } else {
      performRemove();
    }
  };
  const removeFragment = (cur, end) => {
    let next;
    while (cur !== end) {
      next = hostNextSibling(cur);
      hostRemove(cur);
      cur = next;
    }
    hostRemove(end);
  };
  const unmountComponent = (instance, parentSuspense, doRemove) => {
    const { bum, scope, job, subTree, um, m, a } = instance;
    invalidateMount(m);
    invalidateMount(a);
    if (bum) {
      invokeArrayFns(bum);
    }
    scope.stop();
    if (job) {
      job.flags |= 8;
      unmount(subTree, instance, parentSuspense, doRemove);
    }
    if (um) {
      queuePostRenderEffect(um, parentSuspense);
    }
    queuePostRenderEffect(() => {
      instance.isUnmounted = true;
    }, parentSuspense);
    if (parentSuspense && parentSuspense.pendingBranch && !parentSuspense.isUnmounted && instance.asyncDep && !instance.asyncResolved && instance.suspenseId === parentSuspense.pendingId) {
      parentSuspense.deps--;
      if (parentSuspense.deps === 0) {
        parentSuspense.resolve();
      }
    }
  };
  const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
    for (let i = start; i < children.length; i++) {
      unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
    }
  };
  const getNextHostNode = (vnode) => {
    if (vnode.shapeFlag & 6) {
      return getNextHostNode(vnode.component.subTree);
    }
    if (vnode.shapeFlag & 128) {
      return vnode.suspense.next();
    }
    const el = hostNextSibling(vnode.anchor || vnode.el);
    const teleportEnd = el && el[TeleportEndKey];
    return teleportEnd ? hostNextSibling(teleportEnd) : el;
  };
  let isFlushing = false;
  const render = (vnode, container, namespace) => {
    if (vnode == null) {
      if (container._vnode) {
        unmount(container._vnode, null, null, true);
      }
    } else {
      patch(
        container._vnode || null,
        vnode,
        container,
        null,
        null,
        null,
        namespace
      );
    }
    container._vnode = vnode;
    if (!isFlushing) {
      isFlushing = true;
      flushPreFlushCbs();
      flushPostFlushCbs();
      isFlushing = false;
    }
  };
  const internals = {
    p: patch,
    um: unmount,
    m: move,
    r: remove2,
    mt: mountComponent,
    mc: mountChildren,
    pc: patchChildren,
    pbc: patchBlockChildren,
    n: getNextHostNode,
    o: options
  };
  let hydrate;
  return {
    render,
    hydrate,
    createApp: createAppAPI(render)
  };
}
function resolveChildrenNamespace({ type: type2, props }, currentNamespace) {
  return currentNamespace === "svg" && type2 === "foreignObject" || currentNamespace === "mathml" && type2 === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
}
function toggleRecurse({ effect: effect2, job }, allowed) {
  if (allowed) {
    effect2.flags |= 32;
    job.flags |= 4;
  } else {
    effect2.flags &= -33;
    job.flags &= -5;
  }
}
function needTransition(parentSuspense, transition) {
  return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
  const ch1 = n1.children;
  const ch2 = n2.children;
  if (isArray(ch1) && isArray(ch2)) {
    for (let i = 0; i < ch1.length; i++) {
      const c1 = ch1[i];
      let c2 = ch2[i];
      if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
        if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
          c2 = ch2[i] = cloneIfMounted(ch2[i]);
          c2.el = c1.el;
        }
        if (!shallow && c2.patchFlag !== -2)
          traverseStaticChildren(c1, c2);
      }
      if (c2.type === Text) {
        c2.el = c1.el;
      }
    }
  }
}
function getSequence(arr) {
  const p2 = arr.slice();
  const result = [0];
  let i, j, u, v, c;
  const len = arr.length;
  for (i = 0; i < len; i++) {
    const arrI = arr[i];
    if (arrI !== 0) {
      j = result[result.length - 1];
      if (arr[j] < arrI) {
        p2[i] = j;
        result.push(i);
        continue;
      }
      u = 0;
      v = result.length - 1;
      while (u < v) {
        c = u + v >> 1;
        if (arr[result[c]] < arrI) {
          u = c + 1;
        } else {
          v = c;
        }
      }
      if (arrI < arr[result[u]]) {
        if (u > 0) {
          p2[i] = result[u - 1];
        }
        result[u] = i;
      }
    }
  }
  u = result.length;
  v = result[u - 1];
  while (u-- > 0) {
    result[u] = v;
    v = p2[v];
  }
  return result;
}
function locateNonHydratedAsyncRoot(instance) {
  const subComponent = instance.subTree.component;
  if (subComponent) {
    if (subComponent.asyncDep && !subComponent.asyncResolved) {
      return subComponent;
    } else {
      return locateNonHydratedAsyncRoot(subComponent);
    }
  }
}
function invalidateMount(hooks) {
  if (hooks) {
    for (let i = 0; i < hooks.length; i++)
      hooks[i].flags |= 8;
  }
}
const ssrContextKey = Symbol.for("v-scx");
const useSSRContext = () => {
  {
    const ctx = inject(ssrContextKey);
    return ctx;
  }
};
function watchEffect(effect2, options) {
  return doWatch(effect2, null, options);
}
function watch(source, cb, options) {
  return doWatch(source, cb, options);
}
function doWatch(source, cb, options = EMPTY_OBJ) {
  const { immediate, deep, flush, once } = options;
  const baseWatchOptions = extend({}, options);
  const runsImmediately = cb && immediate || !cb && flush !== "post";
  let ssrCleanup;
  if (isInSSRComponentSetup) {
    if (flush === "sync") {
      const ctx = useSSRContext();
      ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
    } else if (!runsImmediately) {
      const watchStopHandle = () => {
      };
      watchStopHandle.stop = NOOP;
      watchStopHandle.resume = NOOP;
      watchStopHandle.pause = NOOP;
      return watchStopHandle;
    }
  }
  const instance = currentInstance;
  baseWatchOptions.call = (fn, type2, args) => callWithAsyncErrorHandling(fn, instance, type2, args);
  let isPre = false;
  if (flush === "post") {
    baseWatchOptions.scheduler = (job) => {
      queuePostRenderEffect(job, instance && instance.suspense);
    };
  } else if (flush !== "sync") {
    isPre = true;
    baseWatchOptions.scheduler = (job, isFirstRun) => {
      if (isFirstRun) {
        job();
      } else {
        queueJob(job);
      }
    };
  }
  baseWatchOptions.augmentJob = (job) => {
    if (cb) {
      job.flags |= 4;
    }
    if (isPre) {
      job.flags |= 2;
      if (instance) {
        job.id = instance.uid;
        job.i = instance;
      }
    }
  };
  const watchHandle = watch$1(source, cb, baseWatchOptions);
  if (isInSSRComponentSetup) {
    if (ssrCleanup) {
      ssrCleanup.push(watchHandle);
    } else if (runsImmediately) {
      watchHandle();
    }
  }
  return watchHandle;
}
function instanceWatch(source, value, options) {
  const publicThis = this.proxy;
  const getter = isString$1(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
  let cb;
  if (isFunction$1(value)) {
    cb = value;
  } else {
    cb = value.handler;
    options = value;
  }
  const reset = setCurrentInstance(this);
  const res = doWatch(getter, cb.bind(publicThis), options);
  reset();
  return res;
}
function createPathGetter(ctx, path) {
  const segments = path.split(".");
  return () => {
    let cur = ctx;
    for (let i = 0; i < segments.length && cur; i++) {
      cur = cur[segments[i]];
    }
    return cur;
  };
}
const getModelModifiers = (props, modelName) => {
  return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
};
function emit(instance, event, ...rawArgs) {
  if (instance.isUnmounted) return;
  const props = instance.vnode.props || EMPTY_OBJ;
  let args = rawArgs;
  const isModelListener2 = event.startsWith("update:");
  const modifiers = isModelListener2 && getModelModifiers(props, event.slice(7));
  if (modifiers) {
    if (modifiers.trim) {
      args = rawArgs.map((a) => isString$1(a) ? a.trim() : a);
    }
    if (modifiers.number) {
      args = rawArgs.map(looseToNumber);
    }
  }
  let handlerName;
  let handler = props[handlerName = toHandlerKey(event)] || // also try camelCase event handler (#2249)
  props[handlerName = toHandlerKey(camelize(event))];
  if (!handler && isModelListener2) {
    handler = props[handlerName = toHandlerKey(hyphenate(event))];
  }
  if (handler) {
    callWithAsyncErrorHandling(
      handler,
      instance,
      6,
      args
    );
  }
  const onceHandler = props[handlerName + `Once`];
  if (onceHandler) {
    if (!instance.emitted) {
      instance.emitted = {};
    } else if (instance.emitted[handlerName]) {
      return;
    }
    instance.emitted[handlerName] = true;
    callWithAsyncErrorHandling(
      onceHandler,
      instance,
      6,
      args
    );
  }
}
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
  const cache = appContext.emitsCache;
  const cached = cache.get(comp);
  if (cached !== void 0) {
    return cached;
  }
  const raw = comp.emits;
  let normalized = {};
  let hasExtends = false;
  if (!isFunction$1(comp)) {
    const extendEmits = (raw2) => {
      const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
      if (normalizedFromExtend) {
        hasExtends = true;
        extend(normalized, normalizedFromExtend);
      }
    };
    if (!asMixin && appContext.mixins.length) {
      appContext.mixins.forEach(extendEmits);
    }
    if (comp.extends) {
      extendEmits(comp.extends);
    }
    if (comp.mixins) {
      comp.mixins.forEach(extendEmits);
    }
  }
  if (!raw && !hasExtends) {
    if (isObject(comp)) {
      cache.set(comp, null);
    }
    return null;
  }
  if (isArray(raw)) {
    raw.forEach((key) => normalized[key] = null);
  } else {
    extend(normalized, raw);
  }
  if (isObject(comp)) {
    cache.set(comp, normalized);
  }
  return normalized;
}
function isEmitListener(options, key) {
  if (!options || !isOn(key)) {
    return false;
  }
  key = key.slice(2).replace(/Once$/, "");
  return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
}
function markAttrsAccessed() {
}
function renderComponentRoot(instance) {
  const {
    type: Component,
    vnode,
    proxy,
    withProxy,
    propsOptions: [propsOptions],
    slots,
    attrs,
    emit: emit2,
    render,
    renderCache,
    props,
    data,
    setupState,
    ctx,
    inheritAttrs
  } = instance;
  const prev = setCurrentRenderingInstance(instance);
  let result;
  let fallthroughAttrs;
  try {
    if (vnode.shapeFlag & 4) {
      const proxyToUse = withProxy || proxy;
      const thisProxy = false ? new Proxy(proxyToUse, {
        get(target, key, receiver) {
          warn$1(
            `Property '${String(
              key
            )}' was accessed via 'this'. Avoid using 'this' in templates.`
          );
          return Reflect.get(target, key, receiver);
        }
      }) : proxyToUse;
      result = normalizeVNode(
        render.call(
          thisProxy,
          proxyToUse,
          renderCache,
          false ? shallowReadonly(props) : props,
          setupState,
          data,
          ctx
        )
      );
      fallthroughAttrs = attrs;
    } else {
      const render2 = Component;
      if (false) ;
      result = normalizeVNode(
        render2.length > 1 ? render2(
          false ? shallowReadonly(props) : props,
          false ? {
            get attrs() {
              markAttrsAccessed();
              return shallowReadonly(attrs);
            },
            slots,
            emit: emit2
          } : { attrs, slots, emit: emit2 }
        ) : render2(
          false ? shallowReadonly(props) : props,
          null
        )
      );
      fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
    }
  } catch (err) {
    blockStack.length = 0;
    handleError(err, instance, 1);
    result = createVNode(Comment);
  }
  let root = result;
  if (fallthroughAttrs && inheritAttrs !== false) {
    const keys = Object.keys(fallthroughAttrs);
    const { shapeFlag } = root;
    if (keys.length) {
      if (shapeFlag & (1 | 6)) {
        if (propsOptions && keys.some(isModelListener)) {
          fallthroughAttrs = filterModelListeners(
            fallthroughAttrs,
            propsOptions
          );
        }
        root = cloneVNode(root, fallthroughAttrs, false, true);
      }
    }
  }
  if (vnode.dirs) {
    root = cloneVNode(root, null, false, true);
    root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
  }
  if (vnode.transition) {
    setTransitionHooks(root, vnode.transition);
  }
  {
    result = root;
  }
  setCurrentRenderingInstance(prev);
  return result;
}
function filterSingleRoot(children, recurse = true) {
  let singleRoot;
  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    if (isVNode(child)) {
      if (child.type !== Comment || child.children === "v-if") {
        if (singleRoot) {
          return;
        } else {
          singleRoot = child;
        }
      }
    } else {
      return;
    }
  }
  return singleRoot;
}
const getFunctionalFallthrough = (attrs) => {
  let res;
  for (const key in attrs) {
    if (key === "class" || key === "style" || isOn(key)) {
      (res || (res = {}))[key] = attrs[key];
    }
  }
  return res;
};
const filterModelListeners = (attrs, props) => {
  const res = {};
  for (const key in attrs) {
    if (!isModelListener(key) || !(key.slice(9) in props)) {
      res[key] = attrs[key];
    }
  }
  return res;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
  const { props: prevProps, children: prevChildren, component } = prevVNode;
  const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
  const emits = component.emitsOptions;
  if (nextVNode.dirs || nextVNode.transition) {
    return true;
  }
  if (optimized && patchFlag >= 0) {
    if (patchFlag & 1024) {
      return true;
    }
    if (patchFlag & 16) {
      if (!prevProps) {
        return !!nextProps;
      }
      return hasPropsChanged(prevProps, nextProps, emits);
    } else if (patchFlag & 8) {
      const dynamicProps = nextVNode.dynamicProps;
      for (let i = 0; i < dynamicProps.length; i++) {
        const key = dynamicProps[i];
        if (nextProps[key] !== prevProps[key] && !isEmitListener(emits, key)) {
          return true;
        }
      }
    }
  } else {
    if (prevChildren || nextChildren) {
      if (!nextChildren || !nextChildren.$stable) {
        return true;
      }
    }
    if (prevProps === nextProps) {
      return false;
    }
    if (!prevProps) {
      return !!nextProps;
    }
    if (!nextProps) {
      return true;
    }
    return hasPropsChanged(prevProps, nextProps, emits);
  }
  return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
  const nextKeys = Object.keys(nextProps);
  if (nextKeys.length !== Object.keys(prevProps).length) {
    return true;
  }
  for (let i = 0; i < nextKeys.length; i++) {
    const key = nextKeys[i];
    if (nextProps[key] !== prevProps[key] && !isEmitListener(emitsOptions, key)) {
      return true;
    }
  }
  return false;
}
function updateHOCHostEl({ vnode, parent }, el) {
  while (parent) {
    const root = parent.subTree;
    if (root.suspense && root.suspense.activeBranch === vnode) {
      root.el = vnode.el;
    }
    if (root === vnode) {
      (vnode = parent.vnode).el = el;
      parent = parent.parent;
    } else {
      break;
    }
  }
}
const isSuspense = (type2) => type2.__isSuspense;
let suspenseId = 0;
const SuspenseImpl = {
  name: "Suspense",
  // In order to make Suspense tree-shakable, we need to avoid importing it
  // directly in the renderer. The renderer checks for the __isSuspense flag
  // on a vnode's type and calls the `process` method, passing in renderer
  // internals.
  __isSuspense: true,
  process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
    if (n1 == null) {
      mountSuspense(
        n2,
        container,
        anchor,
        parentComponent,
        parentSuspense,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    } else {
      if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback) {
        n2.suspense = n1.suspense;
        n2.suspense.vnode = n2;
        n2.el = n1.el;
        return;
      }
      patchSuspense(
        n1,
        n2,
        container,
        anchor,
        parentComponent,
        namespace,
        slotScopeIds,
        optimized,
        rendererInternals
      );
    }
  },
  hydrate: hydrateSuspense,
  normalize: normalizeSuspenseChildren
};
const Suspense = SuspenseImpl;
function triggerEvent$1(vnode, name) {
  const eventListener = vnode.props && vnode.props[name];
  if (isFunction$1(eventListener)) {
    eventListener();
  }
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
  const {
    p: patch,
    o: { createElement }
  } = rendererInternals;
  const hiddenContainer = createElement("div");
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    container,
    hiddenContainer,
    anchor,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals
  );
  patch(
    null,
    suspense.pendingBranch = vnode.ssContent,
    hiddenContainer,
    null,
    parentComponent,
    suspense,
    namespace,
    slotScopeIds
  );
  if (suspense.deps > 0) {
    triggerEvent$1(vnode, "onPending");
    triggerEvent$1(vnode, "onFallback");
    patch(
      null,
      vnode.ssFallback,
      container,
      anchor,
      parentComponent,
      null,
      // fallback tree will not have suspense context
      namespace,
      slotScopeIds
    );
    setActiveBranch(suspense, vnode.ssFallback);
  } else {
    suspense.resolve(false, true);
  }
}
function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
  const suspense = n2.suspense = n1.suspense;
  suspense.vnode = n2;
  n2.el = n1.el;
  const newBranch = n2.ssContent;
  const newFallback = n2.ssFallback;
  const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
  if (pendingBranch) {
    suspense.pendingBranch = newBranch;
    if (isSameVNodeType(newBranch, pendingBranch)) {
      patch(
        pendingBranch,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else if (isInFallback) {
        if (!isHydrating) {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      }
    } else {
      suspense.pendingId = suspenseId++;
      if (isHydrating) {
        suspense.isHydrating = false;
        suspense.activeBranch = pendingBranch;
      } else {
        unmount(pendingBranch, parentComponent, suspense);
      }
      suspense.deps = 0;
      suspense.effects.length = 0;
      suspense.hiddenContainer = createElement("div");
      if (isInFallback) {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        } else {
          patch(
            activeBranch,
            newFallback,
            container,
            anchor,
            parentComponent,
            null,
            // fallback tree will not have suspense context
            namespace,
            slotScopeIds,
            optimized
          );
          setActiveBranch(suspense, newFallback);
        }
      } else if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
        patch(
          activeBranch,
          newBranch,
          container,
          anchor,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        suspense.resolve(true);
      } else {
        patch(
          null,
          newBranch,
          suspense.hiddenContainer,
          null,
          parentComponent,
          suspense,
          namespace,
          slotScopeIds,
          optimized
        );
        if (suspense.deps <= 0) {
          suspense.resolve();
        }
      }
    }
  } else {
    if (activeBranch && isSameVNodeType(newBranch, activeBranch)) {
      patch(
        activeBranch,
        newBranch,
        container,
        anchor,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      setActiveBranch(suspense, newBranch);
    } else {
      triggerEvent$1(n2, "onPending");
      suspense.pendingBranch = newBranch;
      if (newBranch.shapeFlag & 512) {
        suspense.pendingId = newBranch.component.suspenseId;
      } else {
        suspense.pendingId = suspenseId++;
      }
      patch(
        null,
        newBranch,
        suspense.hiddenContainer,
        null,
        parentComponent,
        suspense,
        namespace,
        slotScopeIds,
        optimized
      );
      if (suspense.deps <= 0) {
        suspense.resolve();
      } else {
        const { timeout, pendingId } = suspense;
        if (timeout > 0) {
          setTimeout(() => {
            if (suspense.pendingId === pendingId) {
              suspense.fallback(newFallback);
            }
          }, timeout);
        } else if (timeout === 0) {
          suspense.fallback(newFallback);
        }
      }
    }
  }
}
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
  const {
    p: patch,
    m: move,
    um: unmount,
    n: next,
    o: { parentNode, remove: remove2 }
  } = rendererInternals;
  let parentSuspenseId;
  const isSuspensible = isVNodeSuspensible(vnode);
  if (isSuspensible) {
    if (parentSuspense && parentSuspense.pendingBranch) {
      parentSuspenseId = parentSuspense.pendingId;
      parentSuspense.deps++;
    }
  }
  const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
  const initialAnchor = anchor;
  const suspense = {
    vnode,
    parent: parentSuspense,
    parentComponent,
    namespace,
    container,
    hiddenContainer,
    deps: 0,
    pendingId: suspenseId++,
    timeout: typeof timeout === "number" ? timeout : -1,
    activeBranch: null,
    pendingBranch: null,
    isInFallback: !isHydrating,
    isHydrating,
    isUnmounted: false,
    effects: [],
    resolve(resume = false, sync = false) {
      const {
        vnode: vnode2,
        activeBranch,
        pendingBranch,
        pendingId,
        effects,
        parentComponent: parentComponent2,
        container: container2
      } = suspense;
      let delayEnter = false;
      if (suspense.isHydrating) {
        suspense.isHydrating = false;
      } else if (!resume) {
        delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
        if (delayEnter) {
          activeBranch.transition.afterLeave = () => {
            if (pendingId === suspense.pendingId) {
              move(
                pendingBranch,
                container2,
                anchor === initialAnchor ? next(activeBranch) : anchor,
                0
              );
              queuePostFlushCb(effects);
            }
          };
        }
        if (activeBranch) {
          if (parentNode(activeBranch.el) === container2) {
            anchor = next(activeBranch);
          }
          unmount(activeBranch, parentComponent2, suspense, true);
        }
        if (!delayEnter) {
          move(pendingBranch, container2, anchor, 0);
        }
      }
      setActiveBranch(suspense, pendingBranch);
      suspense.pendingBranch = null;
      suspense.isInFallback = false;
      let parent = suspense.parent;
      let hasUnresolvedAncestor = false;
      while (parent) {
        if (parent.pendingBranch) {
          parent.effects.push(...effects);
          hasUnresolvedAncestor = true;
          break;
        }
        parent = parent.parent;
      }
      if (!hasUnresolvedAncestor && !delayEnter) {
        queuePostFlushCb(effects);
      }
      suspense.effects = [];
      if (isSuspensible) {
        if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
          parentSuspense.deps--;
          if (parentSuspense.deps === 0 && !sync) {
            parentSuspense.resolve();
          }
        }
      }
      triggerEvent$1(vnode2, "onResolve");
    },
    fallback(fallbackVNode) {
      if (!suspense.pendingBranch) {
        return;
      }
      const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
      triggerEvent$1(vnode2, "onFallback");
      const anchor2 = next(activeBranch);
      const mountFallback = () => {
        if (!suspense.isInFallback) {
          return;
        }
        patch(
          null,
          fallbackVNode,
          container2,
          anchor2,
          parentComponent2,
          null,
          // fallback tree will not have suspense context
          namespace2,
          slotScopeIds,
          optimized
        );
        setActiveBranch(suspense, fallbackVNode);
      };
      const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
      if (delayEnter) {
        activeBranch.transition.afterLeave = mountFallback;
      }
      suspense.isInFallback = true;
      unmount(
        activeBranch,
        parentComponent2,
        null,
        // no suspense so unmount hooks fire now
        true
        // shouldRemove
      );
      if (!delayEnter) {
        mountFallback();
      }
    },
    move(container2, anchor2, type2) {
      suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type2);
      suspense.container = container2;
    },
    next() {
      return suspense.activeBranch && next(suspense.activeBranch);
    },
    registerDep(instance, setupRenderEffect, optimized2) {
      const isInPendingSuspense = !!suspense.pendingBranch;
      if (isInPendingSuspense) {
        suspense.deps++;
      }
      const hydratedEl = instance.vnode.el;
      instance.asyncDep.catch((err) => {
        handleError(err, instance, 0);
      }).then((asyncSetupResult) => {
        if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) {
          return;
        }
        instance.asyncResolved = true;
        const { vnode: vnode2 } = instance;
        handleSetupResult(instance, asyncSetupResult);
        if (hydratedEl) {
          vnode2.el = hydratedEl;
        }
        const placeholder = !hydratedEl && instance.subTree.el;
        setupRenderEffect(
          instance,
          vnode2,
          // component may have been moved before resolve.
          // if this is not a hydration, instance.subTree will be the comment
          // placeholder.
          parentNode(hydratedEl || instance.subTree.el),
          // anchor will not be used if this is hydration, so only need to
          // consider the comment placeholder case.
          hydratedEl ? null : next(instance.subTree),
          suspense,
          namespace,
          optimized2
        );
        if (placeholder) {
          remove2(placeholder);
        }
        updateHOCHostEl(instance, vnode2.el);
        if (isInPendingSuspense && --suspense.deps === 0) {
          suspense.resolve();
        }
      });
    },
    unmount(parentSuspense2, doRemove) {
      suspense.isUnmounted = true;
      if (suspense.activeBranch) {
        unmount(
          suspense.activeBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
      if (suspense.pendingBranch) {
        unmount(
          suspense.pendingBranch,
          parentComponent,
          parentSuspense2,
          doRemove
        );
      }
    }
  };
  return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
  const suspense = vnode.suspense = createSuspenseBoundary(
    vnode,
    parentSuspense,
    parentComponent,
    node.parentNode,
    // eslint-disable-next-line no-restricted-globals
    document.createElement("div"),
    null,
    namespace,
    slotScopeIds,
    optimized,
    rendererInternals,
    true
  );
  const result = hydrateNode(
    node,
    suspense.pendingBranch = vnode.ssContent,
    parentComponent,
    suspense,
    slotScopeIds,
    optimized
  );
  if (suspense.deps === 0) {
    suspense.resolve(false, true);
  }
  return result;
}
function normalizeSuspenseChildren(vnode) {
  const { shapeFlag, children } = vnode;
  const isSlotChildren = shapeFlag & 32;
  vnode.ssContent = normalizeSuspenseSlot(
    isSlotChildren ? children.default : children
  );
  vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
  let block;
  if (isFunction$1(s)) {
    const trackBlock = isBlockTreeEnabled && s._c;
    if (trackBlock) {
      s._d = false;
      openBlock();
    }
    s = s();
    if (trackBlock) {
      s._d = true;
      block = currentBlock;
      closeBlock();
    }
  }
  if (isArray(s)) {
    const singleChild = filterSingleRoot(s);
    s = singleChild;
  }
  s = normalizeVNode(s);
  if (block && !s.dynamicChildren) {
    s.dynamicChildren = block.filter((c) => c !== s);
  }
  return s;
}
function queueEffectWithSuspense(fn, suspense) {
  if (suspense && suspense.pendingBranch) {
    if (isArray(fn)) {
      suspense.effects.push(...fn);
    } else {
      suspense.effects.push(fn);
    }
  } else {
    queuePostFlushCb(fn);
  }
}
function setActiveBranch(suspense, branch) {
  suspense.activeBranch = branch;
  const { vnode, parentComponent } = suspense;
  let el = branch.el;
  while (!el && branch.component) {
    branch = branch.component.subTree;
    el = branch.el;
  }
  vnode.el = el;
  if (parentComponent && parentComponent.subTree === vnode) {
    parentComponent.vnode.el = el;
    updateHOCHostEl(parentComponent, el);
  }
}
function isVNodeSuspensible(vnode) {
  const suspensible = vnode.props && vnode.props.suspensible;
  return suspensible != null && suspensible !== false;
}
const Fragment = Symbol.for("v-fgt");
const Text = Symbol.for("v-txt");
const Comment = Symbol.for("v-cmt");
const Static = Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
  blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
  blockStack.pop();
  currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
  isBlockTreeEnabled += value;
  if (value < 0 && currentBlock && inVOnce) {
    currentBlock.hasOnce = true;
  }
}
function setupBlock(vnode) {
  vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
  closeBlock();
  if (isBlockTreeEnabled > 0 && currentBlock) {
    currentBlock.push(vnode);
  }
  return vnode;
}
function createElementBlock(type2, props, children, patchFlag, dynamicProps, shapeFlag) {
  return setupBlock(
    createBaseVNode(
      type2,
      props,
      children,
      patchFlag,
      dynamicProps,
      shapeFlag,
      true
    )
  );
}
function createBlock(type2, props, children, patchFlag, dynamicProps) {
  return setupBlock(
    createVNode(
      type2,
      props,
      children,
      patchFlag,
      dynamicProps,
      true
    )
  );
}
function isVNode(value) {
  return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
  return n1.type === n2.type && n1.key === n2.key;
}
const normalizeKey = ({ key }) => key != null ? key : null;
const normalizeRef = ({
  ref: ref3,
  ref_key,
  ref_for
}) => {
  if (typeof ref3 === "number") {
    ref3 = "" + ref3;
  }
  return ref3 != null ? isString$1(ref3) || isRef(ref3) || isFunction$1(ref3) ? { i: currentRenderingInstance, r: ref3, k: ref_key, f: !!ref_for } : ref3 : null;
};
function createBaseVNode(type2, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type2 === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
  const vnode = {
    __v_isVNode: true,
    __v_skip: true,
    type: type2,
    props,
    key: props && normalizeKey(props),
    ref: props && normalizeRef(props),
    scopeId: currentScopeId,
    slotScopeIds: null,
    children,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag,
    patchFlag,
    dynamicProps,
    dynamicChildren: null,
    appContext: null,
    ctx: currentRenderingInstance
  };
  if (needFullChildrenNormalization) {
    normalizeChildren(vnode, children);
    if (shapeFlag & 128) {
      type2.normalize(vnode);
    }
  } else if (children) {
    vnode.shapeFlag |= isString$1(children) ? 8 : 16;
  }
  if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
  !isBlockNode && // has current parent block
  currentBlock && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  vnode.patchFlag !== 32) {
    currentBlock.push(vnode);
  }
  return vnode;
}
const createVNode = _createVNode;
function _createVNode(type2, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
  if (!type2 || type2 === NULL_DYNAMIC_COMPONENT) {
    type2 = Comment;
  }
  if (isVNode(type2)) {
    const cloned = cloneVNode(
      type2,
      props,
      true
      /* mergeRef: true */
    );
    if (children) {
      normalizeChildren(cloned, children);
    }
    if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
      if (cloned.shapeFlag & 6) {
        currentBlock[currentBlock.indexOf(type2)] = cloned;
      } else {
        currentBlock.push(cloned);
      }
    }
    cloned.patchFlag = -2;
    return cloned;
  }
  if (isClassComponent(type2)) {
    type2 = type2.__vccOpts;
  }
  if (props) {
    props = guardReactiveProps(props);
    let { class: klass, style } = props;
    if (klass && !isString$1(klass)) {
      props.class = normalizeClass(klass);
    }
    if (isObject(style)) {
      if (isProxy(style) && !isArray(style)) {
        style = extend({}, style);
      }
      props.style = normalizeStyle(style);
    }
  }
  const shapeFlag = isString$1(type2) ? 1 : isSuspense(type2) ? 128 : isTeleport(type2) ? 64 : isObject(type2) ? 4 : isFunction$1(type2) ? 2 : 0;
  return createBaseVNode(
    type2,
    props,
    children,
    patchFlag,
    dynamicProps,
    shapeFlag,
    isBlockNode,
    true
  );
}
function guardReactiveProps(props) {
  if (!props) return null;
  return isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
  const { props, ref: ref3, patchFlag, children, transition } = vnode;
  const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
  const cloned = {
    __v_isVNode: true,
    __v_skip: true,
    type: vnode.type,
    props: mergedProps,
    key: mergedProps && normalizeKey(mergedProps),
    ref: extraProps && extraProps.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      mergeRef && ref3 ? isArray(ref3) ? ref3.concat(normalizeRef(extraProps)) : [ref3, normalizeRef(extraProps)] : normalizeRef(extraProps)
    ) : ref3,
    scopeId: vnode.scopeId,
    slotScopeIds: vnode.slotScopeIds,
    children,
    target: vnode.target,
    targetStart: vnode.targetStart,
    targetAnchor: vnode.targetAnchor,
    staticCount: vnode.staticCount,
    shapeFlag: vnode.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
    dynamicProps: vnode.dynamicProps,
    dynamicChildren: vnode.dynamicChildren,
    appContext: vnode.appContext,
    dirs: vnode.dirs,
    transition,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: vnode.component,
    suspense: vnode.suspense,
    ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
    ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
    el: vnode.el,
    anchor: vnode.anchor,
    ctx: vnode.ctx,
    ce: vnode.ce
  };
  if (transition && cloneTransition) {
    setTransitionHooks(
      cloned,
      transition.clone(cloned)
    );
  }
  return cloned;
}
function createTextVNode(text = " ", flag = 0) {
  return createVNode(Text, null, text, flag);
}
function createCommentVNode(text = "", asBlock = false) {
  return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
  if (child == null || typeof child === "boolean") {
    return createVNode(Comment);
  } else if (isArray(child)) {
    return createVNode(
      Fragment,
      null,
      // #3666, avoid reference pollution when reusing vnode
      child.slice()
    );
  } else if (isVNode(child)) {
    return cloneIfMounted(child);
  } else {
    return createVNode(Text, null, String(child));
  }
}
function cloneIfMounted(child) {
  return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
  let type2 = 0;
  const { shapeFlag } = vnode;
  if (children == null) {
    children = null;
  } else if (isArray(children)) {
    type2 = 16;
  } else if (typeof children === "object") {
    if (shapeFlag & (1 | 64)) {
      const slot = children.default;
      if (slot) {
        slot._c && (slot._d = false);
        normalizeChildren(vnode, slot());
        slot._c && (slot._d = true);
      }
      return;
    } else {
      type2 = 32;
      const slotFlag = children._;
      if (!slotFlag && !isInternalObject(children)) {
        children._ctx = currentRenderingInstance;
      } else if (slotFlag === 3 && currentRenderingInstance) {
        if (currentRenderingInstance.slots._ === 1) {
          children._ = 1;
        } else {
          children._ = 2;
          vnode.patchFlag |= 1024;
        }
      }
    }
  } else if (isFunction$1(children)) {
    children = { default: children, _ctx: currentRenderingInstance };
    type2 = 32;
  } else {
    children = String(children);
    if (shapeFlag & 64) {
      type2 = 16;
      children = [createTextVNode(children)];
    } else {
      type2 = 8;
    }
  }
  vnode.children = children;
  vnode.shapeFlag |= type2;
}
function mergeProps(...args) {
  const ret = {};
  for (let i = 0; i < args.length; i++) {
    const toMerge = args[i];
    for (const key in toMerge) {
      if (key === "class") {
        if (ret.class !== toMerge.class) {
          ret.class = normalizeClass([ret.class, toMerge.class]);
        }
      } else if (key === "style") {
        ret.style = normalizeStyle([ret.style, toMerge.style]);
      } else if (isOn(key)) {
        const existing = ret[key];
        const incoming = toMerge[key];
        if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) {
          ret[key] = existing ? [].concat(existing, incoming) : incoming;
        }
      } else if (key !== "") {
        ret[key] = toMerge[key];
      }
    }
  }
  return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
  callWithAsyncErrorHandling(hook, instance, 7, [
    vnode,
    prevVNode
  ]);
}
const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
  const type2 = vnode.type;
  const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
  const instance = {
    uid: uid++,
    vnode,
    type: type2,
    parent,
    appContext,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    job: null,
    scope: new EffectScope(
      true
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: parent ? parent.provides : Object.create(appContext.provides),
    ids: parent ? parent.ids : ["", 0, 0],
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: normalizePropsOptions(type2, appContext),
    emitsOptions: normalizeEmitsOptions(type2, appContext),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: EMPTY_OBJ,
    // inheritAttrs
    inheritAttrs: type2.inheritAttrs,
    // state
    ctx: EMPTY_OBJ,
    data: EMPTY_OBJ,
    props: EMPTY_OBJ,
    attrs: EMPTY_OBJ,
    slots: EMPTY_OBJ,
    refs: EMPTY_OBJ,
    setupState: EMPTY_OBJ,
    setupContext: null,
    // suspense related
    suspense,
    suspenseId: suspense ? suspense.pendingId : 0,
    asyncDep: null,
    asyncResolved: false,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: false,
    isUnmounted: false,
    isDeactivated: false,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  {
    instance.ctx = { _: instance };
  }
  instance.root = parent ? parent.root : instance;
  instance.emit = emit.bind(null, instance);
  if (vnode.ce) {
    vnode.ce(instance);
  }
  return instance;
}
let currentInstance = null;
const getCurrentInstance = () => currentInstance || currentRenderingInstance;
let internalSetCurrentInstance;
let setInSSRSetupState;
{
  const g = getGlobalThis();
  const registerGlobalSetter = (key, setter) => {
    let setters;
    if (!(setters = g[key])) setters = g[key] = [];
    setters.push(setter);
    return (v) => {
      if (setters.length > 1) setters.forEach((set2) => set2(v));
      else setters[0](v);
    };
  };
  internalSetCurrentInstance = registerGlobalSetter(
    `__VUE_INSTANCE_SETTERS__`,
    (v) => currentInstance = v
  );
  setInSSRSetupState = registerGlobalSetter(
    `__VUE_SSR_SETTERS__`,
    (v) => isInSSRComponentSetup = v
  );
}
const setCurrentInstance = (instance) => {
  const prev = currentInstance;
  internalSetCurrentInstance(instance);
  instance.scope.on();
  return () => {
    instance.scope.off();
    internalSetCurrentInstance(prev);
  };
};
const unsetCurrentInstance = () => {
  currentInstance && currentInstance.scope.off();
  internalSetCurrentInstance(null);
};
function isStatefulComponent(instance) {
  return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
  isSSR && setInSSRSetupState(isSSR);
  const { props, children } = instance.vnode;
  const isStateful = isStatefulComponent(instance);
  initProps(instance, props, isStateful, isSSR);
  initSlots(instance, children, optimized);
  const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
  isSSR && setInSSRSetupState(false);
  return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
  const Component = instance.type;
  instance.accessCache = /* @__PURE__ */ Object.create(null);
  instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
  const { setup } = Component;
  if (setup) {
    pauseTracking();
    const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
    const reset = setCurrentInstance(instance);
    const setupResult = callWithErrorHandling(
      setup,
      instance,
      0,
      [
        instance.props,
        setupContext
      ]
    );
    const isAsyncSetup = isPromise(setupResult);
    resetTracking();
    reset();
    if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
      markAsyncBoundary(instance);
    }
    if (isAsyncSetup) {
      setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
      if (isSSR) {
        return setupResult.then((resolvedResult) => {
          handleSetupResult(instance, resolvedResult);
        }).catch((e) => {
          handleError(e, instance, 0);
        });
      } else {
        instance.asyncDep = setupResult;
      }
    } else {
      handleSetupResult(instance, setupResult);
    }
  } else {
    finishComponentSetup(instance);
  }
}
function handleSetupResult(instance, setupResult, isSSR) {
  if (isFunction$1(setupResult)) {
    if (instance.type.__ssrInlineRender) {
      instance.ssrRender = setupResult;
    } else {
      instance.render = setupResult;
    }
  } else if (isObject(setupResult)) {
    instance.setupState = proxyRefs(setupResult);
  } else ;
  finishComponentSetup(instance);
}
function finishComponentSetup(instance, isSSR, skipOptions) {
  const Component = instance.type;
  if (!instance.render) {
    instance.render = Component.render || NOOP;
  }
  {
    const reset = setCurrentInstance(instance);
    pauseTracking();
    try {
      applyOptions(instance);
    } finally {
      resetTracking();
      reset();
    }
  }
}
const attrsProxyHandlers = {
  get(target, key) {
    track(target, "get", "");
    return target[key];
  }
};
function createSetupContext(instance) {
  const expose = (exposed) => {
    instance.exposed = exposed || {};
  };
  {
    return {
      attrs: new Proxy(instance.attrs, attrsProxyHandlers),
      slots: instance.slots,
      emit: instance.emit,
      expose
    };
  }
}
function getComponentPublicInstance(instance) {
  if (instance.exposed) {
    return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
      get(target, key) {
        if (key in target) {
          return target[key];
        } else if (key in publicPropertiesMap) {
          return publicPropertiesMap[key](instance);
        }
      },
      has(target, key) {
        return key in target || key in publicPropertiesMap;
      }
    }));
  } else {
    return instance.proxy;
  }
}
const classifyRE = /(?:^|[-_])(\w)/g;
const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
  return isFunction$1(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function formatComponentName(instance, Component, isRoot = false) {
  let name = getComponentName(Component);
  if (!name && Component.__file) {
    const match = Component.__file.match(/([^/\\]+)\.\w+$/);
    if (match) {
      name = match[1];
    }
  }
  if (!name && instance && instance.parent) {
    const inferFromRegistry = (registry) => {
      for (const key in registry) {
        if (registry[key] === Component) {
          return key;
        }
      }
    };
    name = inferFromRegistry(
      instance.components || instance.parent.type.components
    ) || inferFromRegistry(instance.appContext.components);
  }
  return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value) {
  return isFunction$1(value) && "__vccOpts" in value;
}
const computed = (getterOrOptions, debugOptions) => {
  const c = computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
  return c;
};
function h(type2, propsOrChildren, children) {
  const l = arguments.length;
  if (l === 2) {
    if (isObject(propsOrChildren) && !isArray(propsOrChildren)) {
      if (isVNode(propsOrChildren)) {
        return createVNode(type2, null, [propsOrChildren]);
      }
      return createVNode(type2, propsOrChildren);
    } else {
      return createVNode(type2, null, propsOrChildren);
    }
  } else {
    if (l > 3) {
      children = Array.prototype.slice.call(arguments, 2);
    } else if (l === 3 && isVNode(children)) {
      children = [children];
    }
    return createVNode(type2, propsOrChildren, children);
  }
}
const version = "3.5.13";
/**
* @vue/runtime-dom v3.5.13
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let policy = void 0;
const tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) {
  try {
    policy = /* @__PURE__ */ tt.createPolicy("vue", {
      createHTML: (val) => val
    });
  } catch (e) {
  }
}
const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
const svgNS = "http://www.w3.org/2000/svg";
const mathmlNS = "http://www.w3.org/1998/Math/MathML";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
  insert: (child, parent, anchor) => {
    parent.insertBefore(child, anchor || null);
  },
  remove: (child) => {
    const parent = child.parentNode;
    if (parent) {
      parent.removeChild(child);
    }
  },
  createElement: (tag, namespace, is, props) => {
    const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
    if (tag === "select" && props && props.multiple != null) {
      el.setAttribute("multiple", props.multiple);
    }
    return el;
  },
  createText: (text) => doc.createTextNode(text),
  createComment: (text) => doc.createComment(text),
  setText: (node, text) => {
    node.nodeValue = text;
  },
  setElementText: (el, text) => {
    el.textContent = text;
  },
  parentNode: (node) => node.parentNode,
  nextSibling: (node) => node.nextSibling,
  querySelector: (selector) => doc.querySelector(selector),
  setScopeId(el, id) {
    el.setAttribute(id, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(content, parent, anchor, namespace, start, end) {
    const before = anchor ? anchor.previousSibling : parent.lastChild;
    if (start && (start === end || start.nextSibling)) {
      while (true) {
        parent.insertBefore(start.cloneNode(true), anchor);
        if (start === end || !(start = start.nextSibling)) break;
      }
    } else {
      templateContainer.innerHTML = unsafeToTrustedHTML(
        namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content
      );
      const template = templateContainer.content;
      if (namespace === "svg" || namespace === "mathml") {
        const wrapper = template.firstChild;
        while (wrapper.firstChild) {
          template.appendChild(wrapper.firstChild);
        }
        template.removeChild(wrapper);
      }
      parent.insertBefore(template, anchor);
    }
    return [
      // first
      before ? before.nextSibling : parent.firstChild,
      // last
      anchor ? anchor.previousSibling : parent.lastChild
    ];
  }
};
const vtcKey = Symbol("_vtc");
function patchClass(el, value, isSVG) {
  const transitionClasses = el[vtcKey];
  if (transitionClasses) {
    value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
  }
  if (value == null) {
    el.removeAttribute("class");
  } else if (isSVG) {
    el.setAttribute("class", value);
  } else {
    el.className = value;
  }
}
const vShowOriginalDisplay = Symbol("_vod");
const vShowHidden = Symbol("_vsh");
const vShow = {
  beforeMount(el, { value }, { transition }) {
    el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
    if (transition && value) {
      transition.beforeEnter(el);
    } else {
      setDisplay(el, value);
    }
  },
  mounted(el, { value }, { transition }) {
    if (transition && value) {
      transition.enter(el);
    }
  },
  updated(el, { value, oldValue }, { transition }) {
    if (!value === !oldValue) return;
    if (transition) {
      if (value) {
        transition.beforeEnter(el);
        setDisplay(el, true);
        transition.enter(el);
      } else {
        transition.leave(el, () => {
          setDisplay(el, false);
        });
      }
    } else {
      setDisplay(el, value);
    }
  },
  beforeUnmount(el, { value }) {
    setDisplay(el, value);
  }
};
function setDisplay(el, value) {
  el.style.display = value ? el[vShowOriginalDisplay] : "none";
  el[vShowHidden] = !value;
}
const CSS_VAR_TEXT = Symbol("");
function useCssVars(getter) {
  const instance = getCurrentInstance();
  if (!instance) {
    return;
  }
  const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
    Array.from(
      document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)
    ).forEach((node) => setVarsOnNode(node, vars));
  };
  const setVars = () => {
    const vars = getter(instance.proxy);
    if (instance.ce) {
      setVarsOnNode(instance.ce, vars);
    } else {
      setVarsOnVNode(instance.subTree, vars);
    }
    updateTeleports(vars);
  };
  onBeforeUpdate(() => {
    queuePostFlushCb(setVars);
  });
  onMounted(() => {
    watch(setVars, NOOP, { flush: "post" });
    const ob = new MutationObserver(setVars);
    ob.observe(instance.subTree.el.parentNode, { childList: true });
    onUnmounted(() => ob.disconnect());
  });
}
function setVarsOnVNode(vnode, vars) {
  if (vnode.shapeFlag & 128) {
    const suspense = vnode.suspense;
    vnode = suspense.activeBranch;
    if (suspense.pendingBranch && !suspense.isHydrating) {
      suspense.effects.push(() => {
        setVarsOnVNode(suspense.activeBranch, vars);
      });
    }
  }
  while (vnode.component) {
    vnode = vnode.component.subTree;
  }
  if (vnode.shapeFlag & 1 && vnode.el) {
    setVarsOnNode(vnode.el, vars);
  } else if (vnode.type === Fragment) {
    vnode.children.forEach((c) => setVarsOnVNode(c, vars));
  } else if (vnode.type === Static) {
    let { el, anchor } = vnode;
    while (el) {
      setVarsOnNode(el, vars);
      if (el === anchor) break;
      el = el.nextSibling;
    }
  }
}
function setVarsOnNode(el, vars) {
  if (el.nodeType === 1) {
    const style = el.style;
    let cssText = "";
    for (const key in vars) {
      style.setProperty(`--${key}`, vars[key]);
      cssText += `--${key}: ${vars[key]};`;
    }
    style[CSS_VAR_TEXT] = cssText;
  }
}
const displayRE = /(^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
  const style = el.style;
  const isCssString = isString$1(next);
  let hasControlledDisplay = false;
  if (next && !isCssString) {
    if (prev) {
      if (!isString$1(prev)) {
        for (const key in prev) {
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      } else {
        for (const prevStyle of prev.split(";")) {
          const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
          if (next[key] == null) {
            setStyle(style, key, "");
          }
        }
      }
    }
    for (const key in next) {
      if (key === "display") {
        hasControlledDisplay = true;
      }
      setStyle(style, key, next[key]);
    }
  } else {
    if (isCssString) {
      if (prev !== next) {
        const cssVarText = style[CSS_VAR_TEXT];
        if (cssVarText) {
          next += ";" + cssVarText;
        }
        style.cssText = next;
        hasControlledDisplay = displayRE.test(next);
      }
    } else if (prev) {
      el.removeAttribute("style");
    }
  }
  if (vShowOriginalDisplay in el) {
    el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
    if (el[vShowHidden]) {
      style.display = "none";
    }
  }
}
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
  if (isArray(val)) {
    val.forEach((v) => setStyle(style, name, v));
  } else {
    if (val == null) val = "";
    if (name.startsWith("--")) {
      style.setProperty(name, val);
    } else {
      const prefixed = autoPrefix(style, name);
      if (importantRE.test(val)) {
        style.setProperty(
          hyphenate(prefixed),
          val.replace(importantRE, ""),
          "important"
        );
      } else {
        style[prefixed] = val;
      }
    }
  }
}
const prefixes = ["Webkit", "Moz", "ms"];
const prefixCache = {};
function autoPrefix(style, rawName) {
  const cached = prefixCache[rawName];
  if (cached) {
    return cached;
  }
  let name = camelize(rawName);
  if (name !== "filter" && name in style) {
    return prefixCache[rawName] = name;
  }
  name = capitalize(name);
  for (let i = 0; i < prefixes.length; i++) {
    const prefixed = prefixes[i] + name;
    if (prefixed in style) {
      return prefixCache[rawName] = prefixed;
    }
  }
  return rawName;
}
const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance, isBoolean2 = isSpecialBooleanAttr(key)) {
  if (isSVG && key.startsWith("xlink:")) {
    if (value == null) {
      el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
    } else {
      el.setAttributeNS(xlinkNS, key, value);
    }
  } else {
    if (value == null || isBoolean2 && !includeBooleanAttr(value)) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(
        key,
        isBoolean2 ? "" : isSymbol(value) ? String(value) : value
      );
    }
  }
}
function patchDOMProp(el, key, value, parentComponent, attrName) {
  if (key === "innerHTML" || key === "textContent") {
    if (value != null) {
      el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
    }
    return;
  }
  const tag = el.tagName;
  if (key === "value" && tag !== "PROGRESS" && // custom elements may use _value internally
  !tag.includes("-")) {
    const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
    const newValue = value == null ? (
      // #11647: value should be set as empty string for null and undefined,
      // but <input type="checkbox"> should be set as 'on'.
      el.type === "checkbox" ? "on" : ""
    ) : String(value);
    if (oldValue !== newValue || !("_value" in el)) {
      el.value = newValue;
    }
    if (value == null) {
      el.removeAttribute(key);
    }
    el._value = value;
    return;
  }
  let needRemove = false;
  if (value === "" || value == null) {
    const type2 = typeof el[key];
    if (type2 === "boolean") {
      value = includeBooleanAttr(value);
    } else if (value == null && type2 === "string") {
      value = "";
      needRemove = true;
    } else if (type2 === "number") {
      value = 0;
      needRemove = true;
    }
  }
  try {
    el[key] = value;
  } catch (e) {
  }
  needRemove && el.removeAttribute(attrName || key);
}
function addEventListener(el, event, handler, options) {
  el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
  el.removeEventListener(event, handler, options);
}
const veiKey = Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
  const invokers = el[veiKey] || (el[veiKey] = {});
  const existingInvoker = invokers[rawName];
  if (nextValue && existingInvoker) {
    existingInvoker.value = nextValue;
  } else {
    const [name, options] = parseName(rawName);
    if (nextValue) {
      const invoker = invokers[rawName] = createInvoker(
        nextValue,
        instance
      );
      addEventListener(el, name, invoker, options);
    } else if (existingInvoker) {
      removeEventListener(el, name, existingInvoker, options);
      invokers[rawName] = void 0;
    }
  }
}
const optionsModifierRE = /(?:Once|Passive|Capture)$/;
function parseName(name) {
  let options;
  if (optionsModifierRE.test(name)) {
    options = {};
    let m;
    while (m = name.match(optionsModifierRE)) {
      name = name.slice(0, name.length - m[0].length);
      options[m[0].toLowerCase()] = true;
    }
  }
  const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
  return [event, options];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
  const invoker = (e) => {
    if (!e._vts) {
      e._vts = Date.now();
    } else if (e._vts <= invoker.attached) {
      return;
    }
    callWithAsyncErrorHandling(
      patchStopImmediatePropagation(e, invoker.value),
      instance,
      5,
      [e]
    );
  };
  invoker.value = initialValue;
  invoker.attached = getNow();
  return invoker;
}
function patchStopImmediatePropagation(e, value) {
  if (isArray(value)) {
    const originalStop = e.stopImmediatePropagation;
    e.stopImmediatePropagation = () => {
      originalStop.call(e);
      e._stopped = true;
    };
    return value.map(
      (fn) => (e2) => !e2._stopped && fn && fn(e2)
    );
  } else {
    return value;
  }
}
const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
  const isSVG = namespace === "svg";
  if (key === "class") {
    patchClass(el, nextValue, isSVG);
  } else if (key === "style") {
    patchStyle(el, prevValue, nextValue);
  } else if (isOn(key)) {
    if (!isModelListener(key)) {
      patchEvent(el, key, prevValue, nextValue, parentComponent);
    }
  } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
    patchDOMProp(el, key, nextValue);
    if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
      patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
    }
  } else if (
    // #11081 force set props for possible async custom element
    el._isVueCE && (/[A-Z]/.test(key) || !isString$1(nextValue))
  ) {
    patchDOMProp(el, camelize(key), nextValue, parentComponent, key);
  } else {
    if (key === "true-value") {
      el._trueValue = nextValue;
    } else if (key === "false-value") {
      el._falseValue = nextValue;
    }
    patchAttr(el, key, nextValue, isSVG);
  }
};
function shouldSetAsProp(el, key, value, isSVG) {
  if (isSVG) {
    if (key === "innerHTML" || key === "textContent") {
      return true;
    }
    if (key in el && isNativeOn(key) && isFunction$1(value)) {
      return true;
    }
    return false;
  }
  if (key === "spellcheck" || key === "draggable" || key === "translate") {
    return false;
  }
  if (key === "form") {
    return false;
  }
  if (key === "list" && el.tagName === "INPUT") {
    return false;
  }
  if (key === "type" && el.tagName === "TEXTAREA") {
    return false;
  }
  if (key === "width" || key === "height") {
    const tag = el.tagName;
    if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") {
      return false;
    }
  }
  if (isNativeOn(key) && isString$1(value)) {
    return false;
  }
  return key in el;
}
const systemModifiers = ["ctrl", "shift", "alt", "meta"];
const modifierGuards = {
  stop: (e) => e.stopPropagation(),
  prevent: (e) => e.preventDefault(),
  self: (e) => e.target !== e.currentTarget,
  ctrl: (e) => !e.ctrlKey,
  shift: (e) => !e.shiftKey,
  alt: (e) => !e.altKey,
  meta: (e) => !e.metaKey,
  left: (e) => "button" in e && e.button !== 0,
  middle: (e) => "button" in e && e.button !== 1,
  right: (e) => "button" in e && e.button !== 2,
  exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
};
const withModifiers = (fn, modifiers) => {
  const cache = fn._withMods || (fn._withMods = {});
  const cacheKey = modifiers.join(".");
  return cache[cacheKey] || (cache[cacheKey] = (event, ...args) => {
    for (let i = 0; i < modifiers.length; i++) {
      const guard = modifierGuards[modifiers[i]];
      if (guard && guard(event, modifiers)) return;
    }
    return fn(event, ...args);
  });
};
const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
let renderer;
function ensureRenderer() {
  return renderer || (renderer = createRenderer(rendererOptions));
}
const createApp = (...args) => {
  const app = ensureRenderer().createApp(...args);
  const { mount } = app;
  app.mount = (containerOrSelector) => {
    const container = normalizeContainer(containerOrSelector);
    if (!container) return;
    const component = app._component;
    if (!isFunction$1(component) && !component.render && !component.template) {
      component.template = container.innerHTML;
    }
    if (container.nodeType === 1) {
      container.textContent = "";
    }
    const proxy = mount(container, false, resolveRootNamespace(container));
    if (container instanceof Element) {
      container.removeAttribute("v-cloak");
      container.setAttribute("data-v-app", "");
    }
    return proxy;
  };
  return app;
};
function resolveRootNamespace(container) {
  if (container instanceof SVGElement) {
    return "svg";
  }
  if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
    return "mathml";
  }
}
function normalizeContainer(container) {
  if (isString$1(container)) {
    const res = document.querySelector(container);
    return res;
  }
  return container;
}
new Set("0123456789");
function isFunction(value) {
  return typeof value === "function";
}
function isNumber(value) {
  return typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value);
}
function isString(value) {
  return typeof value === "string";
}
function sleep(time) {
  return new Promise((resolve2) => {
    setTimeout(() => {
      resolve2();
    }, time);
  });
}
function toCamelCase(attr) {
  return attr.toLowerCase().replace(/-(.)/g, (_, group) => {
    return group.toUpperCase();
  });
}
function camelCaseToUnderscore(str) {
  return str.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
}
function getDataAttributes(attrs, handler) {
  if (!attrs) {
    return;
  }
  const result = {};
  for (const attr in attrs) {
    if (!attr.startsWith("data-")) {
      continue;
    }
    const theAfter = attr.replace(/^data-/, "");
    const transAttr = toCamelCase(theAfter);
    result[transAttr] = handler(attrs[attr]);
  }
  return result;
}
const isAndroid = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
const isIOS = typeof navigator !== "undefined" && /iPad|iPhone|iPod/.test(navigator.userAgent);
const isHarmonyOS = typeof navigator !== "undefined" && /OpenHarmony|harmony/.test(navigator.userAgent);
const isDesktop = typeof navigator !== "undefined" && !/Android|iPad|iPhone|iPod|OpenHarmony|harmony|Mobile/.test(navigator.userAgent);
(() => {
  if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) {
    return true;
  } else {
    return false;
  }
})();
function resolvePath(basePath, relativePath) {
  if (relativePath.startsWith("/")) {
    return relativePath.slice(1);
  }
  const currParts = basePath.split("/");
  const relativeParts = relativePath.split("/");
  for (const element of relativeParts) {
    const part = element;
    if (part === "..") {
      if (currParts.length > 0) {
        currParts.pop();
      }
    } else if (part !== "." && part !== "") {
      currParts.push(part);
    }
  }
  return currParts.join("/");
}
function parsePath(currPath, url) {
  const basePath = currPath.split("/").slice(0, -1).join("/");
  const parts = url.split("?");
  const pagePath = parts[0];
  const paramStr = parts[1];
  let newUrl = resolvePath(basePath, pagePath);
  if (paramStr) {
    newUrl += `?${paramStr}`;
  }
  return newUrl;
}
const rpxRegex = /([+-]?\d+(?:\.\d+)?)rpx/g;
function transformRpx(styleText) {
  if (!isString(styleText)) {
    return styleText;
  }
  return styleText.replace(rpxRegex, (match, pixel) => {
    return `${Number(pixel)}rem`;
  });
}
function suffixPixel(value) {
  return isNumber(value) ? `${value}px` : value;
}
function suffixDegree(value) {
  return `${value}deg`;
}
const transformHandler = {
  matrix(args) {
    return `matrix(${args.join(", ")})`;
  },
  matrix3d(args) {
    return `matrix3d(${args.join(", ")})`;
  },
  rotate(args) {
    const [angle] = args.map(suffixDegree);
    return `rotate(${angle})`;
  },
  rotate3d(args) {
    args[3] = suffixDegree(args[3]);
    return `rotate3d(${args.join(", ")})`;
  },
  rotateX(args) {
    const [angle] = args.map(suffixDegree);
    return `rotateX(${angle})`;
  },
  rotateY(args) {
    const [angle] = args.map(suffixDegree);
    return `rotateY(${angle})`;
  },
  rotateZ(args) {
    const [angle] = args.map(suffixDegree);
    return `rotateZ(${angle})`;
  },
  scale(args) {
    return `scale(${args.join(", ")})`;
  },
  scale3d(args) {
    return `scale3d(${args.join(", ")})`;
  },
  scaleX(args) {
    return `scaleX(${args[0]})`;
  },
  scaleY(args) {
    return `scaleY(${args[0]})`;
  },
  scaleZ(args) {
    return `scaleZ(${args[0]})`;
  },
  skew(args) {
    const _args = args.map(suffixDegree);
    return `skew(${_args.join(", ")})`;
  },
  skewX(args) {
    const [angle] = args.map(suffixDegree);
    return `skewX(${angle})`;
  },
  skewY(args) {
    const [angle] = args.map(suffixDegree);
    return `skewY(${angle})`;
  },
  translate(args) {
    const _args = args.map(suffixPixel);
    return `translate(${_args.join(", ")})`;
  },
  translate3d(args) {
    const _args = args.map(suffixPixel);
    return `translate3d(${_args.join(", ")})`;
  },
  translateX(args) {
    const [value] = args.map(suffixPixel);
    return `translateX(${value})`;
  },
  translateY(args) {
    const [value] = args.map(suffixPixel);
    return `translateY(${value})`;
  },
  translateZ(args) {
    const [value] = args.map(suffixPixel);
    return `translateZ(${value})`;
  }
};
function animationToStyle(action) {
  const { animates, option } = action;
  const transformOrigin = option.transformOrigin;
  const transition = option.transition;
  if (transformOrigin === void 0 || transition === void 0) {
    return {
      transformOrigin: "",
      transform: "",
      transition: ""
    };
  }
  const transform = animates.filter((animate) => animate.type !== "style").map((animate) => {
    const { type: type2, args } = animate;
    if (isFunction(transformHandler[type2])) {
      return transformHandler[type2](args);
    }
    console.warn(`[Common] SDK inner warning (Transform Handler not found animation type: ${type2})`);
    return "";
  }).join(" ");
  const styles = {};
  animates.filter((animate) => animate.type === "style").forEach((animate) => {
    const [prop, value] = animate.args;
    styles[prop] = value;
  });
  return {
    keyframes: [
      {
        transform,
        transformOrigin,
        ...styles
      }
    ],
    options: {
      duration: transition.duration,
      easing: transition.timingFunction,
      delay: transition.delay,
      fill: "forwards"
      // 保持动画最后一帧的状态
    }
  };
}
const initTimeStamp = Date.now();
function useInfo() {
  const bridgeId = inject("bridgeId");
  const currPath = inject("path");
  const info = inject(currPath);
  let moduleId;
  let path;
  const instance = getCurrentInstance();
  const scopeIds = instance.vnode.slotScopeIds;
  if (scopeIds == null ? void 0 : scopeIds.length) {
    let currentInfo = info;
    let currentPath = currPath;
    for (let i = 0; i < scopeIds.length; i++) {
      if (!(currentInfo == null ? void 0 : currentInfo.pagePath))
        break;
      const parentPath = currentInfo.pagePath;
      const parentInfo = inject(parentPath);
      if (!parentInfo)
        break;
      currentInfo = parentInfo;
      currentPath = parentPath;
    }
    provide("path", currentPath);
    provide(currentPath, currentInfo);
    moduleId = currentInfo.id;
    path = currentPath;
  } else {
    moduleId = info.id;
    path = currPath;
  }
  return {
    attrs: useAttrs(),
    bridgeId,
    moduleId,
    path
  };
}
function isScrollable(element) {
  const isElementScrollable = (el) => {
    const style = window.getComputedStyle(el);
    const overflowY = style.overflowY;
    const overflowX = style.overflowX;
    return (overflowY === "auto" || overflowY === "scroll") && el.scrollHeight > el.clientHeight || (overflowX === "auto" || overflowX === "scroll") && el.scrollWidth > el.clientWidth;
  };
  let current = element;
  while (current && current !== document.body) {
    if (isElementScrollable(current)) {
      return true;
    }
    current = current.parentElement;
  }
  return false;
}
function triggerEvent(type2, { event, detail, info, success }) {
  if (!info.attrs) {
    return;
  }
  const bindHandler = info.attrs[`bind${type2}`] || info.attrs[`bind:${type2}`];
  const catchHandler = info.attrs[`catch${type2}`] || info.attrs[`catch:${type2}`];
  if (catchHandler) {
    if (event) {
      event.stopPropagation();
      if (type2.startsWith("touch")) {
        if (!isScrollable(event.target)) {
          event.preventDefault();
        }
      }
    }
    sendTriggerEvent(catchHandler, {
      type: type2,
      detail,
      info,
      success,
      event
    });
    return;
  }
  if (bindHandler) {
    sendTriggerEvent(bindHandler, {
      type: type2,
      detail,
      info,
      success,
      event
    });
  }
}
function sendTriggerEvent(methodName, { type: type2, detail = {}, info, success, event = {} }) {
  const { bridgeId, moduleId } = info;
  const { currentTarget, target, pageX, pageY, changedTouches = [], touches = [] } = event;
  if (pageX !== void 0 && pageY !== void 0) {
    detail.x = pageX;
    detail.y = pageY;
  }
  const currentTargetInfo = currentTarget ? {
    id: currentTarget.id,
    dataset: { ...currentTarget.dataset, ...currentTarget._ds },
    offsetLeft: currentTarget.offsetLeft,
    offsetTop: currentTarget.offsetTop
  } : {};
  const targetInfo = target ? {
    id: target.id,
    dataset: { ...target.dataset, ...target._ds },
    offsetLeft: target.offsetLeft,
    offsetTop: target.offsetTop
  } : {};
  const successId = success && window.__callback.store(success);
  window.__message.send({
    type: "t",
    target: "service",
    body: {
      bridgeId,
      moduleId,
      methodName,
      success: successId,
      event: {
        type: type2,
        // 代表事件的类型
        timeStamp: Date.now() - initTimeStamp,
        // 页面打开到触发事件所经过的毫秒数
        detail,
        // 自定义事件所携带的数据
        currentTarget: currentTargetInfo,
        // 当前处理事件的元素（即绑定事件监听器的元素）
        target: targetInfo,
        // 触发事件的元素
        changedTouches: Array.from(changedTouches).map((touch) => ({
          clientX: touch.clientX,
          clientY: touch.clientY,
          force: touch.force,
          identifier: touch.identifier,
          pageX: touch.pageX,
          pageY: touch.pageY,
          screenX: touch.screenX,
          screenY: touch.screenY
        })),
        touches: Array.from(touches).map((touch) => ({
          clientX: touch.clientX,
          clientY: touch.clientY,
          force: touch.force,
          identifier: touch.identifier,
          pageX: touch.pageX,
          pageY: touch.pageY,
          screenX: touch.screenX,
          screenY: touch.screenY
        }))
      }
    }
  });
}
function invokeAPI(apiName, { params, bridgeId }) {
  window.__message.invoke({
    type: "invokeAPI",
    target: "container",
    body: {
      name: apiName,
      bridgeId,
      params
    }
  });
}
function onEvent(eventName, callback2) {
  window.__message.on(eventName, (msg) => {
    callback2 == null ? void 0 : callback2(msg);
  });
}
function offEvent(eventName) {
  window.__message.off(eventName);
}
const _sfc_main$D = {
  __name: "Block",
  setup(__props) {
    useInfo();
    return (_ctx, _cache) => {
      return renderSlot(_ctx.$slots, "default");
    };
  }
};
function getActualBottom(element) {
  if (!element) {
    return 0;
  }
  const rect = element.getBoundingClientRect();
  const visualViewport = window.visualViewport;
  const viewportHeight = visualViewport ? visualViewport.height : window.innerHeight;
  return viewportHeight - rect.bottom - rect.height;
}
function withInstall(comp) {
  const name = camelCaseToUnderscore(comp.__name);
  comp.__tagName = name;
  comp.install = (app) => {
    install(app, comp);
  };
  return comp;
}
const componentPrefix = "dd-";
function install(app, component) {
  app.component(
    componentPrefix + component.__tagName,
    component
  );
}
function deepToRaw(obj) {
  if (typeof obj !== "object" || obj === null) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj.map((item) => deepToRaw(item));
  }
  const result = {};
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      const value = obj[key];
      if (isRef(value)) {
        result[key] = unref(value);
      } else if (isReactive(value)) {
        result[key] = toRaw(value);
      } else if (typeof value === "object" && value !== null) {
        result[key] = deepToRaw(value);
      } else {
        result[key] = value;
      }
    }
  }
  return result;
}
const index$D = withInstall(_sfc_main$D);
const __vite_glob_0_0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$D
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$i = ["id", "type", "size", "loading", "plain", "disabled"];
const _sfc_main$C = {
  __name: "Button",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * 按钮的大小
     * 合法值 default, mini
     */
    size: {
      type: String,
      default: "default",
      validator: (value) => {
        return ["default", "mini"].includes(value);
      }
    },
    /**
     * 按钮的样式类型
     * 合法值 primary default warn
     */
    type: {
      type: String,
      default: "default",
      validator: (value) => {
        return ["primary", "default", "warn"].includes(value);
      }
    },
    /**
     * 按钮是否镂空，背景色透明
     */
    plain: {
      type: Boolean,
      default: false
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * 名称前是否带 loading 图标
     */
    loading: {
      type: Boolean
    },
    /**
     * 用于 form 组件，点击分别会触发 form 组件的 submit/reset 事件
     * 合法值 submit, reset
     */
    formType: {
      type: String,
      validator: (value) => {
        return ["submit", "reset"].includes(value);
      }
    },
    /**
     * 开放能力，暂不实现
     */
    openType: {
      type: String,
      validator: (value) => {
        return [
          "contact",
          "liveActivity",
          "share",
          "getPhoneNumber",
          "getRealtimePhoneNumber",
          "getUserInfo",
          "launchApp",
          "openSetting",
          "feedback",
          "chooseAvatar",
          "agreePrivacyAuthorization"
        ].includes(value);
      }
    },
    /**
     * 指定按钮按下去的样式类。当 hover-class="none" 时，没有点击态效果
     */
    hoverClass: {
      type: String,
      default: "button-hover"
    },
    /**
     * 指定是否阻止本节点的祖先节点出现点击态
     */
    hoverStopPropagation: {
      type: Boolean,
      default: false
    },
    /**
     * 按住后多久出现点击态，单位毫秒
     */
    hoverStartTime: {
      type: Number,
      default: 20
    },
    /**
     * 手指松开后点击态保留时间，单位毫秒
     */
    hoverStayTime: {
      type: Number,
      default: 70
    }
  },
  setup(__props) {
    const props = __props;
    const plainParsed = computed(() => {
      return Boolean(props.plain) === true ? true : void 0;
    });
    const disabledParsed = computed(() => {
      return Boolean(props.disabled) === true ? true : void 0;
    });
    const loadingParsed = computed(() => {
      return Boolean(props.loading) === true ? true : void 0;
    });
    const isActive = ref(false);
    const info = useInfo();
    const handleFormEvent = inject("formEvent", void 0);
    function handleClicked(event) {
      if (!props.disabled) {
        if (props.hoverStopPropagation) {
          event.stopPropagation();
        }
        if (props.formType) {
          handleFormEvent == null ? void 0 : handleFormEvent(event, props.formType);
        } else {
          triggerEvent("tap", { event, info });
        }
      }
    }
    async function handleDown() {
      if (!props.disabled) {
        await sleep(props.hoverStartTime);
        isActive.value = true;
      }
    }
    async function handleUp() {
      if (!props.disabled) {
        await sleep(props.hoverStayTime);
        isActive.value = false;
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", mergeProps({ id: __props.id }, _ctx.$attrs, {
        class: ["dd-button", [unref(isActive) ? __props.hoverClass : void 0]],
        type: __props.type,
        size: __props.size,
        loading: unref(loadingParsed),
        plain: unref(plainParsed),
        disabled: unref(disabledParsed),
        onClick: handleClicked,
        onMousedown: handleDown,
        onMouseup: handleUp
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16, _hoisted_1$i);
    };
  }
};
const index$C = withInstall(_sfc_main$C);
const __vite_glob_0_1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$C
}, Symbol.toStringTag, { value: "Module" }));
const type$2 = "native/camera";
const _sfc_main$B = {
  __name: "Camera",
  props: {
    /**
     * 应用模式，只在初始化时有效，不能动态变更
     * 合法值 normal, scanCode
     */
    mode: {
      type: String,
      default: "normal",
      validator: (value) => {
        return ["normal", "scanCode"].includes(value);
      }
    },
    /**
     * 分辨率，不支持动态修改
     * 合法值 low medium high
     */
    resolution: {
      type: String,
      default: "medium",
      validator: (value) => {
        return ["low", "medium", "high"].includes(value);
      }
    },
    /**
     * 摄像头朝向
     * 合法值 front back
     */
    devicePosition: {
      type: String,
      default: "back",
      validator: (value) => {
        return ["front", "back"].includes(value);
      }
    },
    /**
     * 闪光灯
     * 合法值 auto, on, off, torch
     */
    flash: {
      type: String,
      default: "auto",
      validator: (value) => {
        return ["auto", "on", "off", "torch"].includes(value);
      }
    },
    /**
     * 指定期望的相机帧数据尺寸
     * 合法值 small medium large
     */
    frameSize: {
      type: String,
      default: "medium",
      validator: (value) => {
        return ["small", "medium", "large"].includes(value);
      }
    }
  },
  setup(__props) {
    const props = __props;
    useInfo();
    watch([() => props.devicePosition, () => props.devicePosition, () => props.flash, () => props.frameSize], ([newDevicePosition, newFlash, newFrameSize], [oldDevicePosition, oldFlash, oldFrameSize]) => {
    });
    onMounted(() => {
    });
    onBeforeUnmount(() => {
    });
    return (_ctx, _cache) => {
      return unref(isDesktop) ? (openBlock(), createElementBlock("div", mergeProps({ key: 0 }, _ctx.$attrs, { class: "dd-camera dd-camera-desktop" }), " 未找到摄像头 ", 16)) : unref(isIOS) ? (openBlock(), createElementBlock("div", mergeProps({ key: 1 }, _ctx.$attrs, { class: "dd-camera" }), _cache[0] || (_cache[0] = [
        createBaseVNode("div", { class: "dd-camera-container" }, [
          createBaseVNode("div", { style: { "width": "101%", "height": "101%" } })
        ], -1)
      ]), 16)) : unref(isAndroid) ? (openBlock(), createElementBlock("embed", mergeProps({ key: 2 }, _ctx.$attrs, {
        class: "dd-camera",
        type: "application/view",
        comp_type: type$2
      }), null, 16)) : unref(isHarmonyOS) ? (openBlock(), createElementBlock("embed", mergeProps({ key: 3 }, _ctx.$attrs, {
        class: "dd-camera",
        type: type$2
      }), null, 16)) : createCommentVNode("", true);
    };
  }
};
const index$B = withInstall(_sfc_main$B);
const __vite_glob_0_2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$B
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$h = ["id"];
const _sfc_main$A = {
  __name: "CheckboxGroup",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * name，为表单使用
     */
    name: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    const collectFormValue = inject("collectFormValue", void 0);
    const selected = ref([]);
    function selectValue(value) {
      if (value !== void 0) {
        if (selected.value.includes(value)) {
          selected.value = selected.value.filter((item) => item !== value);
        } else {
          selected.value.push(value);
        }
      }
      collectFormValue == null ? void 0 : collectFormValue(props.name, toRaw(selected.value));
    }
    const info = useInfo();
    function handleValueChange(event) {
      const v = toRaw(selected.value);
      collectFormValue == null ? void 0 : collectFormValue(props.name, v);
      triggerEvent("change", {
        event,
        info,
        detail: {
          value: v
        }
      });
    }
    provide("selected", selected);
    provide("selectValue", selectValue);
    provide("handleValueChange", handleValueChange);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, { class: "dd-checkbox-group" }), [
        renderSlot(_ctx.$slots, "default")
      ], 16, _hoisted_1$h);
    };
  }
};
const index$A = withInstall(_sfc_main$A);
const __vite_glob_0_3 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$A
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$g = { class: "dd-checkbox-wrapper" };
const _sfc_main$z = {
  __name: "Checkbox",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * checkbox标识，选中时触发checkbox-group的 change 事件，并携带 checkbox 的 value。
     */
    value: {
      type: String
    },
    /**
     * 是否禁用 checkbox。
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * 当前是否选中，可用来设置默认选中。
     */
    checked: {
      type: Boolean,
      default: false
    },
    /**
     * checkbox颜色，同css的color。
     */
    color: {
      type: String,
      default: "#09BB07"
    }
  },
  setup(__props) {
    const props = __props;
    const selectValue = inject("selectValue", void 0);
    const selected = inject("selected", ref(props.checked ? [props.value] : []));
    if (props.checked) {
      selectValue == null ? void 0 : selectValue(props.value);
    } else {
      selectValue == null ? void 0 : selectValue(void 0);
    }
    const isOn2 = computed(() => {
      return selected.value.includes(props.value);
    });
    const computedStyle = computed(() => {
      if (props.color && isOn2.value) {
        return {
          color: props.color
        };
      } else {
        return void 0;
      }
    });
    const handleValueChange = inject("handleValueChange", void 0);
    function handleClicked(event) {
      if (!props.disabled) {
        if (typeof selectValue === "function") {
          selectValue(props.value);
        } else {
          if (selected.value.includes(props.value)) {
            selected.value = selected.value.filter((item) => item !== props.value);
          } else {
            selected.value.push(props.value);
          }
        }
        handleValueChange == null ? void 0 : handleValueChange(event);
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-checkbox" }), [
        createBaseVNode("div", _hoisted_1$g, [
          createBaseVNode("div", {
            class: normalizeClass(["dd-checkbox-input", { "dd-checkbox-input-checked": unref(isOn2), "dd-checkbox-input-disabled": __props.disabled }]),
            style: normalizeStyle(unref(computedStyle)),
            onClick: handleClicked
          }, null, 6)
        ])
      ], 16);
    };
  }
};
const index$z = withInstall(_sfc_main$z);
const __vite_glob_0_4 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$z
}, Symbol.toStringTag, { value: "Module" }));
function useLongPress(info, threshold = 350, moveThreshold = 10) {
  const longPressTimer = ref(null);
  const touchStartPosition = ref({ x: 0, y: 0 });
  const isTouchMoved = ref(false);
  function onTouchStart(event) {
    const currentTarget = event.currentTarget;
    const touch = event.touches[0];
    touchStartPosition.value = { x: touch.clientX, y: touch.clientY };
    isTouchMoved.value = false;
    if (longPressTimer.value) {
      clearTimeout(longPressTimer.value);
    }
    longPressTimer.value = setTimeout(() => {
      if (!isTouchMoved.value) {
        triggerEvent("longpress", { event: { ...event, currentTarget }, info });
      }
      longPressTimer.value = null;
    }, threshold);
    triggerEvent("touchstart", { event, info });
  }
  function onTouchMove(event) {
    const touch = event.touches[0];
    const moveX = Math.abs(touch.clientX - touchStartPosition.value.x);
    const moveY = Math.abs(touch.clientY - touchStartPosition.value.y);
    if (moveX > moveThreshold || moveY > moveThreshold) {
      isTouchMoved.value = true;
      if (longPressTimer.value) {
        clearTimeout(longPressTimer.value);
        longPressTimer.value = null;
      }
    }
    triggerEvent("touchmove", { event, info });
  }
  function onTouchEnd(event) {
    if (longPressTimer.value) {
      clearTimeout(longPressTimer.value);
      longPressTimer.value = null;
    }
    triggerEvent("touchend", { event, info });
  }
  function onTouchCancel(event) {
    if (longPressTimer.value) {
      clearTimeout(longPressTimer.value);
      longPressTimer.value = null;
    }
    triggerEvent("touchcancel", { event, info });
  }
  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
    onTouchCancel
  };
}
const _hoisted_1$f = ["src"];
const _sfc_main$y = {
  __name: "Image",
  props: {
    src: {
      type: String,
      default: ""
    },
    mode: {
      type: String,
      validator: (val) => {
        return ["scaleToFill", "aspectFit", "aspectFill", "widthFix", "heightFix", "top", "bottom", "center", "left", "right", "top left", "top right", "bottom left", "bottom right"].includes(val);
      }
    }
  },
  setup(__props) {
    const props = __props;
    const MODE_CLASS_MAP = {
      "scaleToFill": "dd-image-scale",
      "aspectFit": "dd-image-aspect",
      "aspectFill": "dd-image-fill",
      "widthFix": "dd-image-width",
      "heightFix": "dd-image-height",
      "top": "dd-image-top",
      "bottom": "dd-image-bottom",
      "center": "dd-image-center",
      "left": "dd-image-left",
      "right": "dd-image-right",
      "top left": "dd-image-top-left",
      "top right": "dd-image-top-right",
      "bottom left": "dd-image-bottom-left",
      "bottom right": "dd-image-bottom-right"
    };
    const dynamicClass = computed(() => MODE_CLASS_MAP[props.mode] || "");
    const imgRef = ref(null);
    const conRef = ref(null);
    const info = useInfo();
    onMounted(() => {
      if (props.mode === "widthFix") {
        conRef.value.style.height = "auto";
      } else if (props.mode === "heightFix") {
        conRef.value.style.width = "auto";
      }
    });
    function handleLoaded(event) {
      var _a, _b;
      triggerEvent("load", {
        event,
        info,
        detail: {
          width: (_a = imgRef.value) == null ? void 0 : _a.width,
          height: (_b = imgRef.value) == null ? void 0 : _b.height
        }
      });
    }
    function handleError2(event) {
      triggerEvent("error", {
        event,
        info,
        detail: {
          errMsg: props.src
        }
      });
    }
    function handleClicked(event) {
      if (!props.disabled) {
        if (props.hoverStopPropagation) {
          event.stopPropagation();
        }
        triggerEvent("tap", { event, info });
      }
    }
    const { onTouchStart, onTouchMove, onTouchEnd, onTouchCancel } = useLongPress(info);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", mergeProps({
        ref_key: "conRef",
        ref: conRef
      }, _ctx.$attrs, {
        class: "dd-image",
        onClick: handleClicked,
        onTouchstart: _cache[0] || (_cache[0] = (...args) => unref(onTouchStart) && unref(onTouchStart)(...args)),
        onTouchmove: _cache[1] || (_cache[1] = (...args) => unref(onTouchMove) && unref(onTouchMove)(...args)),
        onTouchend: _cache[2] || (_cache[2] = (...args) => unref(onTouchEnd) && unref(onTouchEnd)(...args)),
        onTouchcancel: _cache[3] || (_cache[3] = (...args) => unref(onTouchCancel) && unref(onTouchCancel)(...args))
      }), [
        createBaseVNode("img", {
          ref_key: "imgRef",
          ref: imgRef,
          class: normalizeClass(unref(dynamicClass)),
          src: __props.src,
          alt: "",
          decoding: "async",
          loading: "lazy",
          onLoad: handleLoaded,
          onError: handleError2
        }, null, 42, _hoisted_1$f)
      ], 16);
    };
  }
};
const _sfc_main$x = {
  __name: "CoverImage",
  props: {
    src: {
      type: String,
      default: ""
    }
  },
  setup(__props) {
    const props = __props;
    useInfo();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$y, mergeProps(_ctx.$attrs, {
        src: props.src
      }), null, 16, ["src"]);
    };
  }
};
const index$y = withInstall(_sfc_main$x);
const __vite_glob_0_5 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$y
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$w = {
  __name: "View",
  setup(__props) {
    const info = useInfo();
    function onClicked(event) {
      triggerEvent("tap", { event, info });
    }
    const { onTouchStart, onTouchMove, onTouchEnd, onTouchCancel } = useLongPress(info);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
        class: "dd-view",
        onClick: onClicked,
        onTouchstart: _cache[0] || (_cache[0] = (...args) => unref(onTouchStart) && unref(onTouchStart)(...args)),
        onTouchmove: _cache[1] || (_cache[1] = (...args) => unref(onTouchMove) && unref(onTouchMove)(...args)),
        onTouchend: _cache[2] || (_cache[2] = (...args) => unref(onTouchEnd) && unref(onTouchEnd)(...args)),
        onTouchcancel: _cache[3] || (_cache[3] = (...args) => unref(onTouchCancel) && unref(onTouchCancel)(...args))
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const _sfc_main$v = {
  __name: "CoverView",
  setup(__props) {
    useInfo();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$w, normalizeProps(guardReactiveProps(_ctx.$attrs)), {
        default: withCtx(() => [
          renderSlot(_ctx.$slots, "default")
        ]),
        _: 3
      }, 16);
    };
  }
};
const index$x = withInstall(_sfc_main$v);
const __vite_glob_0_6 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$x
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$u = {
  __name: "Form",
  props: {
    /**
     * 是否返回 formId 用于发送模板消息
     */
    reportSubmit: {
      type: Boolean,
      default: false,
      required: false
      // 由于“否”表示不是必填项，所以设置为 false
    },
    /**
     * 等待一段时间（毫秒数）以确认 formId 是否生效。
     * 如果未指定这个参数，formId 有很小的概率是无效的（如遇到网络失败的情况）。
     * 指定这个参数将可以检测 formId 是否有效，以这个参数的时间作为这项检测的超时时间。
     * 如果失败，将返回 requestFormId:fail 开头的 formId
     */
    reportSubmitTimeout: {
      type: Number,
      default: 0,
      required: false
      // 由于“否”表示不是必填项，所以设置为 false
    }
  },
  setup(__props) {
    const formValues = ref({});
    function collectFormValue(name, value) {
      formValues.value[name] = value;
    }
    provide("collectFormValue", collectFormValue);
    const info = useInfo();
    function handleEvent(event, formType) {
      event.stopPropagation();
      if (formType === "submit") {
        triggerEvent("submit", {
          event,
          info,
          detail: {
            value: toRaw(formValues.value)
          }
        });
      } else if (formType === "reset") {
        triggerEvent("reset", {
          event,
          info
        });
      }
    }
    provide("formEvent", handleEvent);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", normalizeProps(guardReactiveProps(_ctx.$attrs)), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$w = withInstall(_sfc_main$u);
const __vite_glob_0_7 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$w
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$e = ["title"];
const _sfc_main$t = {
  __name: "Icon",
  props: {
    /**
     * icon的类型
     * 合法值 success, success_no_circle, info, warn, waiting, cancel,
     * download, search, clear, circle
     */
    type: {
      type: String,
      required: true
    },
    /**
     * icon的大小，单位默认为px，支持传入单位(rpx/px/rem)
     */
    size: {
      type: [Number, String],
      default: 23
    },
    /**
     * icon的颜色，同css的color
     */
    color: {
      type: String
    }
  },
  setup(__props) {
    useCssVars((_ctx) => ({
      "ca781606": unref(iSize),
      "86488c32": unref(iColor)
    }));
    const props = __props;
    const iClass = computed(() => {
      switch (props.type) {
        case "success":
          return "dd-icon-success";
        case "success_circle":
          return "dd-icon-success_circle";
        case "success_no_circle":
          return "dd-icon-success_no_circle";
        case "info":
          return "dd-icon-info";
        case "info_circle":
          return "dd-icon-info_circle";
        case "warn":
          return "dd-icon-warn";
        case "waiting":
          return "dd-icon-waiting";
        case "cancel":
          return "dd-icon-cancel";
        case "download":
          return "dd-icon-download";
        case "search":
          return "dd-icon-search";
        case "clear":
          return "dd-icon-clear";
        case "circle":
          return "dd-icon-circle";
        default:
          return "dd-icon-success";
      }
    });
    const iTitle = computed(() => {
      switch (props.type) {
        case "success":
        case "success_circle":
        case "success_no_circle":
          return "成功";
        case "info":
        case "info_circle":
          return "信息";
        case "warn":
          return "警告";
        case "waiting":
          return "等待";
        case "cancel":
          return "取消";
        case "download":
          return "下载";
        case "search":
          return "搜索";
        case "clear":
          return "清除";
        case "circle":
          return "空选";
        default:
          return "成功";
      }
    });
    const unit = /(?:\d+px|\d+rem)$/;
    const iSize = computed(() => {
      let size;
      if (!props.size) {
        size = "23px";
      } else {
        size = transformRpx(props.size);
      }
      if (!unit.test(size)) {
        size += "px";
      }
      return size;
    });
    const iColor = computed(() => {
      return props.color || "initial";
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("i", mergeProps(_ctx.$attrs, {
        title: unref(iTitle),
        class: ["dd-icon", unref(iClass)]
      }), null, 16, _hoisted_1$e);
    };
  }
};
const index$v = withInstall(_sfc_main$t);
const __vite_glob_0_8 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$v
}, Symbol.toStringTag, { value: "Module" }));
const index$u = withInstall(_sfc_main$y);
const __vite_glob_0_9 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$u
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$d = ["id", "type", "inputmode", "maxlength", "value", "disabled"];
const _sfc_main$s = {
  __name: "Input",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * name，为表单使用
     */
    name: {
      type: String
    },
    /**
     * 输入框的初始内容
     */
    value: {
      type: String,
      default: ""
    },
    /**
     * input 的类型
     * 合法值: text, number, idcard, digit, safe-password, nickname
     */
    type: {
      type: String,
      default: "text",
      validator: (value) => {
        return ["text", "number", "idcard", "digit", "safe-password", "nickname"].includes(value);
      }
    },
    /**
     * 是否是密码类型
     */
    password: {
      type: Boolean,
      default: false
    },
    /**
     * 输入框为空时占位符
     */
    placeholder: {
      type: String,
      required: true
    },
    /**
     * 指定 placeholder 的样式，目前仅支持color,font-size和font-weight
     */
    placeholderStyle: {
      type: [String, Object],
      default() {
        return {};
      }
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * 最大输入长度，设置为 -1 的时候不限制最大长度
     */
    maxlength: {
      type: [Number, String],
      default: 140
    },
    /**
     * 指定光标与键盘的距离，取 input 距离底部的距离和 cursor-spacing 指定的距离的最小值作为光标与键盘的距离
     */
    cursorSpacing: {
      type: Number,
      default: 0
    },
    /**
     * (即将废弃，请直接使用 focus )自动聚焦，拉起键盘
     */
    autoFocus: {
      type: Boolean,
      default: false
    },
    /**
     * 获取焦点
     */
    focus: {
      type: Boolean,
      default: false
    },
    /**
     * 设置键盘右下角按钮的文字，仅在type='text'时生效
     * 合法值: send, search, next, go, done
     */
    confirmType: {
      type: String,
      default: "done",
      validator: (value) => {
        return ["send", "search", "next", "go", "done"].includes(value);
      }
    },
    /**
     * 强制 input 处于同层状态，默认 focus 时 input 会切到非同层状态 (仅在 iOS 下生效)
     */
    alwaysEmbed: {
      type: Boolean,
      default: false
    },
    /**
     * 点击键盘右下角按钮时是否保持键盘不收起
     */
    confirmHold: {
      type: Boolean,
      default: false
    },
    /**
     * 指定focus时的光标位置
     */
    cursor: {
      type: Number
    },
    /**
     * 光标颜色。iOS 下的格式为十六进制颜色值 #000000，安卓下的只支持 default 和 green
     */
    cursorColor: {
      type: String
    },
    /**
     * 光标起始位置，自动聚集时有效，需与selection-end搭配使用
     */
    selectionStart: {
      type: Number,
      default: -1
    },
    selectionEnd: {
      type: Number,
      default: -1
    },
    /**
     * 键盘弹起时，是否自动上推页面
     */
    adjustPosition: {
      type: Boolean,
      default: true
    },
    /**
     * focus时，点击页面的时候不收起键盘
     */
    holdKeyboard: {
      type: Boolean,
      default: false
    },
    /**
     * WebView 特有属性
     * 指定 placeholder 的样式类，目前仅支持color,font-size和font-weight
     */
    placeholderClass: {
      type: String,
      default: "input-placeholder"
    }
  },
  emits: ["update:value"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit2 = __emit;
    const wrapperClass = computed(() => {
      return {
        "dd-input-wrapper": true,
        "dd-input-disabled": props.disabled
      };
    });
    const inputType = computed(() => {
      if (props.password || props.type === "safe-password") {
        return "password";
      }
      return props.type === "number" || props.type === "digit" ? "text" : props.type;
    });
    const inputMode = computed(() => {
      switch (props.type) {
        case "number":
          return "numeric";
        case "digit":
          return "decimal";
        default:
          return "text";
      }
    });
    const computedPlaceholderStyle = computed(() => {
      const placeholderColor = () => {
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/color:([^;]+)/);
          if (match) {
            return match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "color")) {
            return props.placeholderStyle.color;
          }
        }
        return "rgba(0,0,0,.3)";
      };
      const placeholderFontSize = () => {
        let size;
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/font-size:([^;]+)/);
          if (match) {
            size = match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-size")) {
            size = props.placeholderStyle["font-size"];
          }
        }
        return size ? transformRpx(size) : "inherit";
      };
      const placeholderFontWeight = () => {
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/font-weight:([^;]+)/);
          if (match) {
            return match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-weight")) {
            return props.placeholderStyle["font-weight"];
          }
        }
        return "inherit";
      };
      return {
        color: placeholderColor(),
        fontSize: placeholderFontSize(),
        fontWeight: placeholderFontWeight()
      };
    });
    const collectFormValue = inject("collectFormValue", void 0);
    collectFormValue == null ? void 0 : collectFormValue(props.name, props.value);
    const iValue = ref(props.value);
    const placeholderShow = computed(() => {
      var _a;
      return !iValue.value || ((_a = iValue.value) == null ? void 0 : _a.length) === 0;
    });
    const inputRef = ref(null);
    const keyCode = ref(null);
    const vFocus = {
      mounted: async (el) => {
        if (!props.autoFocus) {
          return;
        }
        if (isDesktop) {
          await sleep(540);
        }
        el.focus();
      }
    };
    watch(
      [() => props.focus, () => props.value],
      ([nF, nV], [, preV]) => {
        nF && inputRef.value.focus();
        if (preV !== nV) {
          iValue.value = nV;
        }
      }
    );
    const wrapperRef = ref(null);
    const info = useInfo();
    function handleKeydown(event) {
      keyCode.value = event.keyCode;
      if (event.keyCode === 13) {
        if (!props.confirmHold) {
          event.target.blur();
        }
        triggerEvent("confirm", {
          event,
          info,
          detail: {
            value: event.target.value
          }
        });
      }
    }
    function handleWrapperEvent(event) {
      if (event.target.tagName.toLowerCase() !== "input") {
        return;
      }
      const value = event.target.value;
      switch (event.type) {
        case "input":
          collectFormValue == null ? void 0 : collectFormValue(props.name, value);
          iValue.value = value;
          emit2("update:value", value);
          triggerEvent("input", {
            event,
            info,
            detail: {
              value,
              cursor: event.target.selectionEnd,
              keyCode: keyCode.value
            },
            success: (data) => {
              iValue.value = data.value ?? data;
              emit2("update:value", data.value ?? data);
            }
          });
          break;
        case "focusin":
          triggerEvent("focus", {
            event,
            info,
            detail: {
              value
            }
          });
          if (!isDesktop && props.adjustPosition) {
            const element = wrapperRef.value;
            if (!element) {
              return;
            }
            const bottom = getActualBottom(element);
            invokeAPI("adjustPosition", {
              bridgeId: info.bridgeId,
              params: {
                bottom
              }
            });
          }
          break;
        case "focusout":
          triggerEvent("blur", {
            event,
            info,
            detail: {
              value,
              cursor: event.target.selectionEnd
            }
          });
          break;
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({
        ref_key: "wrapperRef",
        ref: wrapperRef
      }, _ctx.$attrs, {
        class: unref(wrapperClass),
        role: "textbox",
        onInput: handleWrapperEvent,
        onFocusin: handleWrapperEvent,
        onFocusout: handleWrapperEvent
      }), [
        withDirectives(createBaseVNode("input", {
          id: __props.id,
          ref_key: "inputRef",
          ref: inputRef,
          class: "dd-input",
          type: unref(inputType),
          inputmode: unref(inputMode),
          maxlength: __props.maxlength,
          value: unref(iValue),
          disabled: __props.disabled,
          onKeydown: handleKeydown
        }, null, 40, _hoisted_1$d), [
          [vFocus]
        ]),
        withDirectives(createBaseVNode("div", {
          class: normalizeClass(["dd-input-placeholder", __props.placeholderClass]),
          style: normalizeStyle(unref(computedPlaceholderStyle))
        }, toDisplayString(__props.placeholder), 7), [
          [vShow, unref(placeholderShow)]
        ])
      ], 16);
    };
  }
};
const index$t = withInstall(_sfc_main$s);
const __vite_glob_0_10 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$t
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$r = {
  __name: "KeyboardAccessory",
  setup(__props) {
    return (_ctx, _cache) => {
      return renderSlot(_ctx.$slots, "default");
    };
  }
};
const index$s = withInstall(_sfc_main$r);
const __vite_glob_0_11 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$s
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$c = ["for"];
const _sfc_main$q = {
  __name: "Label",
  props: {
    /**
     * 绑定控件的 id
     */
    for: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("label", mergeProps(_ctx.$attrs, {
        for: props.for
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16, _hoisted_1$c);
    };
  }
};
const index$r = withInstall(_sfc_main$q);
const __vite_glob_0_12 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$r
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$b = ["id"];
const type$1 = "native/map";
const _sfc_main$p = {
  __name: "Map",
  props: {
    /**
     * 地图 id
     */
    id: {
      type: String,
      default: `map_${Date.now()}_${String(Math.random()).slice(-3)}`
    },
    /**
     * 中心经度
     */
    longitude: {
      type: Number,
      required: true
    },
    /**
     * 中心纬度
     */
    latitude: {
      type: Number,
      required: true
    },
    /**
     * 缩放级别，取值范围为3-20
     */
    scale: {
      type: Number,
      default: 16
    },
    /**
     * 最小缩放级别
     */
    minScale: {
      type: Number,
      default: 3
    },
    /**
     * 最大缩放级别
     */
    maxScale: {
      type: Number,
      default: 20
    },
    /**
     * 标记点
     */
    markers: {
      type: Array
    },
    /**
     * 路线
     */
    polyline: {
      type: Array
    },
    /**
     * 圆
     */
    circles: {
      type: Array
    },
    /**
     * 缩放视野以包含所有给定的坐标点
     */
    includePoints: {
      type: Array
    },
    /**
     * 显示带有方向的当前定位点
     */
    showLocation: {
      type: Boolean,
      default: false
    },
    /**
     * 多边形
     */
    polygons: {
      type: Array
    },
    /**
     * 旋转角度，范围 0 ~ 360, 地图正北和设备 y 轴角度的夹角
     */
    rotate: {
      type: Number,
      default: 0
    },
    /**
     * 倾斜角度，范围 0 ~ 40 , 关于 z 轴的倾角
     */
    skew: {
      type: Number,
      default: 0
    },
    /**
     * 展示3D楼块
     */
    enable3D: {
      type: Boolean,
      default: false
    },
    /**
     * 显示指南针
     */
    showCompass: {
      type: Boolean,
      default: false
    },
    /**
     * 显示比例尺
     */
    showScale: {
      type: Boolean,
      default: false
    },
    /**
     * 开启俯视
     */
    enableOverlooking: {
      type: Boolean,
      default: false
    },
    /**
     * 开启最大俯视角，俯视角度从 45 度拓展到 75 度
     */
    enableAutoMaxOverlooking: {
      type: Boolean,
      default: false
    },
    /**
     * 是否支持缩放
     */
    enableZoom: {
      type: Boolean,
      default: true
    },
    /**
     * 是否支持拖动
     */
    enableScroll: {
      type: Boolean,
      default: true
    },
    /**
     * 是否支持旋转
     */
    enableRotate: {
      type: Boolean,
      default: false
    },
    /**
     * 是否开启卫星图
     */
    enableSatellite: {
      type: Boolean,
      default: false
    },
    /**
     * 是否开启实时路况
     */
    enableTraffic: {
      type: Boolean,
      default: false
    },
    /**
     * 是否展示 POI 点
     */
    enablePOI: {
      type: Boolean,
      default: true
    },
    /**
     * 是否展示建筑物
     */
    enableBuilding: {
      type: Boolean
    }
  },
  setup(__props) {
    const props = __props;
    const info = useInfo();
    watch(
      [
        () => props.longitude,
        () => props.latitude,
        () => props.scale,
        () => props.markers,
        () => props.polyline,
        () => props.polygons,
        () => props.circles,
        () => props.includePoints,
        () => props.showLocation
      ],
      ([newLongitude, newLatitude, newScale, newMarkers, newPolyline, newPolygons, newCircles, newIncludePoints, newShowLocation], [oldLongitude, oldLatitude, oldScale, oldMarkers, oldPolyline, oldPolygons, oldCircles, oldIncludePoints, oldShowLocation]) => {
        const params = { type: type$1, id: props.id };
        if (newScale !== oldScale) {
          params.scale = newScale;
        }
        if (newMarkers !== oldMarkers) {
          params.markers = newMarkers;
        }
        if (newPolyline !== oldPolyline) {
          params.polyline = newPolyline;
        }
        if (newPolygons !== oldPolygons) {
          params.polygons = newPolygons;
        }
        if (newCircles !== oldCircles) {
          params.circles = newCircles;
        }
        if (newIncludePoints !== oldIncludePoints) {
          params.includePoints = newIncludePoints;
          params.longitude = newLongitude;
          params.latitude = newLatitude;
        } else {
          if (newLongitude !== oldLongitude || newLatitude !== oldLatitude) {
            params.longitude = newLongitude;
            params.latitude = newLatitude;
          }
        }
        if (newShowLocation !== oldShowLocation) {
          params.showLocation = newShowLocation;
        }
        invokeAPI("propsUpdate", {
          bridgeId: info.bridgeId,
          params
        });
      }
    );
    onBeforeMount(() => {
      onEvent("bindcallouttap", (msg) => {
        triggerEvent("callouttap", {
          info,
          detail: {
            id: msg.id,
            markerId: msg.markerId,
            longitude: msg.longitude,
            latitude: msg.latitude
          }
        });
      });
      onEvent("bindmarkertap", (msg) => {
        triggerEvent("markertap", {
          info,
          detail: {
            id: msg.id,
            markerId: msg.markerId,
            longitude: msg.longitude,
            latitude: msg.latitude
          }
        });
      });
      onEvent("bindregionchange", (msg) => {
        triggerEvent("regionchange", {
          info,
          detail: msg
        });
      });
      onEvent("bindtap", (msg) => {
        triggerEvent("tap", {
          info,
          detail: {
            markerId: msg.markerId
          }
        });
      });
      invokeAPI("componentMount", {
        bridgeId: info.bridgeId,
        params: {
          type: type$1,
          id: props.id,
          longitude: props.longitude,
          latitude: props.latitude,
          scale: props.scale,
          markers: props.markers,
          polyline: props.polyline,
          polygons: props.polygons,
          circles: props.circles,
          includePoints: props.includePoints,
          showLocation: props.showLocation
        }
      });
    });
    onBeforeUnmount(() => {
      invokeAPI("componentUnmount", {
        bridgeId: info.bridgeId,
        params: {
          type: type$1,
          id: props.id,
          longitude: props.longitude,
          latitude: props.latitude,
          scale: props.scale,
          markers: props.markers,
          polyline: props.polyline,
          polygons: props.polygons,
          circles: props.circles,
          includePoints: props.includePoints,
          showLocation: props.showLocation
        }
      });
      offEvent("bindcallouttap");
      offEvent("bindmarkertap");
      offEvent("bindregionchange");
      offEvent("bindtap");
    });
    return (_ctx, _cache) => {
      return unref(isDesktop) ? (openBlock(), createElementBlock("div", mergeProps({ key: 0 }, _ctx.$attrs, { class: "dd-map dd-map-desktop" }), " 未实现组件 ", 16)) : unref(isIOS) ? (openBlock(), createElementBlock("div", mergeProps({ key: 1 }, _ctx.$attrs, { class: "dd-map" }), _cache[0] || (_cache[0] = [
        createBaseVNode("div", { class: "dd-map-container" }, [
          createBaseVNode("div", { style: { "width": "101%", "height": "101%" } })
        ], -1)
      ]), 16)) : unref(isAndroid) ? (openBlock(), createElementBlock("embed", mergeProps({ key: 2 }, _ctx.$attrs, {
        class: "dd-map",
        type: "application/view",
        comp_type: type$1
      }), null, 16)) : unref(isHarmonyOS) ? (openBlock(), createElementBlock("embed", mergeProps({
        key: 3,
        id: __props.id
      }, _ctx.$attrs, {
        class: "dd-map",
        type: type$1
      }), null, 16, _hoisted_1$b)) : createCommentVNode("", true);
    };
  }
};
const index$q = withInstall(_sfc_main$p);
const __vite_glob_0_13 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$q
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$o = {
  __name: "MovableArea",
  props: {
    /**
     * 当里面的movable-view设置为支持双指缩放时，设置此值可将缩放手势生效区域修改为整个movable-area
     */
    scaleArea: {
      type: Boolean,
      default: false,
      require: false
    }
  },
  setup(__props) {
    useInfo();
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-movable-area" }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$p = withInstall(_sfc_main$o);
const __vite_glob_0_14 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$p
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$n = {
  __name: "MovableView",
  props: {
    /**
     * movable-view的移动方向，属性值有all、vertical、horizontal、none
     */
    direction: {
      type: String,
      default: "none",
      required: false,
      validator: (value) => ["all", "vertical", "horizontal", "none"].includes(value)
    },
    /**
     * movable-view是否带有惯性
     */
    inertia: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 超过可移动区域后，movable-view是否还可以移动
     */
    outOfBounds: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 定义x轴方向的偏移，如果x的值不在可移动范围内，会自动移动到可移动范围；改变x的值会触发动画；单位支持px（默认）、暂不支持 rpx；
     */
    x: {
      type: [Number, String],
      default: 1,
      required: false
    },
    /**
     * 定义y轴方向的偏移，如果y的值不在可移动范围内，会自动移动到可移动范围；改变y的值会触发动画；单位支持px（默认）、暂不支持 rpx；
     */
    y: {
      type: [Number, String],
      default: 1,
      required: false
    },
    /**
     * 阻尼系数，用于控制x或y改变时的动画和过界回弹的动画
     */
    damping: {
      type: Number,
      default: 20,
      required: false
    },
    /**
     * 摩擦系数，用于控制惯性滑动的动画
     */
    friction: {
      type: Number,
      default: 2,
      required: false,
      validator: (value) => value > 0
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 是否支持双指缩放
     */
    scale: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 定义缩放倍数最小值
     */
    scaleMin: {
      type: Number,
      default: 0.1,
      required: false
    },
    /**
     * 定义缩放倍数最大值
     */
    scaleMax: {
      type: Number,
      default: 10,
      required: false
    },
    /**
     * 定义缩放倍数
     */
    scaleValue: {
      type: Number,
      default: 1,
      required: false,
      validator: (value) => value >= 0.1 && value <= 10
    },
    /**
     * 是否使用动画
     */
    animation: {
      type: Boolean,
      default: true,
      required: false
    }
  },
  emits: ["update:x", "update:y"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit2 = __emit;
    const info = useInfo();
    const movableView = ref(null);
    const movableViewContent = ref(null);
    let startX = 0;
    let startY = 0;
    const currentX = ref(Number.isNaN(props.x) ? 1 : Number.parseFloat(props.x));
    const currentY = ref(Number.isNaN(props.y) ? 1 : Number.parseFloat(props.y));
    const duration = ref(props.animation ? "0.5s" : "0s");
    let isDragging = false;
    let isUpdatingFromDrag = false;
    let parentRect = { width: 0, height: 0 };
    let childRect = { width: 0, height: 0 };
    let lastPositionX = 0;
    let lastPositionY = 0;
    let rafId = null;
    let resizeObserver = null;
    onMounted(() => {
      resizeObserver = new ResizeObserver(() => {
        requestAnimationFrame(() => {
          updateRects();
        });
      });
      if (movableView.value && movableView.value.parentElement) {
        resizeObserver.observe(movableView.value.parentElement);
        resizeObserver.observe(movableViewContent.value);
      }
      nextTick(() => {
        updateRects();
        duration.value = "0s";
        const { x: constrainedX, y: constrainedY } = constrainPosition(currentX.value, currentY.value);
        currentX.value = constrainedX;
        currentY.value = constrainedY;
      });
    });
    onUnmounted(() => {
      if (resizeObserver) {
        resizeObserver.disconnect();
        resizeObserver = null;
      }
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
    });
    function updateRects() {
      parentRect = movableView.value.parentElement.getBoundingClientRect();
      childRect = movableViewContent.value.getBoundingClientRect();
      if (parentRect.width >= childRect.width) {
        lastPositionX = parentRect.x;
      } else {
        lastPositionX = childRect.x;
      }
      if (parentRect.height >= childRect.height) {
        lastPositionY = parentRect.y;
      } else {
        lastPositionY = childRect.y;
      }
    }
    function constrainPosition(x, y) {
      if (!parentRect || !childRect)
        return { x, y };
      let constrainedX = x;
      let constrainedY = y;
      if (parentRect.width >= childRect.width) {
        constrainedX = Math.min(Math.max(x, 0), parentRect.width - childRect.width);
      } else {
        constrainedX = Math.min(Math.max(x, parentRect.width - childRect.width), 0);
      }
      if (parentRect.height >= childRect.height) {
        constrainedY = Math.min(Math.max(y, 0), parentRect.height - childRect.height);
      } else {
        constrainedY = Math.min(Math.max(y, parentRect.height - childRect.height), 0);
      }
      return { x: constrainedX, y: constrainedY };
    }
    function startDrag(event) {
      if (props.disabled) {
        triggerEvent("touchstart", { event, info });
        return;
      }
      duration.value = "0s";
      isDragging = true;
      startX = (event.touches ? event.touches[0].clientX : event.clientX) - currentX.value;
      startY = (event.touches ? event.touches[0].clientY : event.clientY) - currentY.value;
      triggerEvent("touchstart", { event, info });
    }
    function drag(event) {
      if (props.disabled || !isDragging) {
        if (props.disabled) {
          triggerEvent("touchmove", { event, info });
        }
        return;
      }
      event.stopPropagation();
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(() => {
        const nX = event.touches ? event.touches[0].clientX : event.clientX;
        const nY = event.touches ? event.touches[0].clientY : event.clientY;
        const dx = nX - startX;
        const dy = nY - startY;
        const { x: constrainedX, y: constrainedY } = constrainPosition(dx, dy);
        const rect = movableViewContent.value.getBoundingClientRect();
        const x = rect.x - lastPositionX;
        const y = rect.y - lastPositionY;
        isUpdatingFromDrag = true;
        if (props.direction === "horizontal") {
          currentX.value = constrainedX;
          emit2("update:x", constrainedX);
        } else if (props.direction === "vertical") {
          currentY.value = constrainedY;
          emit2("update:y", constrainedY);
        } else if (props.direction === "all") {
          currentX.value = constrainedX;
          currentY.value = constrainedY;
          emit2("update:x", constrainedX);
          emit2("update:y", constrainedY);
        }
        triggerEvent("change", {
          event,
          info,
          detail: {
            x,
            y,
            source: "touch"
          }
        });
      });
    }
    function endDrag(event) {
      if (props.disabled) {
        triggerEvent("touchend", { event, info });
        return;
      }
      if (!isDragging) {
        return;
      }
      isDragging = false;
      isUpdatingFromDrag = false;
      duration.value = props.animation ? "0.5s" : "0s";
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
      triggerEvent("touchend", { event, info });
    }
    watch([() => props.x, () => props.y], ([nX, nY], [pX, pY]) => {
      if (isUpdatingFromDrag) {
        return;
      }
      if (nX === pX && nY === pY) {
        return;
      }
      const x = Number.isNaN(nX) ? 1 : Number.parseFloat(nX);
      const y = Number.isNaN(nY) ? 1 : Number.parseFloat(nY);
      const { x: constrainedX, y: constrainedY } = constrainPosition(x, y);
      duration.value = props.animation ? "0.5s" : "0s";
      currentX.value = constrainedX;
      currentY.value = constrainedY;
    }, { flush: "post" });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({
        ref_key: "movableView",
        ref: movableView
      }, _ctx.$attrs, {
        class: ["dd-movable-view", [`direction-${__props.direction}`]],
        "aria-dropeffect": "move",
        "aria-label": "可移动",
        onTouchstart: startDrag,
        onTouchmove: drag,
        onTouchend: endDrag,
        onTouchcancel: endDrag,
        onMousedown: startDrag,
        onMousemove: drag,
        onMouseup: endDrag,
        onMouseleave: endDrag
      }), [
        createBaseVNode("div", {
          ref_key: "movableViewContent",
          ref: movableViewContent,
          class: "dd-movable-view-content",
          style: normalizeStyle({
            "--duration": unref(duration),
            "transform": `translate3d(${unref(currentX)}px, ${unref(currentY)}px, 0) scale(${__props.scaleValue})`
          })
        }, [
          renderSlot(_ctx.$slots, "default")
        ], 4)
      ], 16);
    };
  }
};
const index$o = withInstall(_sfc_main$n);
const __vite_glob_0_15 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$o
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$m = {
  __name: "NavigationBar",
  props: {
    /**
     * 导航条标题
     */
    title: {
      type: String,
      required: false
    },
    /**
     * 是否在导航条显示 loading 加载提示
     */
    loading: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 导航条前景颜色值，包括按钮、标题、状态栏的颜色，仅支持 #ffffff 和 #000000
     */
    frontColor: {
      type: String,
      required: false,
      validator: (value) => ["#ffffff", "#000000"].includes(value)
    },
    /**
     * 导航条背景颜色值，有效值为十六进制颜色
     */
    backgroundColor: {
      type: String,
      required: false,
      validator: (value) => /^#([0-9A-F]{6}|[0-9A-F]{3})$/i.test(value)
    },
    /**
     * 改变导航栏颜色时的动画时长，默认为 0 （即没有动画效果）
     */
    colorAnimationDuration: {
      type: Number,
      default: 0,
      required: false
    },
    /**
     * 改变导航栏颜色时的动画方式，支持 linear 、 easeIn 、 easeOut 和 easeInOut
     */
    colorAnimationTimingFunc: {
      type: String,
      default: "linear",
      required: false,
      validator: (value) => ["linear", "easeIn", "easeOut", "easeInOut"].includes(value)
    }
  },
  setup(__props) {
    const props = __props;
    const info = useInfo();
    onMounted(() => {
      invokeAPI("setNavigationBarTitle", {
        bridgeId: info.bridgeId,
        params: { title: props.title }
      });
      invokeAPI("setNavigationBarColor", {
        bridgeId: info.bridgeId,
        params: {
          frontColor: props.frontColor,
          backgroundColor: props.backgroundColor,
          animation: {
            duration: props.colorAnimationDuration,
            timingFunc: props.colorAnimationTimingFunc
          }
        }
      });
    });
    return (_ctx, _cache) => {
      return renderSlot(_ctx.$slots, "default");
    };
  }
};
const index$n = withInstall(_sfc_main$m);
const __vite_glob_0_16 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$n
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$l = {
  __name: "Navigator",
  props: {
    /**
     * 在哪个目标上发生跳转，默认当前小程序
     * 合法值 self|miniProgram
     */
    target: {
      type: String,
      default: "self"
    },
    url: {
      type: String
    },
    redirect: {
      type: Boolean,
      default: false
    },
    /**
     * 跳转方式
     * 合法值: navigate, redirect, switchTab, reLaunch, navigateBack, exit
     */
    openType: {
      type: String,
      default: "navigate"
    },
    /**
     * 当 open-type 为 'navigateBack' 时有效，表示回退的层数
     */
    delta: {
      type: Number,
      default: 1
    },
    /**
     * 当target="miniProgram"且open-type="navigate"时有效，要打开的小程序 appId
     */
    appId: {
      type: String
    },
    // 当target="miniProgram"且open-type="navigate"时有效，打开的页面路径，如果为空则打开首页
    path: {
      type: String
    },
    // 当target="miniProgram"且open-type="navigate/navigateBack"时有效，需要传递给目标小程序的数据，目标小程序可在 App.onLaunch()，App.onShow() 中获取到这份数据
    extraData: {
      type: Object
    },
    /**
     * 当target="miniProgram"且open-type="navigate"时有效，要打开的小程序版本
     * 合法值 develop|trial|release
     */
    version: {
      type: String,
      default: "release"
    },
    /**
     * 当target="miniProgram"时有效，当传递该参数后，可以不传 app-id 和 path。链接可以通过【小程序菜单】->【复制链接】获取。
     */
    shortLink: {
      type: String
    },
    /**
     * 指定点击时的样式类，当hover-class="none"时，没有点击态效果
     */
    hoverClass: {
      type: String,
      default: "navigator-hover"
    },
    /**
     * 指定是否阻止本节点的祖先节点出现点击态
     */
    hoverStopPropagation: {
      type: Boolean,
      default: false
    },
    /**
     * 按住后多久出现点击态，单位毫秒
     */
    hoverStartTime: {
      type: Number,
      default: 50
    },
    /**
     * 手指松开后点击态保留时间，单位毫秒
     */
    hoverStayTime: {
      type: Number,
      default: 600
    }
  },
  setup(__props) {
    const props = __props;
    const isActive = ref(false);
    async function handleDown(event) {
      if (props.hoverStopPropagation) {
        event.stopPropagation();
      }
      await sleep(props.hoverStartTime);
      isActive.value = true;
    }
    async function handleUp() {
      await sleep(props.hoverStayTime);
      isActive.value = false;
    }
    const info = useInfo();
    function clicked() {
      const { openType, target, url, redirect } = props;
      if (url == null ? void 0 : url.includes("javascript:")) {
        return;
      }
      if (redirect) {
        invokeAPI("redirectTo", {
          bridgeId: info.bridgeId,
          params: { url: parsePath(info.path, url) }
        });
        return;
      }
      switch (openType) {
        case "navigate": {
          invokeAPI("navigateTo", {
            bridgeId: info.bridgeId,
            params: { url: parsePath(info.path, url) }
          });
          break;
        }
        case "redirect": {
          invokeAPI("redirectTo", {
            bridgeId: info.bridgeId,
            params: { url: parsePath(info.path, url) }
          });
          break;
        }
        case "switchTab": {
          invokeAPI("switchTab", {
            bridgeId: info.bridgeId,
            params: { url: parsePath(info.path, url) }
          });
          break;
        }
        case "reLaunch": {
          invokeAPI("reLaunch", {
            bridgeId: info.bridgeId,
            params: { url: parsePath(info.path, url) }
          });
          break;
        }
        case "navigateBack": {
          invokeAPI("navigateBack", {
            bridgeId: info.bridgeId
          });
          break;
        }
        case "exit": {
          if (target === "miniProgram") {
            invokeAPI("exit", {
              bridgeId: info.bridgeId
            });
          }
          break;
        }
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", mergeProps(_ctx.$attrs, {
        class: ["dd-navigator", [unref(isActive) ? __props.hoverClass : void 0]],
        onClick: clicked,
        onMousedown: handleDown,
        onMouseup: handleUp
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$m = withInstall(_sfc_main$l);
const __vite_glob_0_17 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$m
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$k = {
  __name: "OpenData",
  props: {},
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", normalizeProps(guardReactiveProps(_ctx.$attrs)), null, 16);
    };
  }
};
const index$l = withInstall(_sfc_main$k);
const __vite_glob_0_18 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$l
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$j = {
  __name: "PageMeta",
  props: {
    /**
     * 下拉背景字体、loading 图的样式，仅支持 dark 和 light
     */
    backgroundTextStyle: {
      type: String,
      required: false,
      validator: (value) => {
        return ["dark", "light"].includes(value);
      }
    },
    /**
     * 窗口的背景色，必须为十六进制颜色值
     */
    backgroundColor: {
      type: String,
      required: false
    },
    /**
     * 窗口的背景色，必须为十六进制颜色值
     */
    backgroundColorTop: {
      type: String,
      required: false
    },
    /**
     * 底部窗口的背景色，必须为十六进制颜色值，仅 iOS 支持
     */
    backgroundColorBottom: {
      type: String,
      required: false
    },
    /**
     * 页面内容的背景色，用于页面中的空白部分和页面大小变化 resize 动画期间的临时空闲区域
     */
    rootBackgroundColor: {
      type: String,
      default: "",
      required: false
    },
    /**
     * 页面根节点样式，页面根节点是所有页面节点的祖先节点，相当于 HTML 中的 body 节点
     */
    pageStyle: {
      type: String,
      default: "",
      required: false
    },
    /**
     * 页面 page 的字体大小，可以设置为 system ，表示使用当前用户设置的微信字体大小
     */
    pageFontSize: {
      type: String,
      default: "",
      required: false
    },
    /**
     * 页面的根字体大小，页面中的所有 rem 单位，将使用这个字体大小作为参考值，即 1rem 等于这个字体大小；自小程序版本 2.11.0 起，也可以设置为 system
     */
    rootFontSize: {
      type: String,
      default: "",
      required: false
    },
    /**
     * 页面的方向，可为 auto portrait 或 landscape
     */
    pageOrientation: {
      type: String,
      default: "",
      required: false
    }
  },
  setup(__props) {
    const props = __props;
    const info = useInfo();
    onMounted(() => {
      invokeAPI("setBackgroundTextStyle", {
        bridgeId: info.bridgeId,
        params: { textStyle: props.backgroundTextStyle }
      });
      invokeAPI("setBackgroundColor", {
        bridgeId: info.bridgeId,
        params: {
          backgroundColor: props.backgroundColor,
          backgroundColorTop: props.backgroundColorTop,
          backgroundColorBottom: props.backgroundColorBottom
        }
      });
    });
    return (_ctx, _cache) => {
      return renderSlot(_ctx.$slots, "default");
    };
  }
};
const index$k = withInstall(_sfc_main$j);
const __vite_glob_0_19 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$k
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$a = {
  "aria-label": "上下滚动进行选择",
  "aria-dropeffect": "move"
};
const _sfc_main$i = {
  __name: "PickerViewColumn",
  setup(__props) {
    const indicatorRef = ref(null);
    const maskRef = ref(null);
    const contentRef = ref(null);
    const currentY = ref(0);
    const duration = ref("0.2s");
    const pickerItemStyle = inject("pickerItemStyle", {});
    const pickerEvent = inject("pickerEvent", void 0);
    const getPickerHeight = inject("getPickerHeight", () => 0);
    const getItemIndex = inject("getItemIndex", () => 0);
    const itemIndex = getItemIndex();
    const setPickerValue = inject("setPickerValue", void 0);
    const itemValue = inject("itemValue", Array(itemIndex).fill(0));
    const indicatorClass = ref(pickerItemStyle.indicatorClass);
    const maskClass = ref(pickerItemStyle.maskClass);
    const nodeLineHeight = ref("34px");
    let isDragging = false;
    let startY = 0;
    let moveY = 0;
    const slots = useSlots();
    let itemsSize = slots.default ? Math.max(slots.default()[0].children.length - 1, 0) : 0;
    const currentIndex = ref(Math.min(itemValue[itemIndex], itemsSize));
    let itemHeight = 0;
    setPickerValue == null ? void 0 : setPickerValue(itemIndex, currentIndex.value);
    function startDrag(event) {
      pickerEvent == null ? void 0 : pickerEvent("pickstart", event);
      isDragging = true;
      startY = event.touches ? event.touches[0].clientY : event.clientY;
      moveY = 0;
      itemHeight = indicatorRef.value.offsetHeight;
    }
    function drag(event) {
      if (!isDragging)
        return;
      moveY = (event.touches ? event.touches[0].clientY : event.clientY) - startY - currentIndex.value * itemHeight;
      currentY.value = moveY;
    }
    function endDrag(event) {
      if (!isDragging)
        return;
      isDragging = false;
      duration.value = "0.2s";
      if (moveY < 0) {
        itemsSize = slots.default ? Math.max(slots.default()[0].children.length - 1, 0) : 0;
        currentIndex.value = Math.min(itemsSize, Math.abs(Math.round(moveY / itemHeight)));
        currentY.value = -currentIndex.value * itemHeight;
      } else {
        currentIndex.value = 0;
        currentY.value = 0;
      }
      setPickerValue == null ? void 0 : setPickerValue(itemIndex, currentIndex.value);
      pickerEvent == null ? void 0 : pickerEvent("change", event);
      pickerEvent == null ? void 0 : pickerEvent("pickend", event);
    }
    onMounted(async () => {
      await nextTick();
      const pickerHeight = getPickerHeight();
      indicatorRef.value.style = pickerItemStyle.indicatorStyle;
      if (slots.default && slots.default()[0].children.length > 0) {
        const firstChild = contentRef.value.querySelector(":first-child");
        if (firstChild) {
          const computedStyle = window.getComputedStyle(firstChild);
          nodeLineHeight.value = computedStyle.lineHeight || "34px";
          indicatorRef.value.style.height = nodeLineHeight.value;
        }
      }
      itemHeight = indicatorRef.value.offsetHeight;
      const pTop = (pickerHeight - itemHeight) / 2;
      indicatorRef.value.style.top = `${pTop}px`;
      maskRef.value.style = pickerItemStyle.maskStyle;
      maskRef.value.style.backgroundSize = `100% ${pTop}px`;
      const slotNodes = contentRef.value.children;
      Array.from(slotNodes).forEach((node) => {
        node.style.height = `${itemHeight}px`;
      });
      contentRef.value.style.paddingTop = `${pTop}px`;
      duration.value = "0s";
      currentY.value = -currentIndex.value * itemHeight;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-picker-view-column" }), [
        createBaseVNode("div", _hoisted_1$a, [
          createBaseVNode("div", {
            ref_key: "maskRef",
            ref: maskRef,
            class: normalizeClass(["dd-picker__mask", unref(maskClass)])
          }, null, 2),
          createBaseVNode("div", {
            ref_key: "indicatorRef",
            ref: indicatorRef,
            class: normalizeClass(["dd-picker__indicator", unref(indicatorClass)])
          }, null, 2),
          createBaseVNode("div", {
            ref_key: "contentRef",
            ref: contentRef,
            class: "dd-picker__content",
            style: normalizeStyle({
              "--duration": unref(duration),
              "transform": `translateY(${unref(currentY)}px)`
            }),
            onTouchstart: startDrag,
            onTouchmove: withModifiers(drag, ["prevent"]),
            onTouchend: withModifiers(endDrag, ["prevent"]),
            onTouchcancel: endDrag,
            onMousedown: startDrag,
            onMousemove: withModifiers(drag, ["prevent"]),
            onMouseup: endDrag,
            onMouseleave: endDrag
          }, [
            renderSlot(_ctx.$slots, "default")
          ], 36)
        ])
      ], 16);
    };
  }
};
const index$j = withInstall(_sfc_main$i);
const __vite_glob_0_20 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$j
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$h = {
  __name: "PickerView",
  props: {
    /**
     * 数组中的数字依次表示 picker-view 内的 picker-view-column 选择的第几项（下标从 0 开始），数字大于 picker-view-column 可选项长度时，选择最后一项。
     */
    value: {
      type: Array
    },
    /**
     * 设置蒙层的类名
     */
    maskClass: {
      type: String
    },
    /**
     * 设置选择器中间选中框的样式
     */
    indicatorStyle: {
      type: String
    },
    /**
     * 设置选择器中间选中框的类名
     */
    indicatorClass: {
      type: String
    },
    /**
     * 设置蒙层的样式
     */
    maskStyle: {
      type: String
    },
    /**
     * 是否在手指松开时立即触发 change 事件。若不开启则会在滚动动画结束后触发 change 事件。
     */
    immediateChange: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    let index2 = -1;
    const pickerView = ref(null);
    const itemValue = [];
    provide("getPickerHeight", () => {
      return pickerView.value.offsetHeight;
    });
    provide("pickerItemStyle", {
      indicatorStyle: props.indicatorStyle,
      indicatorClass: props.indicatorClass,
      maskStyle: props.maskStyle,
      maskClass: props.maskClass
    });
    provide("itemValue", props.value);
    provide("getItemIndex", () => {
      return ++index2;
    });
    provide("setPickerValue", (index3, value) => {
      itemValue[index3] = value;
    });
    const info = useInfo();
    provide("pickerEvent", (type2, event) => {
      const detail = type2 === "change" ? { value: itemValue } : {};
      triggerEvent(type2, {
        event,
        info,
        detail
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({
        ref_key: "pickerView",
        ref: pickerView
      }, _ctx.$attrs, { class: "dd-picker-view" }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$i = withInstall(_sfc_main$h);
const __vite_glob_0_21 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$i
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$g = {
  __name: "Picker",
  props: {
    /**
     * 选择器的标题，仅安卓可用
     */
    headerText: {
      type: String
    },
    /**
     * 选择器类型
     */
    mode: {
      type: String,
      default: "selector",
      validator: (value) => {
        return ["selector", "multiSelector", "time", "date", "region"].includes(value);
      }
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    // 普通选择器：mode = selector, 多列选择器：mode = multiSelector
    /**
     * mode 为 selector 或 multiSelector 时，range 有效
     */
    range: {
      type: [Array, Object],
      default: () => []
    },
    /**
     * 当 range 是一个 Object Array 时，通过 range-key 来指定 Object 中 key 的值作为选择器显示内容
     */
    rangeKey: {
      type: String
    },
    // 时间选择器：mode = time, 日期选择器：mode = date
    /**
     * 表示有效时间范围的开始，字符串格式为"hh:mm"
     * 表示有效日期范围的开始，字符串格式为"YYYY-MM-DD"
     */
    start: {
      type: String
    },
    /**
     * 表示有效时间范围的结束，字符串格式为"hh:mm"
     * 表示有效日期范围的结束，字符串格式为"YYYY-MM-DD"
     */
    end: {
      type: String
    },
    /**
     * 有效值 year,month,day，表示选择器的粒度
     */
    fields: {
      type: String,
      default: "day",
      validator: (value) => {
        return ["year", "month", "day"].includes(value);
      }
    },
    // 省市区选择器：mode = region
    customItem: {
      type: String
    },
    /**
     * 选择器层级
     */
    level: {
      type: String,
      default: "region",
      validator: (value) => {
        return ["province", "city", "region", "sub-district"].includes(value);
      }
    },
    /**
     * 表示选择了 range 中的第几个（下标从 0 开始）
     */
    value: {
      type: [Number, String],
      default: (props) => {
        switch (props.mode) {
          case "selector":
            return 0;
          case "multiSelector":
            return [];
          case "time":
            return;
          case "date": {
            const now = /* @__PURE__ */ new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, "0");
            const day = String(now.getDate()).padStart(2, "0");
            return `${year}-${month}-${day}`;
          }
        }
      }
    }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-picker" }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$h = withInstall(_sfc_main$g);
const __vite_glob_0_22 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$h
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$9 = ["aria-valuenow"];
const _hoisted_2$4 = ["hidden"];
const _sfc_main$f = {
  __name: "Progress",
  props: {
    /**
     * 百分比0~100
     */
    percent: {
      type: [Number, String],
      required: false
    },
    /**
     * 在进度条右侧显示百分比
     */
    showInfo: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 圆角大小
     */
    borderRadius: {
      type: [Number, String],
      default: 0,
      required: false
    },
    /**
     * 右侧百分比字体大小
     */
    fontSize: {
      type: [Number, String],
      default: 16,
      required: false
    },
    /**
     * 进度条线的宽度
     */
    strokeWidth: {
      type: [Number, String],
      default: 6,
      required: false
    },
    /**
     * 进度条颜色
     * @deprecated 请使用activeColor属性
     */
    color: {
      type: String,
      default: "#09BB07",
      required: false
    },
    /**
     * 已选择的进度条的颜色
     */
    activeColor: {
      type: String,
      default: "#09BB07",
      required: false
    },
    /**
     * 未选择的进度条的颜色
     */
    backgroundColor: {
      type: String,
      default: "#EBEBEB",
      required: false
    },
    /**
     * 进度条从左往右的动画
     */
    active: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * backwards: 动画从头播；forwards：动画从上次结束点接着播
     */
    activeMode: {
      type: String,
      default: "backwards",
      required: false
    },
    /**
     * 进度增加1%所需毫秒数
     */
    duration: {
      type: Number,
      default: 30,
      required: false
    }
  },
  setup(__props) {
    const props = __props;
    const percentParsed = computed(() => {
      return props.active ? 0 : `${props.percent}%`;
    });
    const durationParsed = computed(() => {
      return `${Number(props.duration) * Number(props.percent)}ms`;
    });
    const progressRef = ref(null);
    onMounted(async () => {
      if (props.active) {
        if (isDesktop) {
          await sleep(540);
        }
        progressRef.value.style.setProperty("--percent", `${props.percent}%`);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-progress" }), [
        createBaseVNode("div", {
          class: "dd-progress-bar",
          "aria-label": "",
          "aria-valuenow": `${__props.percent}%`,
          style: normalizeStyle({
            borderRadius: `${__props.borderRadius}px`,
            backgroundColor: __props.backgroundColor,
            height: `${__props.strokeWidth}px`
          })
        }, [
          createBaseVNode("div", {
            ref_key: "progressRef",
            ref: progressRef,
            class: "dd-progress-inner-bar",
            style: normalizeStyle({ "--percent": unref(percentParsed), "--duration": unref(durationParsed), "backgroundColor": __props.activeColor || __props.color })
          }, null, 4)
        ], 12, _hoisted_1$9),
        createBaseVNode("p", {
          class: "dd-progress-info",
          style: normalizeStyle({ fontSize: __props.fontSize }),
          hidden: !__props.showInfo
        }, toDisplayString(__props.percent) + "% ", 13, _hoisted_2$4)
      ], 16);
    };
  }
};
const index$g = withInstall(_sfc_main$f);
const __vite_glob_0_23 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$g
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$8 = ["id"];
const _sfc_main$e = {
  __name: "RadioGroup",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * name，为表单使用
     */
    name: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    const collectFormValue = inject("collectFormValue", void 0);
    const selected = ref(null);
    function selectValue(value) {
      selected.value = value;
      collectFormValue == null ? void 0 : collectFormValue(props.name, selected.value);
    }
    const info = useInfo();
    function handleValueChange(event) {
      collectFormValue == null ? void 0 : collectFormValue(props.name, selected.value);
      triggerEvent("change", {
        event,
        info,
        detail: {
          value: selected.value
        }
      });
    }
    provide("selected", selected);
    provide("selectValue", selectValue);
    provide("handleValueChange", handleValueChange);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, { class: "dd-radio-group" }), [
        renderSlot(_ctx.$slots, "default")
      ], 16, _hoisted_1$8);
    };
  }
};
const index$f = withInstall(_sfc_main$e);
const __vite_glob_0_24 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$f
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$7 = { class: "dd-radio-wrapper" };
const _sfc_main$d = {
  __name: "Radio",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * radio 标识。当该radio 选中时，radio-group 的 change 事件会携带radio的value
     */
    value: {
      type: String,
      default: ""
    },
    /**
     * 是否选中
     */
    checked: {
      type: Boolean,
      default: false
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * switch 的颜色，同 css 的 color
     */
    color: {
      type: String,
      default: "#09BB07"
    }
  },
  setup(__props) {
    const props = __props;
    const selectValue = inject("selectValue", void 0);
    const selected = inject("selected", void 0);
    if (props.checked) {
      selectValue == null ? void 0 : selectValue(props.value);
    }
    const isOn2 = computed(() => {
      if (selected) {
        return selected.value === props.value;
      } else {
        return Boolean(props.checked);
      }
    });
    const computedStyle = computed(() => {
      if (props.color && isOn2.value) {
        return {
          backgroundColor: props.color,
          borderColor: props.color
        };
      } else {
        return void 0;
      }
    });
    const handleValueChange = inject("handleValueChange", void 0);
    const info = useInfo();
    function handleClicked(event) {
      if (!props.disabled) {
        if (typeof selectValue === "function") {
          selectValue(props.value);
        }
        handleValueChange == null ? void 0 : handleValueChange(event);
        triggerEvent("tap", {
          event,
          info,
          detail: {}
        });
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-radio" }), [
        createBaseVNode("div", _hoisted_1$7, [
          createBaseVNode("div", {
            class: normalizeClass(["dd-radio-input", { "dd-radio-input-checked": unref(isOn2), "dd-radio-input-disabled": __props.disabled }]),
            style: normalizeStyle(unref(computedStyle)),
            onClick: handleClicked
          }, null, 6),
          renderSlot(_ctx.$slots, "default")
        ])
      ], 16);
    };
  }
};
const index$e = withInstall(_sfc_main$d);
const __vite_glob_0_25 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$e
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$6 = ["innerHTML"];
const _sfc_main$c = {
  __name: "RichText",
  props: {
    /**
     * 节点列表/HTML String
     */
    nodes: {
      type: [Array, String],
      default: []
    },
    /**
     * 显示连续空格
     * ensp	中文字符空格一半大小
     * emsp	中文字符空格大小
     * nbsp	根据字体设置的空格大小
     */
    space: {
      type: String,
      validator: (value) => ["ensp", "emsp", "nbsp"].includes(value)
    },
    /**
     * 文本是否可选，该属性会使节点显示为 block
     */
    userSelect: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const sanitizedHtml = ref("");
    function renderNode(node) {
      const spaceType = props.space;
      let html = `<${node.name}`;
      if (node.attrs) {
        for (const key in node.attrs) {
          if (Object.prototype.hasOwnProperty.call(node.attrs, key)) {
            let value = node.attrs[key];
            if (value === " ") {
              value = `&${spaceType};`;
            }
            html += ` ${key}="${value}"`;
          }
        }
      }
      if (node.children && node.children.length > 0) {
        html += ">";
        node.children.forEach((child) => {
          if (child.type === "text") {
            const textContent = child.text.replace(/ /g, `&${spaceType};`);
            html += textContent;
          } else {
            html += renderNode(child);
          }
        });
        html += `</${node.name}>`;
      } else if (node.type === "text") {
        const textContent = node.text.replace(/ /g, `&${spaceType};`);
        html += `>${textContent}</${node.name}>`;
      } else {
        html += "/>";
      }
      return html;
    }
    onMounted(() => {
      let htmlContent = "";
      const nodes = toRaw(props.nodes);
      if (typeof nodes === "string") {
        htmlContent = nodes;
      } else if (typeof nodes === "object" && Array.isArray(nodes)) {
        nodes.forEach((node) => {
          htmlContent += renderNode(node);
        });
      }
      sanitizedHtml.value = htmlContent.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
        class: { "dd-rich-text": __props.userSelect },
        innerHTML: unref(sanitizedHtml)
      }), null, 16, _hoisted_1$6);
    };
  }
};
const index$d = withInstall(_sfc_main$c);
const __vite_glob_0_26 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$d
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$b = {
  __name: "RootPortal",
  props: {},
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", normalizeProps(guardReactiveProps(_ctx.$attrs)), null, 16);
    };
  }
};
const index$c = withInstall(_sfc_main$b);
const __vite_glob_0_27 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$c
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$a = {
  __name: "ScrollView",
  props: {
    /**
     * 允许横向滚动
     */
    scrollX: {
      type: Boolean,
      default: false
    },
    /**
     * 允许纵向滚动
     */
    scrollY: {
      type: Boolean,
      default: false
    },
    /**
     * 距顶部/左边多远时，触发 scrolltoupper 事件
     */
    upperThreshold: {
      type: [Number, String],
      default: 50
    },
    /**
     * 距底部/右边多远时，触发 scrolltolower 事件
     */
    lowerThreshold: {
      type: [Number, String],
      default: 50
    },
    /**
     * 设置竖向滚动条位置
     */
    scrollTop: {
      type: [Number, String]
    },
    /**
     * 设置横向滚动条位置
     */
    scrollLeft: {
      type: [Number, String]
    },
    /**
     * 值应为某子元素id（id不能以数字开头）。设置哪个方向可滚动，则在哪个方向滚动到该元素
     */
    scrollIntoView: {
      type: String
    },
    /**
     * 在设置滚动条位置时使用动画过渡
     */
    scrollWithAnimation: {
      type: Boolean,
      default: false
    },
    /**
     * iOS点击顶部状态栏、安卓双击标题栏时，滚动条返回顶部，只支持竖向。自 2.27.3 版本开始，若非显式设置为 false，则在显示尺寸大于屏幕 90% 时自动开启。
     */
    enableBackToTop: {
      type: Boolean,
      default: false
    },
    /**
     * TODO: 开启 passive 特性，能优化一定的滚动性能
     */
    enablePassive: {
      type: Boolean,
      default: false
    },
    /**
     * 开启自定义下拉刷新
     */
    refresherEnabled: {
      type: Boolean,
      default: false
    },
    /**
     * 设置自定义下拉刷新阈值
     */
    refresherThreshold: {
      type: Number,
      default: 45
    },
    /**
     * 设置自定义下拉刷新默认样式，支持设置 black | white | none， none 表示不使用默认样式
     */
    refresherDefaultStyle: {
      type: String,
      default: "black",
      validator: (value) => {
        return ["black", "white", "none"].includes(value);
      }
    },
    /**
     * 设置自定义下拉刷新区域背景颜色，默认为透明
     */
    refresherBackground: {
      type: String
    },
    /**
     * 设置当前下拉刷新状态，true 表示下拉刷新已经被触发，false 表示下拉刷新未被触发
     */
    refresherTriggered: {
      type: Boolean,
      default: false
    },
    /**
     * iOS 下 scroll-view 边界弹性控制 (同时开启 enhanced 属性后生效)
     */
    bounces: {
      type: Boolean,
      default: true
    },
    /**
     * 滚动条显隐控制 (同时开启 enhanced 属性后生效)
     */
    showScrollbar: {
      type: Boolean,
      default: true
    },
    /**
     * 滑动减速速率控制, 仅在 iOS 下生效 (同时开启 enhanced 属性后生效)
     */
    fastDeceleration: {
      type: Boolean,
      default: false
    },
    /**
     * 启用 flexbox 布局。开启后，当前节点声明了 display: flex 就会成为 flex container，并作用于其孩子节点
     */
    enableFlex: {
      type: Boolean,
      default: false
    },
    /**
     * 开启 scroll anchoring 特性，即控制滚动位置不随内容变化而抖动，仅在 iOS 下生效，安卓下可参考 CSS overflow-anchor 属性
     */
    scrollAnchoring: {
      type: Boolean,
      default: false
    },
    /**
     * 启用 scroll-view 增强特性，启用后可通过 ScrollViewContext 操作 scroll-view
     */
    enhanced: {
      type: Boolean,
      default: false
    },
    /**
     * 分页滑动效果 (同时开启 enhanced 属性后生效)
     */
    pagingEnabled: {
      type: Boolean,
      default: false
    },
    /**
     * 使 scroll-view 下的 position sticky 特性生效，否则滚动一屏后 sticky 元素会被隐藏
     */
    usingSticky: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const info = useInfo();
    const scrollView = ref(null);
    const hideScrollBar = computed(() => {
      if (props.enhanced) {
        return !props.showScrollbar;
      }
      return true;
    });
    let lastScrollLeft = 0;
    let lastScrollTop = 0;
    let lastScrollToUpperTime = 0;
    function handleScroll(event) {
      const el = scrollView.value;
      const { scrollTop, scrollLeft, scrollHeight, scrollWidth, clientHeight, clientWidth } = el;
      const deltaX = scrollLeft - lastScrollLeft;
      const deltaY = scrollTop - lastScrollTop;
      lastScrollLeft = scrollLeft;
      lastScrollTop = scrollTop;
      triggerEvent("scroll", {
        event,
        info,
        detail: {
          scrollLeft,
          // 水平滚动的距离
          scrollTop,
          // // 垂直滚动的距离
          scrollHeight,
          // 内容总高度
          scrollWidth,
          // 内容总宽度
          deltaX,
          deltaY
        }
      });
      if (props.scrollY) {
        if (scrollTop <= props.upperThreshold && deltaY < 0 && event.timeStamp - lastScrollToUpperTime > 200) {
          lastScrollToUpperTime = event.timeStamp;
          triggerEvent("scrolltoupper", {
            event,
            info,
            detail: {
              direction: "top"
            }
          });
        }
        if (scrollTop + clientHeight >= scrollHeight - props.lowerThreshold && deltaY > 0 && event.timeStamp - lastScrollToUpperTime > 200) {
          lastScrollToUpperTime = event.timeStamp;
          triggerEvent("scrolltolower", {
            event,
            info,
            detail: {
              direction: "bottom"
            }
          });
        }
      }
      if (props.scrollX) {
        if (scrollLeft <= props.upperThreshold && deltaX < 0 && event.timeStamp - lastScrollToUpperTime > 200) {
          lastScrollToUpperTime = event.timeStamp;
          triggerEvent("scrolltoupper", {
            event,
            info,
            detail: {
              direction: "left"
            }
          });
        }
        if (scrollLeft + clientWidth >= scrollWidth - props.lowerThreshold && deltaX > 0 && event.timeStamp - lastScrollToUpperTime > 200) {
          lastScrollToUpperTime = event.timeStamp;
          triggerEvent("scrolltolower", {
            event,
            info,
            detail: {
              direction: "right"
            }
          });
        }
      }
    }
    function handleTouchMove(event) {
      if (props.scrollX || props.scrollY) {
        triggerEvent("touchmove", {
          event,
          info
        });
      } else {
        event.preventDefault();
      }
    }
    watch(
      () => [props.scrollTop, props.scrollLeft],
      ([newScrollTop, newScrollLeft]) => {
        if (scrollView.value) {
          scrollView.value.scrollTo({
            top: newScrollTop,
            left: newScrollLeft,
            behavior: "instant"
          });
        }
      },
      { flush: "post" }
    );
    onMounted(() => {
      if (scrollView.value) {
        scrollView.value.scrollTop = props.scrollTop;
        scrollView.value.scrollLeft = props.scrollLeft;
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({
        ref_key: "scrollView",
        ref: scrollView
      }, _ctx.$attrs, {
        class: ["dd-scroll-view", [{ "scroll-x": Boolean(props.scrollX), "scroll-y": Boolean(props.scrollY), "hide-scrollbar": unref(hideScrollBar) }]],
        onScroll: handleScroll,
        onTouchmove: handleTouchMove
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$b = withInstall(_sfc_main$a);
const __vite_glob_0_28 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$b
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$5 = ["id"];
const _hoisted_2$3 = { class: "dd-slider-wrapper" };
const _hoisted_3 = ["hidden"];
const _hoisted_4 = {
  "parse-text-content": "",
  style: { "width": "3ch" }
};
const _sfc_main$9 = {
  __name: "Slider",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * name，为表单使用
     */
    name: {
      type: String
    },
    /**
     * 最小值
     */
    min: {
      type: Number,
      default: 0,
      required: false
    },
    /**
     * 最大值
     */
    max: {
      type: Number,
      default: 100,
      required: false
    },
    /**
     * 步长，取值必须大于 0，并且可被(max - min)整除
     */
    step: {
      type: Number,
      default: 1,
      required: false
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 当前取值
     */
    value: {
      type: Number,
      default: 0,
      required: false
    },
    /**
     * 背景条的颜色（请使用 backgroundColor）
     */
    color: {
      type: String,
      default: "#e9e9e9",
      required: false
    },
    /**
     * 已选择的颜色（请使用 activeColor）
     */
    selectedColor: {
      type: String,
      default: "#1aad19",
      required: false
    },
    /**
     * 进度条激活态颜色
     */
    activeColor: {
      type: String,
      default: "#1aad19",
      required: false
    },
    /**
     * 进度条非激活态颜色
     */
    backgroundColor: {
      type: String,
      default: "#e9e9e9",
      required: false
    },
    /**
     * 滑块的大小，取值范围为 12 - 28
     */
    blockSize: {
      type: Number,
      default: 28,
      required: false,
      validator: (value) => value >= 12 && value <= 28
    },
    /**
     * 滑块的颜色
     */
    blockColor: {
      type: String,
      default: "#ffffff",
      required: false
    },
    /**
     * 是否显示当前 value
     */
    showValue: {
      type: Boolean,
      default: false,
      required: false
    }
  },
  setup(__props) {
    const props = __props;
    const valColor = computed(() => {
      return props.activeColor || props.selectedColor;
    });
    const backColor = computed(() => {
      return {
        backgroundColor: props.backgroundColor || props.color
      };
    });
    function roundToStep(value) {
      const min = Number(props.min);
      const max = Number(props.max);
      const step = Number(props.step);
      const clamp = Math.min(Math.max(value, min), max);
      return Math.round(clamp / step) * step;
    }
    const sliderHandle = ref(null);
    const disValue = ref(roundToStep(Number(props.value)));
    const collectFormValue = inject("collectFormValue", void 0);
    collectFormValue == null ? void 0 : collectFormValue(props.name, disValue.value);
    const range = computed(() => Number(props.max) - Number(props.min));
    const percent = computed(() => {
      return (disValue.value - Number(props.min)) / range.value * 100;
    });
    let isDragging = false;
    function startDrag() {
      if (props.disabled) {
        return;
      }
      isDragging = true;
    }
    const info = useInfo();
    function drag(event) {
      if (!isDragging || Boolean(props.disabled)) {
        return;
      }
      updateValue(event);
    }
    function updateValue(event) {
      const clientX = event.touches ? event.touches[0].clientX : event.clientX;
      const delta = clientX - sliderHandle.value.offsetLeft;
      const position = delta / sliderHandle.value.offsetWidth * range.value + Number(props.min);
      const disV = roundToStep(position);
      disValue.value = disV;
      collectFormValue == null ? void 0 : collectFormValue(props.name, disV);
      triggerEvent("changing", {
        event,
        info,
        detail: {
          value: disV
        }
      });
    }
    function endDrag(event) {
      if (!isDragging || Boolean(props.disabled)) {
        return;
      }
      triggerEvent("change", {
        event,
        info,
        detail: {
          value: disValue.value
        }
      });
    }
    function handleClick(event) {
      if (isDragging) {
        isDragging = false;
        return;
      }
      if (props.disabled) {
        return;
      }
      updateValue(event);
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({ id: __props.id }, _ctx.$attrs, { class: "dd-slider" }), [
        createBaseVNode("div", _hoisted_2$3, [
          createBaseVNode("div", {
            ref_key: "sliderHandle",
            ref: sliderHandle,
            class: "dd-slider-tap-area",
            onClick: handleClick
          }, [
            createBaseVNode("div", {
              class: "dd-slider-handle-wrapper",
              style: normalizeStyle(unref(backColor))
            }, [
              createBaseVNode("div", {
                class: "dd-slider-handle",
                style: normalizeStyle({ left: `${unref(percent)}%` }),
                onTouchstart: startDrag,
                onTouchmove: withModifiers(drag, ["prevent"]),
                onTouchend: withModifiers(endDrag, ["prevent"]),
                onTouchcancel: endDrag,
                onMousedown: startDrag,
                onMousemove: withModifiers(drag, ["prevent"]),
                onMouseup: endDrag,
                onMouseleave: endDrag
              }, null, 36),
              createBaseVNode("div", {
                class: "dd-slider-thumb",
                style: normalizeStyle({ left: `${unref(percent)}%` })
              }, null, 4),
              createBaseVNode("div", {
                class: "dd-slider-track",
                style: normalizeStyle({ width: `${unref(percent)}%`, backgroundColor: unref(valColor) })
              }, null, 4),
              _cache[0] || (_cache[0] = createBaseVNode("div", { class: "dd-slider-step" }, null, -1))
            ], 4)
          ], 512),
          createBaseVNode("span", {
            class: "dd-slider-value",
            hidden: !__props.showValue
          }, [
            createBaseVNode("p", _hoisted_4, toDisplayString(unref(disValue)), 1)
          ], 8, _hoisted_3)
        ])
      ], 16, _hoisted_1$5);
    };
  }
};
const index$a = withInstall(_sfc_main$9);
const __vite_glob_0_29 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$a
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$4 = ["item-id"];
const _sfc_main$8 = {
  __name: "SwiperItem",
  props: {
    /**
     * 该 swiper-item 的标识符
     */
    itemId: {
      type: String
    },
    /**
     * 是否跳过未显示的滑块布局，设为 true 可优化复杂情况下的滑动性能，但会丢失隐藏状态滑块的布局信息
     */
    skipHiddenItemLayout: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
        class: "dd-swiper-item",
        "item-id": props.itemId
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16, _hoisted_1$4);
    };
  }
};
const index$9 = withInstall(_sfc_main$8);
const __vite_glob_0_30 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$9
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$3 = ["aria-label"];
const _hoisted_2$2 = ["data-dot-index"];
const _sfc_main$7 = {
  __name: "Swiper",
  props: {
    /**
     * 是否显示面板指示点
     */
    indicatorDots: {
      type: Boolean,
      default: false
    },
    /**
     * 指示点颜色
     */
    indicatorColor: {
      type: String,
      default: "rgba(0, 0, 0, .3)"
    },
    /**
     * 当前选中的指示点颜色
     */
    indicatorActiveColor: {
      type: String,
      default: "#000000"
    },
    /**
     * 是否自动切换
     */
    autoplay: {
      type: Boolean,
      default: false
    },
    /**
     * 当前所在滑块的 index
     */
    current: {
      type: Number,
      default: 0
    },
    /**
     * 自动切换时间间隔
     */
    interval: {
      type: Number,
      default: 5e3
    },
    /**
     * 滑动动画时长
     */
    duration: {
      type: Number,
      default: 500
    },
    /**
     * 是否衔接滑动(循环滚动)
     */
    circular: {
      type: Boolean,
      default: false
    },
    /**
     * 滑动方向是否为纵向
     */
    vertical: {
      type: Boolean,
      default: false
    },
    /**
     * 同时显示的滑块数量
     */
    displayMultipleItems: {
      type: Number,
      default: 1
    },
    /**
     * 前边距，可用于露出前一项的一小部分，接受 px 和 rpx 值
     */
    previousMargin: {
      type: String,
      default: "0px"
    },
    /**
     * 指定 swiper 切换缓动动画类型
     * default	默认缓动函数
     * linear	线性动画
     * easeInCubic	缓入动画
     * easeOutCubic	缓出动画
     * easeInOutCubic	缓入缓出动画
     */
    easingFunction: {
      type: String,
      default: "default",
      validator: (value) => {
        return ["default", "linear", "easeInCubic", "easeOutCubic", "easeInOutCubic"].includes(value);
      }
    },
    /**
     * 后边距，可用于露出后一项的一小部分，接受 px 和 rpx 值
     */
    nextMargin: {
      type: String,
      default: "0px"
    },
    /**
     * 当 swiper-item 的个数大于等于 2，关闭 circular 并且开启 previous-margin 或 next-margin 的时候，可以指定这个边距是否应用到第一个、最后一个元素
     */
    snapToEdge: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const info = useInfo();
    const slots = useSlots();
    const slotCount = ref(0);
    const clonedItems = ref([]);
    const realSlotCount = ref(0);
    let isInternalChange = false;
    function findSwiperItems(nodes) {
      var _a;
      const res = [];
      for (let i = 0; i < nodes.length; i++) {
        const vnode = nodes[i];
        if (((_a = vnode.type) == null ? void 0 : _a.__name) === "SwiperItem") {
          res.push(vnode);
        } else if (vnode.children) {
          res.push(...findSwiperItems(vnode.children.default ? vnode.children.default() : vnode.children));
        }
      }
      return res;
    }
    watchEffect(() => {
      if (slots.default) {
        const slotElements = slots.default();
        const res = findSwiperItems(slotElements);
        slotCount.value = res.length;
        if (props.circular && res.length > 1) {
          clonedItems.value = [
            res[res.length - 1],
            // 克隆最后一个元素到最前面
            res[0]
            // 克隆第一个元素到最后面
          ];
          realSlotCount.value = slotCount.value + 2;
        } else {
          clonedItems.value = [];
          realSlotCount.value = slotCount.value;
        }
      } else {
        slotCount.value = 0;
        realSlotCount.value = 0;
      }
    });
    const currentIndex = ref(props.current);
    const swiperSliders = ref(null);
    const swiperFrame = ref(null);
    let startX = 0;
    let startY = 0;
    let isDragging = false;
    let containerRect = { width: 0, height: 0 };
    let moveX = 0;
    let moveY = 0;
    let startTime = 0;
    let lastPositionX = 0;
    let lastPositionY = 0;
    let rafId;
    let source = "";
    const wrapperStyle = ref({
      transform: props.vertical ? `translateY(-${props.current}00%)` : `translateX(-${props.current}00%)`,
      transition: `transform ${props.duration}ms ease`,
      flexDirection: props.vertical ? "column" : "row"
    });
    const easingParsed = computed(() => {
      switch (props.easingFunction) {
        case "linear":
          return "linear";
        case "easeInCubic":
          return "ease-in";
        case "easeOutCubic":
          return "ease-out";
        case "easeInOutCubic":
          return "ease-in-out";
        default:
          return "ease-in";
      }
    });
    function getVelocity(distance, time) {
      return Math.abs(distance) / Math.max(time, 16);
    }
    function checkDirection(deltaX, deltaY, event) {
      const absDeltaX = Math.abs(deltaX);
      const absDeltaY = Math.abs(deltaY);
      if (props.vertical) {
        isDragging = absDeltaX < absDeltaY;
        if (isDragging && absDeltaY > absDeltaX) {
          event.preventDefault();
        }
      } else {
        isDragging = absDeltaX > absDeltaY;
        if (isDragging && absDeltaX > absDeltaY) {
          event.preventDefault();
        }
      }
    }
    function requestMargin() {
      if (props.vertical) {
        swiperSliders.value.style.left = 0;
        swiperSliders.value.style.right = 0;
        swiperSliders.value.style.top = props.previousMargin;
        swiperSliders.value.style.bottom = props.nextMargin;
        swiperFrame.value.style.width = "100%";
        swiperFrame.value.style.height = `${Math.abs(100 / props.displayMultipleItems)}%`;
      } else {
        swiperSliders.value.style.left = props.previousMargin;
        swiperSliders.value.style.right = props.nextMargin;
        swiperSliders.value.style.top = 0;
        swiperSliders.value.style.bottom = 0;
        swiperFrame.value.style.height = "100%";
        swiperFrame.value.style.width = `${Math.abs(100 / props.displayMultipleItems)}%`;
      }
    }
    function setNewCurrent(newCurrent) {
      if (newCurrent === currentIndex.value) {
        return;
      }
      currentIndex.value = newCurrent;
      updateTransform();
      const maxLength = clonedItems.value.length ? realSlotCount.value - 2 : realSlotCount.value;
      triggerEvent("change", {
        info,
        detail: {
          current: (newCurrent + maxLength) % maxLength,
          source
        }
      });
    }
    watch(
      [() => props.vertical, () => props.autoplay, () => props.current, () => props.previousMargin, () => props.nextMargin, () => props.circular],
      ([newVertical, newAutoplay, newCurrent, newPreviousMargin, newNextMargin, newCircular], [oldVertical, oldAutoplay, _oldCurrent, oldPreviousMargin, oldNextMargin, oldCircular]) => {
        if (oldVertical !== newVertical) {
          wrapperStyle.value.flexDirection = newVertical ? "column" : "row";
          updateTransform();
          wrapperStyle.value.transition = "none";
        }
        if (oldAutoplay !== newAutoplay) {
          if (newAutoplay) {
            startAutoplay();
          } else {
            stopAutoplay();
          }
        }
        if (newCurrent !== currentIndex.value && !isInternalChange) {
          source = "";
          setNewCurrent(newCurrent);
        }
        if (oldPreviousMargin !== newPreviousMargin || newNextMargin !== oldNextMargin) {
          requestMargin();
        }
        if (oldCircular !== newCircular) {
          if (clonedItems.value.length) {
            let newCurrent2 = currentIndex.value + 1;
            if (newCurrent2 >= slotCount.value) {
              newCurrent2 = 1;
            }
            if (props.vertical) {
              wrapperStyle.value.transform = `translateY(-${newCurrent2}00%)`;
            } else {
              wrapperStyle.value.transform = `translateX(-${newCurrent2}00%)`;
            }
            wrapperStyle.value.transition = "none";
          } else {
            let newCurrent2 = currentIndex.value - 1;
            if (newCurrent2 < 0) {
              newCurrent2 = 0;
            }
            if (props.vertical) {
              wrapperStyle.value.transform = `translateY(${newCurrent2}00%)`;
            } else {
              wrapperStyle.value.transform = `translateX(${newCurrent2}00%)`;
            }
            wrapperStyle.value.transition = "none";
          }
        }
      }
    );
    function startDrag(event) {
      stopAutoplay();
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
      wrapperStyle.value.transition = "none";
      startTime = Date.now();
      isDragging = false;
      startX = event.touches ? event.touches[0].clientX : event.clientX;
      startY = event.touches ? event.touches[0].clientY : event.clientY;
      moveX = 0;
      moveY = 0;
      containerRect = {
        width: swiperFrame.value.offsetWidth,
        height: swiperFrame.value.offsetHeight
      };
      const rect = swiperFrame.value.getBoundingClientRect();
      lastPositionX = rect.x;
      lastPositionY = rect.y;
    }
    function drag(event) {
      moveX = (event.touches ? event.touches[0].clientX : event.clientX) - startX;
      moveY = (event.touches ? event.touches[0].clientY : event.clientY) - startY;
      checkDirection(moveX, moveY, event);
      if (!isDragging) {
        return;
      }
      let move = props.vertical ? moveY : moveX;
      const containerSize = props.vertical ? containerRect.height : containerRect.width;
      const moveRatio = move / containerSize;
      if (props.circular) {
        const isAtStart = currentIndex.value === 0;
        const isAtEnd = currentIndex.value === (clonedItems.value.length ? realSlotCount.value - 3 : realSlotCount.value - 1);
        if (isAtStart && move > 0 || isAtEnd && move < 0) {
          const dampingFactor = Math.abs(moveRatio);
          if (isAtStart && move > 0) {
            move = move * (0.5 - 0.25 / (dampingFactor + 0.5));
          } else if (isAtEnd && move < 0) {
            move = move * (0.5 - 0.25 / (dampingFactor + 0.5));
          }
        }
      }
      if (props.vertical) {
        const translateY = 100 * (move / containerRect.height - (currentIndex.value + (clonedItems.value.length ? 1 : 0)));
        wrapperStyle.value.transform = `translateY(${translateY}%)`;
      } else {
        const translateX = 100 * (move / containerRect.width - (currentIndex.value + (clonedItems.value.length ? 1 : 0)));
        wrapperStyle.value.transform = `translateX(${translateX}%)`;
      }
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
    }
    function endDrag() {
      if (!isDragging) {
        wrapperStyle.value.transform = props.vertical ? `translateY(-${currentIndex.value}00%)` : `translateX(-${currentIndex.value}00%)`;
        return;
      }
      const elapsedTime = Date.now() - startTime;
      startAutoplay();
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
      const move = props.vertical ? moveY : moveX;
      if (move === 0) {
        isDragging = false;
        startAutoplay();
        return;
      }
      const velocity = getVelocity(move, elapsedTime);
      const VELOCITY_THRESHOLD = 0.2;
      const fallback = () => {
        const isAtEdge = currentIndex.value === 0 || currentIndex.value === slotCount.value - 1;
        const edgeEasing = isAtEdge ? "cubic-bezier(0.34, 1.56, 0.64, 1)" : easingParsed.value;
        wrapperStyle.value.transition = `transform ${props.duration}ms ${edgeEasing}`;
        wrapperStyle.value.transform = props.vertical ? `translateY(-${currentIndex.value}00%)` : `translateX(-${currentIndex.value}00%)`;
      };
      if (slotCount.value > 1) {
        if (Math.abs(velocity) > VELOCITY_THRESHOLD) {
          const speedFactor = Math.min(Math.max(Math.abs(velocity), 0.5), 1.5);
          const newDuration = Math.round(props.duration / speedFactor);
          wrapperStyle.value.transition = `transform ${newDuration}ms ${easingParsed.value}`;
          source = "touch";
          if (move > 0) {
            prevSlide(fallback);
          } else {
            nextSlide(fallback);
          }
        } else {
          fallback();
        }
      } else {
        fallback();
      }
      isDragging = false;
      startAutoplay();
    }
    function nextSlide(fallback) {
      const newCurrent = Math.min(currentIndex.value + 1, clonedItems.value.length ? realSlotCount.value - 2 : realSlotCount.value - 1);
      if (newCurrent === currentIndex.value) {
        fallback == null ? void 0 : fallback();
        return;
      }
      isInternalChange = true;
      setNewCurrent(newCurrent);
    }
    function prevSlide(fallback) {
      const newCurrent = Math.max(currentIndex.value - 1, clonedItems.value.length ? -1 : 0);
      if (newCurrent === currentIndex.value) {
        fallback == null ? void 0 : fallback();
        return;
      }
      isInternalChange = true;
      setNewCurrent(newCurrent);
    }
    function handleTransitionEnd(event) {
      isInternalChange = false;
      if (props.circular && slotCount.value > 1) {
        if (currentIndex.value === slotCount.value) {
          currentIndex.value = 0;
          wrapperStyle.value.transform = props.vertical ? "translateY(-100%)" : "translateX(-100%)";
          wrapperStyle.value.transition = "none";
        } else if (currentIndex.value === -1) {
          currentIndex.value = slotCount.value - 1;
          wrapperStyle.value.transform = props.vertical ? `translateY(-${slotCount.value}00%)` : `translateX(-${slotCount.value}00%)`;
          wrapperStyle.value.transition = "none";
        }
      }
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
      triggerEvent("animationfinish", {
        event,
        info,
        detail: {
          current: currentIndex.value,
          source
        }
      });
    }
    function updateTransform() {
      let translateValue = currentIndex.value;
      if (clonedItems.value.length) {
        translateValue += 1;
      }
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
      if (props.vertical) {
        wrapperStyle.value.transform = `translateY(-${translateValue}00%)`;
      } else {
        wrapperStyle.value.transform = `translateX(-${translateValue}00%)`;
      }
      wrapperStyle.value.transition = `transform ${props.duration}ms ${easingParsed.value}`;
      rafId = requestAnimationFrame(monitorAnimation);
    }
    function monitorAnimation() {
      if (rafId) {
        cancelAnimationFrame(rafId);
        rafId = void 0;
      }
      const rect = swiperFrame.value.getBoundingClientRect();
      if (props.vertical) {
        const dy = lastPositionY - rect.y;
        triggerEvent("transition", {
          info,
          detail: {
            dx: 0,
            dy
          }
        });
      } else {
        const dx = lastPositionX - rect.x;
        triggerEvent("transition", {
          info,
          detail: {
            dx,
            dy: 0
          }
        });
      }
    }
    let intervalId;
    function startAutoplay() {
      if (props.autoplay && slotCount.value > 1) {
        stopAutoplay();
        intervalId = setInterval(() => {
          if (isDragging) {
            return;
          }
          source = "autoplay";
          nextSlide();
        }, props.interval);
      }
    }
    function stopAutoplay() {
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    }
    onMounted(() => {
      requestMargin();
      if (clonedItems.value.length) {
        updateTransform();
        wrapperStyle.value.transition = "none";
      }
      startAutoplay();
    });
    onBeforeUnmount(() => {
      stopAutoplay();
      cancelAnimationFrame(rafId);
      rafId = null;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, { class: "dd-swiper" }), [
        createBaseVNode("div", {
          class: "dd-swiper-wrapper",
          "aria-label": Boolean(props.vertical) ? "可竖向滚动" : "可横向滚动",
          onTouchstart: startDrag,
          onTouchmove: drag,
          onTouchend: endDrag,
          onTouchcancel: endDrag,
          onMousedown: startDrag,
          onMousemove: drag,
          onMouseup: endDrag,
          onMouseleave: endDrag
        }, [
          createBaseVNode("div", {
            ref_key: "swiperSliders",
            ref: swiperSliders,
            class: "dd-swiper-slides"
          }, [
            createBaseVNode("div", {
              ref_key: "swiperFrame",
              ref: swiperFrame,
              class: "dd-swiper-slide-frame",
              style: normalizeStyle(unref(wrapperStyle)),
              onTransitionend: handleTransitionEnd
            }, [
              unref(clonedItems).length ? (openBlock(), createBlock(resolveDynamicComponent(unref(clonedItems)[0]), {
                key: 0,
                "data-dd-cloned": ""
              })) : createCommentVNode("", true),
              renderSlot(_ctx.$slots, "default"),
              unref(clonedItems).length ? (openBlock(), createBlock(resolveDynamicComponent(unref(clonedItems)[1]), {
                key: 1,
                "data-dd-cloned": ""
              })) : createCommentVNode("", true)
            ], 36)
          ], 512),
          Boolean(props.indicatorDots) && unref(slotCount) > 0 ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(["dd-swiper-dots", {
              "dd-swiper-dots-horizontal": !Boolean(props.vertical),
              "dd-swiper-dots-vertical": Boolean(props.vertical)
            }])
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(slotCount), (idx) => {
              return openBlock(), createElementBlock("div", {
                key: idx,
                "data-dot-index": idx,
                class: normalizeClass(["dd-swiper-dot", { "dd-swiper-dot-active": idx - 1 === unref(currentIndex) }])
              }, null, 10, _hoisted_2$2);
            }), 128))
          ], 2)) : createCommentVNode("", true)
        ], 40, _hoisted_1$3)
      ], 16);
    };
  }
};
const index$8 = withInstall(_sfc_main$7);
const __vite_glob_0_31 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$8
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$2 = ["id"];
const _hoisted_2$1 = ["id"];
const _sfc_main$6 = {
  __name: "Switch",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    name: {
      type: String
    },
    /**
     * 是否选中
     */
    checked: {
      type: Boolean,
      default: false
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false
    },
    /**
     * 样式，有效值 switch, checkbox
     */
    type: {
      type: String,
      default: "switch",
      validator: (value) => {
        return ["switch", "checkbox"].includes(value);
      }
    },
    /**
     * switch 的颜色，同 css 的 color
     */
    color: {
      type: String,
      default: "#04BE02"
    }
  },
  setup(__props) {
    useCssVars((_ctx) => ({
      "51f78e61": unref(computedCheckColor),
      "68f2ff06": unref(computedColor)
    }));
    const props = __props;
    const isOn2 = ref(props.checked);
    const collectFormValue = inject("collectFormValue", void 0);
    watch(
      () => props.checked,
      (newVal) => {
        isOn2.value = newVal;
        collectFormValue == null ? void 0 : collectFormValue(props.name, isOn2.value);
      },
      { immediate: true }
      // 立即执行一次回调
    );
    const computedCheckColor = computed(() => {
      if (props.color && isOn2.value) {
        if (props.type === "checkbox") {
          return props.color;
        } else {
          return "initial";
        }
      } else {
        return "initial";
      }
    });
    const computedColor = computed(() => {
      if (props.color && isOn2.value) {
        if (props.type !== "checkbox") {
          return props.color;
        } else {
          return "#dfdfdf";
        }
      } else {
        return "#dfdfdf";
      }
    });
    const info = useInfo();
    function handleClicked(event) {
      if (!props.disabled) {
        isOn2.value = !isOn2.value;
        collectFormValue == null ? void 0 : collectFormValue(props.name, isOn2.value);
        triggerEvent("change", {
          event,
          info,
          detail: {
            value: isOn2.value
          }
        });
      }
    }
    return (_ctx, _cache) => {
      return __props.type === "checkbox" ? (openBlock(), createElementBlock("div", mergeProps({
        key: 0,
        id: __props.id
      }, _ctx.$attrs, {
        class: ["dd-checkbox-input", { "dd-checkbox-input-checked": unref(isOn2), "dd-checkbox-input-disabled": __props.disabled }],
        onClick: handleClicked
      }), null, 16, _hoisted_1$2)) : (openBlock(), createElementBlock("div", mergeProps({
        key: 1,
        id: __props.id
      }, _ctx.$attrs, {
        class: ["dd-switch-input", { "dd-switch-input-checked": unref(isOn2) }],
        onClick: handleClicked
      }), null, 16, _hoisted_2$1));
    };
  }
};
const index$7 = withInstall(_sfc_main$6);
const __vite_glob_0_32 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$7
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$5 = {
  __name: "Template",
  props: {
    is: {
      type: String,
      required: true
    },
    data: {
      type: Object
    }
  },
  setup(__props) {
    const props = __props;
    const tplCom = computed(() => {
      return `tpl-${props.is}`;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(resolveDynamicComponent(unref(tplCom)), mergeProps(_ctx.$attrs, { data: __props.data }), null, 16, ["data"]);
    };
  }
};
const index$6 = withInstall(_sfc_main$5);
const __vite_glob_0_33 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$6
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$4 = {
  __name: "Text",
  props: {
    /**
     * 文本是否可选，该属性会使文本节点显示为 inline-block
     */
    userSelect: {
      type: Boolean,
      default: false
    },
    /**
     * 显示连续空格
     * ensp	中文字符空格一半大小
     * emsp	中文字符空格大小
     * nbsp	根据字体设置的空格大小
     */
    space: {
      type: String,
      validator: (value) => {
        return ["ensp", "emsp", "nbsp"].includes(value);
      }
    },
    /**
     * 是否解码
     * decode可以解析的有 &nbsp; &lt; &gt; &amp; &apos; &ensp; &emsp;
     */
    decode: {
      type: Boolean,
      default: false
    }
  },
  setup(__props) {
    const props = __props;
    const textRef = ref(null);
    function htmlDecode(e) {
      return props.space && (this.space === "nbsp" ? e = e.replace(/ /g, " ") : this.space === "ensp" ? e = e.replace(/ /g, " ") : this.space === "emsp" && (e = e.replace(/ /g, " "))), props.decode ? e.replace(/&nbsp;/g, " ").replace(/&ensp;/g, " ").replace(/&emsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, "&") : e;
    }
    onMounted(() => {
      if (textRef.value) {
        const nodes = textRef.value.childNodes;
        for (let i = 0; i < nodes.length; i++) {
          const node = nodes[i];
          if (node.nodeType === Node.TEXT_NODE) {
            const text = node.nodeValue;
            const decodedText = htmlDecode(text);
            const splitText = decodedText.split("\\n");
            if (splitText.length > 1) {
              const newNode = document.createDocumentFragment();
              for (i = 0; i < splitText.length; i++) {
                newNode.appendChild(document.createTextNode(splitText[i]));
                if (i < splitText.length - 1) {
                  newNode.appendChild(document.createElement("br"));
                }
              }
              node.parentNode.replaceChild(newNode, node);
            } else {
              if (decodedText !== text) {
                const newNode = document.createTextNode(decodedText);
                node.parentNode.replaceChild(newNode, node);
              }
            }
          }
        }
      }
    });
    const info = useInfo();
    function handleClicked(event) {
      if (!props.disabled) {
        if (props.hoverStopPropagation) {
          event.stopPropagation();
        }
        triggerEvent("tap", { event, info });
      }
    }
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("span", mergeProps({
        ref_key: "textRef",
        ref: textRef
      }, _ctx.$attrs, {
        class: ["dd-text", { "dd-text-selectable": __props.userSelect }],
        onClick: handleClicked
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$5 = withInstall(_sfc_main$4);
const __vite_glob_0_34 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$5
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$1 = ["id", "value", "disabled"];
const _sfc_main$3 = {
  __name: "Textarea",
  props: {
    /**
     * id，为 label 使用
     */
    id: {
      type: String
    },
    /**
     * name，为表单使用
     */
    name: {
      type: String
    },
    /**
     * 输入框的内容
     */
    value: {
      type: String,
      required: false,
      default: ""
    },
    /**
     * 输入框为空时占位符
     */
    placeholder: {
      type: String,
      required: false
    },
    /**
     * 指定 placeholder 的样式，目前仅支持color,font-size和font-weight
     */
    placeholderStyle: {
      type: [String, Object],
      required: false,
      default() {
        return {};
      }
    },
    /**
     * 是否禁用
     */
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 最大输入长度，设置为 -1 的时候不限制最大长度
     */
    maxlength: {
      type: Number,
      default: 140,
      required: false
    },
    /**
     * 自动聚焦，拉起键盘
     */
    autoFocus: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 获取焦点
     */
    focus: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 是否自动增高，设置auto-height时，style.height不生效
     */
    autoHeight: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 指定光标与键盘的距离。取textarea距离底部的距离和cursor-spacing指定的距离的最小值作为光标与键盘的距离
     */
    cursorSpacing: {
      type: Number,
      default: 0,
      required: false
    },
    /**
     * 指定focus时的光标位置
     */
    cursor: {
      type: Number,
      default: -1,
      required: false
    },
    /**
     * 是否显示键盘上方带有”完成“按钮那一栏
     */
    showConfirmBar: {
      type: Boolean,
      default: true,
      required: false
    },
    /**
     * 光标起始位置，自动聚集时有效，需与selection-end搭配使用
     */
    selectionStart: {
      type: Number,
      default: -1,
      required: false
    },
    /**
     * 光标结束位置，自动聚集时有效，需与selection-start搭配使用
     */
    selectionEnd: {
      type: Number,
      default: -1,
      required: false
    },
    /**
     * 键盘弹起时，是否自动上推页面
     */
    adjustPosition: {
      type: Boolean,
      default: true,
      required: false
    },
    /**
     * focus时，点击页面的时候不收起键盘
     */
    holdKeyboard: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 是否去掉 iOS 下的默认内边距
     */
    disableDefaultPadding: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 设置键盘右下角按钮的文字
     */
    confirmType: {
      type: String,
      default: "return",
      required: false,
      validator: (value) => ["send", "search", "next", "go", "done", "return"].includes(value)
    },
    /**
     * 点击键盘右下角按钮时是否保持键盘不收起
     */
    confirmHold: {
      type: Boolean,
      default: false,
      required: false
    },
    /**
     * 键盘对齐位置
     */
    adjustKeyboardTo: {
      type: String,
      default: "cursor",
      required: false,
      validator: (value) => ["cursor", "bottom"].includes(value)
    },
    /**
     * 指定 placeholder 的样式类，目前仅支持color,font-size和font-weight
     */
    placeholderClass: {
      type: String,
      default: "textarea-placeholder"
    },
    /**
     * 如果 textarea 是在一个 position:fixed 的区域，需要显示指定属性 fixed 为 true
     */
    fixed: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:value"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit2 = __emit;
    const computedPlaceholderStyle = computed(() => {
      const placeholderColor = () => {
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/color:([^;]+)/);
          if (match) {
            return match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "color")) {
            return props.placeholderStyle.color;
          }
        }
        return "rgba(0,0,0,.3)";
      };
      const placeholderFontSize = () => {
        let size;
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/font-size:([^;]+)/);
          if (match) {
            size = match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-size")) {
            size = props.placeholderStyle["font-size"];
          }
        }
        return size ? transformRpx(size) : "inherit";
      };
      const placeholderFontWeight = () => {
        if (typeof props.placeholderStyle === "string") {
          const match = props.placeholderStyle.match(/font-weight:([^;]+)/);
          if (match) {
            return match[1].trim();
          }
        } else {
          if (Object.prototype.hasOwnProperty.call(props.placeholderStyle, "font-weight")) {
            return props.placeholderStyle["font-weight"];
          }
        }
        return "inherit";
      };
      return {
        color: placeholderColor(),
        fontSize: placeholderFontSize(),
        fontWeight: placeholderFontWeight()
      };
    });
    const collectFormValue = inject("collectFormValue", void 0);
    collectFormValue == null ? void 0 : collectFormValue(props.name, props.value);
    const textareaRef = ref(null);
    const keyCode = ref(null);
    const iValue = ref(props.value);
    const placeholderShow = computed(() => {
      var _a;
      return !iValue.value || ((_a = iValue.value) == null ? void 0 : _a.length) === 0;
    });
    const vFocus = {
      mounted: async (el) => {
        if (!props.autoFocus) {
          return;
        }
        if (isDesktop) {
          await sleep(540);
        }
        el.focus();
      }
    };
    watch(
      [() => props.focus, () => props.value],
      ([nF, nV], [, preV]) => {
        nF && textareaRef.value.focus();
        if (preV !== nV) {
          iValue.value = nV;
        }
      }
    );
    const wrapperRef = ref(null);
    const info = useInfo();
    function handleKeydown(event) {
      keyCode.value = event.keyCode;
      if (event.keyCode === 13) {
        if (!props.confirmHold) {
          event.target.blur();
        }
        triggerEvent("confirm", {
          event,
          info,
          detail: {
            value: event.target.value
          }
        });
      }
    }
    function handleWrapperEvent(event) {
      if (event.target.tagName.toLowerCase() !== "textarea") {
        return;
      }
      const value = event.target.value;
      switch (event.type) {
        case "input":
          collectFormValue == null ? void 0 : collectFormValue(props.name, value);
          iValue.value = value;
          emit2("update:value", value);
          triggerEvent("input", {
            event,
            info,
            detail: {
              value,
              cursor: event.target.selectionEnd,
              keyCode: keyCode.value
            },
            success: (data) => {
              iValue.value = data.value ?? data;
              emit2("update:value", data.value ?? data);
            }
          });
          break;
        case "focusin":
          triggerEvent("focus", {
            event,
            info,
            detail: {
              value
            }
          });
          if (!isDesktop && props.adjustPosition) {
            const element = wrapperRef.value;
            if (!element) {
              return;
            }
            const bottom = getActualBottom(element);
            invokeAPI("adjustPosition", {
              bridgeId: info.bridgeId,
              params: {
                bottom
              }
            });
          }
          break;
        case "focusout":
          triggerEvent("blur", {
            event,
            info,
            detail: {
              value,
              cursor: event.target.selectionEnd
            }
          });
          break;
      }
    }
    const wrapperClass = computed(() => {
      return {
        "dd-textarea-wrapper": true,
        "dd-textarea-disabled": props.disabled
      };
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps({
        ref_key: "wrapperRef",
        ref: wrapperRef
      }, _ctx.$attrs, {
        class: unref(wrapperClass),
        role: "textbox",
        onInput: handleWrapperEvent,
        onFocusin: handleWrapperEvent,
        onFocusout: handleWrapperEvent
      }), [
        withDirectives(createBaseVNode("textarea", {
          id: __props.id,
          ref_key: "textareaRef",
          ref: textareaRef,
          class: "dd-textarea",
          value: unref(iValue),
          disabled: __props.disabled,
          onKeydown: handleKeydown
        }, null, 40, _hoisted_1$1), [
          [vFocus]
        ]),
        withDirectives(createBaseVNode("div", {
          class: normalizeClass(["dd-textarea-placeholder", __props.placeholderClass]),
          style: normalizeStyle(unref(computedPlaceholderStyle))
        }, toDisplayString(__props.placeholder), 7), [
          [vShow, unref(placeholderShow)]
        ])
      ], 16);
    };
  }
};
const index$4 = withInstall(_sfc_main$3);
const __vite_glob_0_35 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$4
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main$2 = {
  __name: "Video",
  props: {
    /**
     * 要播放视频的资源地址，支持网络路径、本地临时路径
     */
    src: {
      type: String,
      required: true
    },
    /**
     * 指定视频时长
     */
    duration: {
      type: Number,
      required: false
    },
    /**
     * 是否显示默认播放控件（播放/暂停按钮、播放进度、时间）
     */
    controls: {
      type: Boolean,
      required: false,
      default: true
    }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", normalizeProps(guardReactiveProps(_ctx.$attrs)), null, 16);
    };
  }
};
const index$3 = withInstall(_sfc_main$2);
const __vite_glob_0_36 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$3
}, Symbol.toStringTag, { value: "Module" }));
const index$2 = withInstall(_sfc_main$w);
const __vite_glob_0_37 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$2
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1 = ["src"];
const _hoisted_2 = ["id"];
const UNMATCHED_SURROGATE_PAIR_REPLACE = "$1�$2";
const type = "native/webview";
const _sfc_main$1 = {
  __name: "WebView",
  props: {
    /**
     * webview id
     */
    id: {
      type: String,
      default: `web-view_${Date.now()}_${String(Math.random()).slice(-3)}`
    },
    /**
     *	webview 指向网页的链接
     */
    src: {
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    const ENCODE_CHARS_REGEXP = /(?:[^\x21\x25\x26-\x3B\x3D\x3F-\x5B\x5D\x5F\x7E]|%(?:[^0-9A-F]|[0-9A-F][^0-9A-F]|$))+/gi;
    const UNMATCHED_SURROGATE_PAIR_REGEXP = /(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]|[\uD800-\uDBFF]([^\uDC00-\uDFFF]|$)/g;
    const url = computed(() => {
      return String(props.src).replace(UNMATCHED_SURROGATE_PAIR_REGEXP, UNMATCHED_SURROGATE_PAIR_REPLACE).replace(ENCODE_CHARS_REGEXP, encodeURI);
    });
    const info = useInfo();
    const attrs = info.attrs;
    function getEventAttrs() {
      const eventAttrs = {};
      for (const attrName in attrs) {
        if (attrName.startsWith("bind") || attrName.startsWith("catch")) {
          eventAttrs[attrName.replace(/^(?:bind:|bind|catch:|catch)/, "")] = attrs[attrName];
        }
      }
      return eventAttrs;
    }
    watch(
      [
        () => props.src,
        () => props.id
      ],
      ([newSrc, newId]) => {
        invokeAPI("propsUpdate", {
          bridgeId: info.bridgeId,
          params: {
            type,
            src: newSrc,
            id: newId
          }
        });
      }
    );
    onBeforeMount(() => {
      onEvent("bindmessage", (msg) => {
        triggerEvent("message", {
          info,
          detail: {
            data: msg.data
          }
        });
      });
      onEvent("bindload", (msg) => {
        triggerEvent("load", {
          info,
          detail: {
            src: msg.src,
            id: msg.id
          }
        });
      });
      onEvent("binderror", (msg) => {
        triggerEvent("error", {
          info,
          detail: {
            url: msg.url,
            fullUrl: msg.fullUrl,
            id: msg.id
          }
        });
      });
      invokeAPI("componentMount", {
        bridgeId: info.bridgeId,
        params: {
          type,
          url: url.value,
          id: props.id,
          attributes: {
            moduleId: info.moduleId,
            attrs: getEventAttrs(),
            src: url.value,
            javascript: `
					function handleSdkFn(){
						window.__wxjs_environment = 'miniprogram';
						var sdk = document.createElement('script');
						sdk.onload = () => {
							window.dispatchEvent(new Event('didiJsBridgeLoaded'))
						};
						sdk.src = 'https://dpubstatic.udache.com/static/dpubimg/UBi0mvYdYcbwXv5qZ9ANw_jdimina_next.js?' + Date.now();
						document.getElementsByTagName('html')[0].appendChild(sdk);
						return (typeof document.getElementsByTagName('html')[0]);
					};
					handleSdkFn()`
          }
        }
      });
    });
    onBeforeUnmount(() => {
      invokeAPI("componentUnmount", {
        bridgeId: info.bridgeId,
        params: {
          type,
          url: url.value,
          id: props.id
        }
      });
      offEvent("bindmessage");
      offEvent("bindload");
      offEvent("binderror");
    });
    return (_ctx, _cache) => {
      return unref(isDesktop) ? (openBlock(), createElementBlock("iframe", mergeProps({ key: 0 }, _ctx.$attrs, {
        class: "dd-web-view dd-web-view-pc",
        type,
        src: unref(url)
      }), null, 16, _hoisted_1)) : (openBlock(), createElementBlock("embed", mergeProps({
        key: 1,
        id: __props.id
      }, _ctx.$attrs, {
        class: "dd-web-view",
        type
      }), null, 16, _hoisted_2));
    };
  }
};
const index$1 = withInstall(_sfc_main$1);
const __vite_glob_0_38 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$1
}, Symbol.toStringTag, { value: "Module" }));
const _sfc_main = {
  __name: "Wrapper",
  setup(__props) {
    useInfo();
    const wrapperRef = ref(null);
    onMounted(() => {
      var _a;
      const slotContent = (_a = wrapperRef.value) == null ? void 0 : _a.firstElementChild;
      if (slotContent) {
        const style = window.getComputedStyle(slotContent);
        if (style.position === "sticky" && (style.top !== "auto" || style.bottom !== "auto" || style.left !== "auto" || style.right !== "auto")) {
          wrapperRef.value.style.display = "contents";
        }
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", mergeProps(_ctx.$attrs, {
        ref_key: "wrapperRef",
        ref: wrapperRef
      }), [
        renderSlot(_ctx.$slots, "default")
      ], 16);
    };
  }
};
const index$E = withInstall(_sfc_main);
const __vite_glob_0_39 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: index$E
}, Symbol.toStringTag, { value: "Module" }));
const componentsInfo = /* @__PURE__ */ Object.assign({ "./component/block/index.js": __vite_glob_0_0, "./component/button/index.js": __vite_glob_0_1, "./component/camera/index.js": __vite_glob_0_2, "./component/checkbox-group/index.js": __vite_glob_0_3, "./component/checkbox/index.js": __vite_glob_0_4, "./component/cover-image/index.js": __vite_glob_0_5, "./component/cover-view/index.js": __vite_glob_0_6, "./component/form/index.js": __vite_glob_0_7, "./component/icon/index.js": __vite_glob_0_8, "./component/image/index.js": __vite_glob_0_9, "./component/input/index.js": __vite_glob_0_10, "./component/keyboard-accessory/index.js": __vite_glob_0_11, "./component/label/index.js": __vite_glob_0_12, "./component/map/index.js": __vite_glob_0_13, "./component/movable-area/index.js": __vite_glob_0_14, "./component/movable-view/index.js": __vite_glob_0_15, "./component/navigation-bar/index.js": __vite_glob_0_16, "./component/navigator/index.js": __vite_glob_0_17, "./component/open-data/index.js": __vite_glob_0_18, "./component/page-meta/index.js": __vite_glob_0_19, "./component/picker-view-column/index.js": __vite_glob_0_20, "./component/picker-view/index.js": __vite_glob_0_21, "./component/picker/index.js": __vite_glob_0_22, "./component/progress/index.js": __vite_glob_0_23, "./component/radio-group/index.js": __vite_glob_0_24, "./component/radio/index.js": __vite_glob_0_25, "./component/rich-text/index.js": __vite_glob_0_26, "./component/root-portal/index.js": __vite_glob_0_27, "./component/scroll-view/index.js": __vite_glob_0_28, "./component/slider/index.js": __vite_glob_0_29, "./component/swiper-item/index.js": __vite_glob_0_30, "./component/swiper/index.js": __vite_glob_0_31, "./component/switch/index.js": __vite_glob_0_32, "./component/template/index.js": __vite_glob_0_33, "./component/text/index.js": __vite_glob_0_34, "./component/textarea/index.js": __vite_glob_0_35, "./component/video/index.js": __vite_glob_0_36, "./component/view/index.js": __vite_glob_0_37, "./component/web-view/index.js": __vite_glob_0_38, "./component/wrapper/index.js": __vite_glob_0_39 });
const components = Object.values(componentsInfo).map((module) => {
  return module.default;
});
function transformAnimation(el, propertyValue) {
  var _a;
  if (!((_a = propertyValue == null ? void 0 : propertyValue.actions) == null ? void 0 : _a.length))
    return;
  let currentIndex = 0;
  const actions = propertyValue.actions;
  function executeAnimation() {
    if (currentIndex >= actions.length)
      return;
    const currentAction = actions[currentIndex];
    const style = animationToStyle(currentAction);
    const animation = el.animate(
      style.keyframes,
      style.options
    );
    animation.onfinish = () => {
      currentIndex++;
      executeAnimation();
    };
  }
  executeAnimation();
}
function transformCss(el, val, append) {
  const convertedStyle = transformRpx(val);
  if (append) {
    el.style.cssText += convertedStyle;
  } else {
    el.style.cssText = convertedStyle;
  }
}
function parseDataset(el, vnode) {
  el._ds = getDataAttributes(vnode.ctx.attrs, deepToRaw);
}
function parseExternalClass(el, instance, vnode) {
  const ctx = vnode.ctx;
  if (ctx.provides.externalClass) {
    for (const cls of el.classList) {
      const clsName = instance.props[toCamelCase(cls)];
      if (clsName) {
        el.className = el.className.replace(cls, clsName);
        if (!el.hasAttribute(instance.sId)) {
          el.setAttribute(instance.sId, "");
        }
      }
    }
  }
}
function Components(app) {
  app.directive("c-style", {
    mounted(el, binding) {
      transformCss(el, binding.value, true);
    },
    updated(el, binding) {
      transformCss(el, binding.value, false);
    }
  });
  app.directive("c-animation", {
    mounted(el, binding) {
      transformAnimation(el, binding.value);
    },
    updated(el, binding) {
      transformAnimation(el, binding.value);
    }
  });
  app.directive("c-data", {
    mounted(el, _binding, vnode) {
      parseDataset(el, vnode);
    },
    updated(el, _binding, vnode) {
      parseDataset(el, vnode);
    }
  });
  app.directive("c-class", {
    mounted(el, binding, vnode) {
      parseExternalClass(el, binding.instance, vnode);
    },
    updated(el, binding, vnode) {
      parseExternalClass(el, binding.instance, vnode);
    }
  });
  return components.forEach((component) => {
    component.mixins = [{
      inheritAttrs: false
    }];
    install(app, component);
  });
}
components.map((obj) => obj.__tagName);
class Runtime {
  constructor() {
    this.app = null;
    this.pageId = null;
    this.instance = /* @__PURE__ */ new Map();
    this.intersectionObservers = /* @__PURE__ */ new Map();
    window._Fragment = Fragment;
    window._createTextVNode = createTextVNode;
    window._createVNode = createVNode;
    window._createBlock = createBlock;
    window._createCommentVNode = createCommentVNode;
    window._createElementBlock = createElementBlock;
    window._createElementVNode = createBaseVNode;
    window._createSlots = createSlots;
    window._normalizeClass = normalizeClass;
    window._normalizeStyle = normalizeStyle;
    window._openBlock = openBlock;
    window._renderList = renderList;
    window._renderSlot = renderSlot;
    window._resolveComponent = resolveComponent;
    window._resolveDirective = resolveDirective;
    window._resolveDynamicComponent = resolveDynamicComponent;
    window._toDisplayString = toDisplayString;
    window._withCtx = withCtx;
    window._withDirectives = withDirectives;
    window.addEventListener("beforeunload", () => {
      if (this.intersectionObservers.size > 0) {
        for (const observers of this.intersectionObservers.values()) {
          observers.forEach((observer) => observer.disconnect());
        }
        this.intersectionObservers.clear();
      }
    });
  }
  /**
   * 首次渲染
   * [Container] resourceLoaded -> [Service] firstRender -> [Render] firstRender
   * @param {*} opts
   */
  firstRender(opts) {
    const { bridgeId, pagePath, pageId, query } = opts;
    const options = this.makeOptions({
      path: pagePath,
      bridgeId,
      pageId,
      query
    });
    if (this.app != null) {
      this.app.unmount();
    }
    this.app = createApp(options.app);
    this.app.use(Components);
    for (const [tplName, render] of Object.entries(options.tplComponents)) {
      this.app.component(`dd-${tplName}`, {
        __scopeId: `data-v-${options.id}`,
        props: {
          data: Object
        },
        data() {
          return {
            ...this.data
          };
        },
        render
      });
    }
    this.app.mount(document.body);
  }
  // Component create -> Page create -> Page attached -> Component attached -> Component ready -> Page ready
  // Component attached -> Page onLoad -> Page onShow -> Component ready -> onReady
  makeOptions(opts) {
    const { path, bridgeId, pageId } = opts;
    const pageModule = loader.getModuleByPath(path);
    const { id, usingComponents, tplComponents } = pageModule.moduleInfo;
    this.pageId = pageId;
    const components2 = this.createComponent(path, bridgeId, usingComponents);
    const self2 = this;
    const rootCom = "dd-page";
    const sId = `data-v-${id}`;
    return {
      id,
      tplComponents,
      app: {
        render: () => {
          const _component_dd_page = resolveComponent(rootCom);
          return h(Suspense, {
            onResolve: () => {
              message.invoke({
                type: "domReady",
                target: "container",
                body: {
                  bridgeId
                }
              });
            }
          }, {
            default: () => h(_component_dd_page, { class: "dd-page" })
            // fallback: () => h('div', 'Loading...'),
          });
        },
        components: {
          [rootCom]: {
            __scopeId: sId,
            async setup(_props, { expose }) {
              expose();
              provide("bridgeId", bridgeId);
              provide("path", path);
              provide(path, {
                id: self2.pageId
              });
              provide("info", {
                id: self2.pageId,
                sId
              });
              const instance = getCurrentInstance().proxy;
              instance.__page__ = true;
              self2.instance.set(self2.pageId, instance);
              let ticking = false;
              const handleScroll = () => {
                if (!ticking) {
                  window.requestAnimationFrame(() => {
                    message.send({
                      type: "pageScroll",
                      target: "service",
                      body: {
                        bridgeId,
                        moduleId: self2.pageId,
                        scrollTop: window.scrollY
                      }
                    });
                    ticking = false;
                  });
                  ticking = true;
                }
              };
              onMounted(() => {
                window.addEventListener("scroll", handleScroll, { passive: true });
                nextTick(() => {
                  message.send({
                    type: "pageReady",
                    target: "service",
                    body: {
                      bridgeId,
                      moduleId: self2.pageId
                    }
                  });
                });
              });
              onUnmounted(() => {
                window.removeEventListener("scroll", handleScroll);
              });
              const data = reactive({});
              const initData = await message.wait(self2.pageId);
              const entries = Object.entries(initData);
              for (let i = 0; i < entries.length; i++) {
                const [key, value] = entries[i];
                set(data, key, value);
              }
              return data;
            },
            components: components2,
            render: pageModule.moduleInfo.render
          }
        }
      }
    };
  }
  createComponent(path, bridgeId, usingComponents) {
    if (!usingComponents || Object.keys(usingComponents).length === 0) {
      return;
    }
    const components2 = {};
    const self2 = this;
    for (const [componentName, componentPath] of Object.entries(usingComponents)) {
      const module = loader.getModuleByPath(componentPath);
      const { id, usingComponents: subUsing } = module.moduleInfo;
      const subComponents = this.createComponent(componentPath, bridgeId, subUsing);
      const sId = `data-v-${id}`;
      components2[`dd-${componentName}`] = {
        __scopeId: sId,
        components: subComponents,
        props: module.props,
        async setup(props, { attrs, expose }) {
          const parentInfo = inject("info");
          expose({
            props,
            sId: parentInfo.sId
          });
          const parentId = parentInfo.id;
          const pageInfo = inject(path);
          const pageId = pageInfo.id;
          const moduleId = `${id}_${uuid()}`;
          provide("info", {
            id: moduleId,
            sId
          });
          provide("path", componentPath);
          provide(componentPath, {
            id: moduleId,
            pagePath: path,
            // 引入该组件的页面信息
            pageId
          });
          const instance = getCurrentInstance().proxy;
          self2.instance.set(moduleId, instance);
          for (const v of Object.values(module.props ?? {})) {
            if (v.cls) {
              provide("externalClass", true);
              break;
            }
          }
          const eventAttr = {};
          for (const attrName in attrs) {
            if (attrName.startsWith("bind") || attrName.startsWith("catch")) {
              eventAttr[attrName.replace(/^(?:bind:|bind|catch:|catch)/, "")] = attrs[attrName];
            }
          }
          watch(
            props,
            (newProps) => {
              message.send({
                type: "t",
                target: "service",
                body: {
                  bridgeId,
                  moduleId,
                  methodName: "tO",
                  // triggerObserver
                  event: deepToRaw(newProps)
                }
              });
            }
          );
          message.send({
            type: "mC",
            // createInstance
            target: "service",
            body: {
              bridgeId,
              moduleId,
              path: componentPath,
              pageId,
              parentId,
              eventAttr,
              targetInfo: {
                dataset: getDataAttributes$1(attrs, deepToRaw),
                id: attrs.id,
                class: attrs.class
              },
              properties: deepToRaw(props)
            }
          });
          onMounted(() => {
            nextTick(() => {
              message.send({
                type: "mR",
                target: "service",
                body: {
                  bridgeId,
                  moduleId
                }
              });
            });
            if (eventAttr.tap) {
              instance.$el.addEventListener("click", (event) => {
                triggerEvent("tap", {
                  event,
                  info: {
                    attrs,
                    bridgeId,
                    moduleId: pageId
                  }
                });
              });
            }
          });
          onUnmounted(() => {
            message.send({
              type: "mU",
              target: "service",
              body: {
                bridgeId,
                moduleId
              }
            });
            self2.instance.delete(moduleId);
          });
          const data = reactive({});
          const initData = await message.wait(moduleId);
          const entries = Object.entries(initData);
          for (let i = 0; i < entries.length; i++) {
            const [key, value] = entries[i];
            if (!(module.props && Object.prototype.hasOwnProperty.call(module.props, key))) {
              set(data, key, value);
            }
          }
          return data;
        },
        render: module.moduleInfo.render
      };
    }
    return components2;
  }
  updateModule(opts) {
    const { moduleId, data } = opts;
    const viewModule = this.instance.get(moduleId);
    if (viewModule) {
      for (const key in data) {
        viewModule.$nextTick(() => {
          if (!key.includes(".") && !key.includes("[") && !(key in viewModule)) {
            const refValue = ref(data[key]);
            Object.defineProperty(viewModule, key, {
              get() {
                return refValue.value;
              },
              set(newValue) {
                refValue.value = newValue;
              },
              enumerable: true,
              configurable: true
            });
          } else {
            set(viewModule, key, data[key]);
          }
        });
      }
    } else {
      console.warn(`[Render] module ${moduleId} is not exist.`);
    }
  }
  async waitForEl(instance, timeout = 500) {
    if (!instance) {
      return;
    }
    if (instance.__page__) {
      return document.body;
    }
    const el = instance.$el;
    if (el) {
      return el;
    }
    return new Promise((resolve2) => {
      var _a;
      const observer = new MutationObserver((_, obs) => {
        const el2 = instance.$el;
        if (el2) {
          obs.disconnect();
          resolve2(el2);
        }
      });
      if (((_a = instance.$parent.$el) == null ? void 0 : _a.nodeType) === Node.COMMENT_NODE) {
        observer.observe(document.body, { childList: true, subtree: true });
      } else {
        observer.observe(instance.$parent.$el, { childList: true });
      }
      setTimeout(() => {
        observer.disconnect();
        resolve2();
      }, timeout);
    });
  }
  async waitForElement(parent, selector, method, timeout = 500) {
    if (!parent[method]) {
      console.warn(`[Render] waitForElement method ${method} in ${parent.nodeType}`);
      return null;
    }
    const elements = parent[method](selector);
    if (elements) {
      return elements;
    }
    return new Promise((resolve2) => {
      const observer = new MutationObserver((_, obs) => {
        const elements2 = parent[method](selector);
        if (elements2) {
          obs.disconnect();
          resolve2(elements2);
        }
      });
      observer.observe(parent, { childList: true, subtree: true });
      setTimeout(() => {
        observer.disconnect();
        resolve2();
      }, timeout);
    });
  }
  selectorQuery(opts) {
    setTimeout(async () => {
      const { bridgeId, params: { tasks, success } } = opts;
      const results = await Promise.all(tasks.map(async (task) => {
        const { moduleId, selector, single, fields } = task;
        const el = await this.waitForEl(this.instance.get(moduleId));
        if (!el) {
          console.warn(`[Render] module ${moduleId} dom is not exist.`);
          return null;
        }
        if (!el.querySelector) {
          console.warn(`[Render] selectorQuery el node type is ${el.nodeType}`);
          return null;
        }
        const selectors = selector.split(",").map((s) => `${s.trim()}:not([data-dd-cloned] *)`).join(",");
        if (single) {
          const targetElement = el.querySelector(selectors);
          return targetElement ? this.parseElement(targetElement, fields) : null;
        } else {
          const targetElements = el.querySelectorAll(selectors);
          return Array.from(targetElements).map((el2) => this.parseElement(el2, fields));
        }
      }));
      const res = results.filter(Boolean);
      message.send({
        type: "triggerCallback",
        target: "service",
        body: {
          bridgeId,
          id: success,
          args: res
        }
      });
    }, 300);
  }
  parseElement(targetElement, fields) {
    const data = {};
    if (fields.dataset) {
      data.dataset = targetElement._ds;
    }
    if (fields.rect) {
      const { left, top, right, bottom, width, height } = targetElement.getBoundingClientRect();
      data.left = left;
      data.top = top;
      data.right = right;
      data.bottom = bottom;
      data.width = width;
      data.height = height;
    }
    data.id = targetElement.id ?? "";
    if (fields.scrollOffset) {
      data.scrollHeight = targetElement.scrollHeight;
      data.scrollLeft = targetElement.scrollLeft;
      data.scrollTop = targetElement.scrollTop;
      data.scrollWidth = targetElement.scrollWidth;
    }
    return data;
  }
  showToast({ params }) {
    window.__globalAPI.showToast(params);
  }
  hideToast({ params }) {
    window.__globalAPI.hideToast(params);
  }
  addIntersectionObserver(opts) {
    setTimeout(async () => {
      const { bridgeId, params: { targetSelector, relativeInfo, moduleId, options, success } } = opts;
      const el = await this.waitForEl(this.instance.get(moduleId));
      if (!el) {
        console.error("[Render] Failed to find element for intersection observer");
        return;
      }
      const observers = [];
      for (const info of relativeInfo) {
        const observerOptions = {
          root: null,
          threshold: options.thresholds,
          rootMargin: info.margins,
          initialRatio: options.initialRatio,
          observeAll: options.observeAll
        };
        if (info.selector === null) {
          observerOptions.root = null;
          observers.push({ options: observerOptions });
          continue;
        }
        const relativeEl = await this.waitForElement(el, info.selector, "querySelector");
        const targetEls2 = await this.waitForElement(el, targetSelector, options.observeAll ? "querySelectorAll" : "querySelector");
        if (!relativeEl || !targetEls2) {
          console.warn(`[Render] Failed to find elements`);
          continue;
        }
        const isAncestor = Array.isArray(targetEls2) ? Array.from(targetEls2).some((target) => relativeEl.contains(target)) : relativeEl.contains(targetEls2);
        if (isAncestor) {
          observerOptions.root = relativeEl;
        } else {
          const position = window.getComputedStyle(relativeEl).position;
          if (position === "fixed") {
            const computedStyle = window.getComputedStyle(relativeEl);
            const top = Number.parseFloat(computedStyle.top) || 0;
            const bottom = top + Number.parseFloat(computedStyle.height) || 0;
            const left = Number.parseFloat(computedStyle.left) || 0;
            const right = left + Number.parseFloat(computedStyle.width) || 0;
            observerOptions.root = null;
            observerOptions.type = "fixed";
            observerOptions.rootMargin = `${-top}px ${-(window.innerWidth - right)}px ${-(window.innerHeight - bottom)}px ${-left}px`;
          } else {
            continue;
          }
        }
        observers.push({ options: observerOptions });
      }
      const targetEls = await this.waitForElement(el, targetSelector, options.observeAll ? "querySelectorAll" : "querySelector");
      if (!targetEls) {
        console.error("[Render] Failed to find target element for intersection observer");
        return;
      }
      const allObservers = observers.map(({ options: options2 }) => {
        let initRatio = options2.initialRatio;
        const observer = new IntersectionObserver((entries) => {
          entries.forEach((entry) => {
            if (entry.intersectionRatio === initRatio)
              return;
            initRatio = entry.intersectionRatio;
            const { top, bottom } = entry.boundingClientRect;
            const viewportHeight = window.innerHeight;
            if (!options2.type && !entry.isIntersecting && top >= 0 && bottom <= viewportHeight) {
              return;
            }
            message.send({
              type: "triggerCallback",
              target: "service",
              body: {
                bridgeId,
                id: success,
                args: {
                  info: {
                    boundingClientRect: entry.boundingClientRect,
                    // 目标边界
                    intersectionRatio: entry.intersectionRatio,
                    // 相交比例
                    intersectionRect: entry.intersectionRect,
                    // 相交区域的边界
                    relativeRect: entry.rootBounds,
                    // 相对参考区域
                    time: entry.time
                  }
                }
              }
            });
          });
        }, options2);
        if (options2.observeAll) {
          Array.from(targetEls).forEach((target) => observer.observe(target));
        } else {
          observer.observe(targetEls);
        }
        return observer;
      });
      const observerId = uuid();
      this.intersectionObservers.set(observerId, allObservers);
      message.send({
        type: "triggerCallback",
        target: "service",
        body: {
          bridgeId,
          id: success,
          args: { observerId }
        }
      });
    }, 300);
  }
  removeIntersectionObserver({ params: { observerId } }) {
    if (observerId) {
      const observers = this.intersectionObservers.get(observerId);
      if (observers) {
        observers.forEach((observer) => observer.disconnect());
        this.intersectionObservers.delete(observerId);
      }
    }
  }
  addPerformanceObserver() {
  }
}
const runtime = new Runtime();
class Render {
  constructor() {
    console.log("[Render] init");
    this.env = env;
    this.message = message;
    window.__message = message;
    window.__callback = callback;
    this.init();
  }
  init() {
    this.message.on("loadResource", (msg) => {
      const { bridgeId, appId, pagePath, root = "." } = msg;
      loader.loadResource({ bridgeId, appId, pagePath, root });
    });
    this.message.on("firstRender", (msg) => {
      const { bridgeId, pageId, pagePath, initialProps, query } = msg;
      loader.setInitialData(initialProps);
      runtime.firstRender({
        pagePath,
        pageId,
        bridgeId,
        query
      });
    });
    this.message.on("u", (msg) => {
      queueMicrotask(() => {
        runtime.updateModule(msg);
      });
    });
    this.message.on("invokeAPI", (msg) => {
      runtime[msg.name](msg);
    });
    this.message.on("triggerCallback", (msg) => {
      const { success, data } = msg;
      success && callback.invoke(success, data);
    });
  }
}
new Render();
window.modDefine = modDefine;
window.modRequire = modRequire;
__vitePreload(async () => {
  const { default: VConsole } = await import("./vconsole.min.js").then((n) => n.v);
  return { default: VConsole };
}, true ? [] : void 0).then(({ default: VConsole }) => new VConsole().setSwitchPosition(10, 140));
