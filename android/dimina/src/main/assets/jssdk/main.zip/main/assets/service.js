var service = function() {
  "use strict";var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);

  var _stacks, _initId, _instance, _instance2, _Page_instances, init_fn, initMembers_fn, invokeInitLifecycle_fn, _Component_instances, init_fn2, initLifecycle_fn, initCustomMethods_fn, invokeInitLifecycle_fn2;
  const isObject = (value) => {
    const type = typeof value;
    return value !== null && (type === "object" || type === "function");
  };
  const disallowedKeys = /* @__PURE__ */ new Set([
    "__proto__",
    "prototype",
    "constructor"
  ]);
  const digits = new Set("0123456789");
  function getPathSegments(path) {
    const parts = [];
    let currentSegment = "";
    let currentPart = "start";
    let isIgnoring = false;
    for (const character of path) {
      switch (character) {
        case "\\": {
          if (currentPart === "index") {
            throw new Error("Invalid character in an index");
          }
          if (currentPart === "indexEnd") {
            throw new Error("Invalid character after an index");
          }
          if (isIgnoring) {
            currentSegment += character;
          }
          currentPart = "property";
          isIgnoring = !isIgnoring;
          break;
        }
        case ".": {
          if (currentPart === "index") {
            throw new Error("Invalid character in an index");
          }
          if (currentPart === "indexEnd") {
            currentPart = "property";
            break;
          }
          if (isIgnoring) {
            isIgnoring = false;
            currentSegment += character;
            break;
          }
          if (disallowedKeys.has(currentSegment)) {
            return [];
          }
          parts.push(currentSegment);
          currentSegment = "";
          currentPart = "property";
          break;
        }
        case "[": {
          if (currentPart === "index") {
            throw new Error("Invalid character in an index");
          }
          if (currentPart === "indexEnd") {
            currentPart = "index";
            break;
          }
          if (isIgnoring) {
            isIgnoring = false;
            currentSegment += character;
            break;
          }
          if (currentPart === "property") {
            if (disallowedKeys.has(currentSegment)) {
              return [];
            }
            parts.push(currentSegment);
            currentSegment = "";
          }
          currentPart = "index";
          break;
        }
        case "]": {
          if (currentPart === "index") {
            parts.push(Number.parseInt(currentSegment, 10));
            currentSegment = "";
            currentPart = "indexEnd";
            break;
          }
          if (currentPart === "indexEnd") {
            throw new Error("Invalid character after an index");
          }
        }
        default: {
          if (currentPart === "index" && !digits.has(character)) {
            throw new Error("Invalid character in an index");
          }
          if (currentPart === "indexEnd") {
            throw new Error("Invalid character after an index");
          }
          if (currentPart === "start") {
            currentPart = "property";
          }
          if (isIgnoring) {
            isIgnoring = false;
            currentSegment += "\\";
          }
          currentSegment += character;
        }
      }
    }
    if (isIgnoring) {
      currentSegment += "\\";
    }
    switch (currentPart) {
      case "property": {
        if (disallowedKeys.has(currentSegment)) {
          return [];
        }
        parts.push(currentSegment);
        break;
      }
      case "index": {
        throw new Error("Index was not closed");
      }
      case "start": {
        parts.push("");
        break;
      }
    }
    return parts;
  }
  function isStringIndex(object, key) {
    if (typeof key !== "number" && Array.isArray(object)) {
      const index2 = Number.parseInt(key, 10);
      return Number.isInteger(index2) && object[index2] === object[key];
    }
    return false;
  }
  function assertNotStringIndex(object, key) {
    if (isStringIndex(object, key)) {
      throw new Error("Cannot use string index");
    }
  }
  function getProperty(object, path, value) {
    if (!isObject(object) || typeof path !== "string") {
      return value === void 0 ? object : value;
    }
    const pathArray = getPathSegments(path);
    if (pathArray.length === 0) {
      return value;
    }
    for (let index2 = 0; index2 < pathArray.length; index2++) {
      const key = pathArray[index2];
      if (isStringIndex(object, key)) {
        object = index2 === pathArray.length - 1 ? void 0 : null;
      } else {
        object = object[key];
      }
      if (object === void 0 || object === null) {
        if (index2 !== pathArray.length - 1) {
          return value;
        }
        break;
      }
    }
    return object === void 0 ? value : object;
  }
  function setProperty(object, path, value) {
    if (!isObject(object) || typeof path !== "string") {
      return object;
    }
    const root = object;
    const pathArray = getPathSegments(path);
    for (let index2 = 0; index2 < pathArray.length; index2++) {
      const key = pathArray[index2];
      assertNotStringIndex(object, key);
      if (index2 === pathArray.length - 1) {
        object[key] = value;
      } else if (!isObject(object[key])) {
        object[key] = typeof pathArray[index2 + 1] === "number" ? [] : {};
      }
      object = object[key];
    }
    return root;
  }
  function isFunction(value) {
    return typeof value === "function";
  }
  function isNumber(value) {
    return typeof value === "number" && Number.isFinite(value) && !Number.isNaN(value);
  }
  function isString(value) {
    return typeof value === "string";
  }
  function isNil(value) {
    return value === null || value === void 0;
  }
  function get(data, path) {
    return getProperty(data, path);
  }
  function set(data, path, value) {
    setProperty(data, path, value);
  }
  function uuid() {
    return Math.random().toString(36).slice(2, 7);
  }
  const isWebWorker = (() => {
    if (typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope) {
      return true;
    } else {
      return false;
    }
  })();
  function resolvePath(basePath, relativePath) {
    if (relativePath.startsWith("/")) {
      return relativePath.slice(1);
    }
    const currParts = basePath.split("/");
    const relativeParts = relativePath.split("/");
    for (const element of relativeParts) {
      const part = element;
      if (part === "..") {
        if (currParts.length > 0) {
          currParts.pop();
        }
      } else if (part !== "." && part !== "") {
        currParts.push(part);
      }
    }
    return currParts.join("/");
  }
  function parsePath(currPath, url) {
    const basePath = currPath.split("/").slice(0, -1).join("/");
    const parts = url.split("?");
    const pagePath = parts[0];
    const paramStr = parts[1];
    let newUrl = resolvePath(basePath, pagePath);
    if (paramStr) {
      newUrl += `?${paramStr}`;
    }
    return newUrl;
  }
  function cloneDeep(value) {
    if (value === null || typeof value !== "object") {
      return value;
    }
    const seen = /* @__PURE__ */ new WeakMap();
    function clone(item) {
      if (item === null || typeof item !== "object") {
        return item;
      }
      if (item instanceof Date) {
        return new Date(item);
      }
      if (item instanceof RegExp) {
        return new RegExp(item.source, item.flags);
      }
      if (Array.isArray(item)) {
        if (seen.has(item)) {
          return seen.get(item);
        }
        const arr = [];
        seen.set(item, arr);
        arr.push(...item.map(clone));
        return arr;
      }
      if (seen.has(item)) {
        return seen.get(item);
      }
      const obj = Object.create(Object.getPrototypeOf(item));
      seen.set(item, obj);
      return Object.assign(obj, ...Object.keys(item).map((key) => ({
        [key]: clone(item[key])
      })));
    }
    return clone(value);
  }
  const JSModules = {};
  const MODULES_STATUS_UNLOAD = 1;
  const MODULES_STATUS_LOADED = 2;
  function modDefine(id, factory) {
    if (!JSModules[id]) {
      JSModules[id] = {
        factory,
        status: MODULES_STATUS_UNLOAD,
        exports: void 0
      };
    }
  }
  const modRequire = function(id, callback2, errorCallback) {
    if (typeof id !== "string") {
      throw new TypeError("require args must be a string");
    }
    const mod = JSModules[id];
    if (!mod) {
      throw new Error(`module ${id} not found`);
    }
    if (mod.status === MODULES_STATUS_UNLOAD) {
      mod.status = MODULES_STATUS_LOADED;
      const module = {
        exports: {}
      };
      let res;
      try {
        if (mod.factory) {
          res = mod.factory.call(null, modRequire, module, module.exports);
        }
      } catch (e) {
        mod.status = MODULES_STATUS_UNLOAD;
        const em = `
				name: ${e.name}
				msg: ${e.message}
				stack:
				${e.stack}
			`;
        console.error(`require ${id} error: ${em}`);
        if (isFunction(errorCallback)) {
          errorCallback({ mod: id, errMsg: e.message });
        }
      }
      mod.exports = module.exports === void 0 ? res : module.exports;
    }
    if (isFunction(callback2)) {
      callback2(mod.exports);
    }
    return mod.exports;
  };
  modRequire.async = async (id) => {
    return new Promise((resolve, reject) => {
      try {
        resolve(modRequire(id));
      } catch (e) {
        reject(new Error(`${e.message}: Failed to initialize asynchronous loading for module '${id}'`));
      }
    });
  };
  class Callback {
    constructor() {
      this.callbacks = {};
    }
    store(callback2, keep) {
      if (keep) {
        for (const [k, v] of Object.entries(this.callbacks)) {
          if (v.callback === callback2) {
            return k;
          }
        }
      }
      const id = uuid();
      this.callbacks[id] = { callback: callback2, keep };
      return id;
    }
    /**
     * [Container] triggerCallback -> [Service] invoke
     * @param {*} id
     * @param {*} args
     */
    invoke(id, args) {
      if (id === void 0) {
        return;
      }
      const obj = this.callbacks[id];
      if (obj && isFunction(obj.callback)) {
        obj.callback(args);
        if (!obj.keep) {
          delete this.callbacks[id];
        }
      }
    }
    remove(id) {
      if (id) {
        Object.keys(this.callbacks).forEach((k) => {
          if (id === k) {
            delete this.callbacks[k];
          }
        });
      } else {
        Object.entries(this.callbacks).forEach(([k, v]) => {
          if (v.keep) {
            delete this.callbacks[k];
          }
        });
      }
    }
  }
  const callback = new Callback();
  class Router {
    constructor() {
      __privateAdd(this, _stacks, []);
      __privateAdd(this, _initId, "");
    }
    setInitId(id) {
      __privateSet(this, _initId, id);
    }
    push(pageInfo, stackId) {
      const { id, query, path } = pageInfo;
      this.stack(stackId).push({
        id,
        query,
        route: path
      });
    }
    pop() {
      if (this.stack().length > 0) {
        this.stack().pop();
      }
    }
    getPageInfo() {
      return this.stack().at(-1) || { id: __privateGet(this, _initId) };
    }
    /**
     * 推入一个新页面栈
     */
    pushStack(stackId) {
      const newStack = {
        id: stackId,
        pages: []
      };
      __privateGet(this, _stacks).push(newStack);
      return newStack;
    }
    /**
     * 当前新页面栈退出
     */
    popStack(stackId) {
      if (stackId) {
        const index2 = __privateGet(this, _stacks).findIndex((stack) => stack.id === stackId);
        if (index2 !== -1) {
          __privateGet(this, _stacks).splice(index2, 1);
        }
      } else if (__privateGet(this, _stacks).length > 0) {
        __privateGet(this, _stacks).pop();
      }
    }
    /**
     * 获取当前页面栈
     */
    stack(stackId) {
      if (stackId) {
        let currentStack = __privateGet(this, _stacks).find((stack) => stack.id === stackId);
        if (!currentStack) {
          currentStack = this.pushStack(stackId);
        }
        return currentStack.pages;
      } else {
        const currentStack = __privateGet(this, _stacks).at(-1);
        if (currentStack) {
          return currentStack.pages;
        } else {
          return this.pushStack(Date.now()).pages;
        }
      }
    }
  }
  _stacks = new WeakMap();
  _initId = new WeakMap();
  const router = new Router();
  function mitt(n) {
    return { all: n = n || /* @__PURE__ */ new Map(), on: function(t, e) {
      var i = n.get(t);
      i ? i.push(e) : n.set(t, [e]);
    }, off: function(t, e) {
      var i = n.get(t);
      i && (e ? i.splice(i.indexOf(e) >>> 0, 1) : n.set(t, []));
    }, emit: function(t, e) {
      var i = n.get(t);
      i && i.slice().map(function(n2) {
        n2(e);
      }), (i = n.get("*")) && i.slice().map(function(n2) {
        n2(t, e);
      });
    } };
  }
  class Message {
    constructor() {
      this.event = mitt();
      this.init();
    }
    init() {
      if (isWebWorker) {
        globalThis.onmessage = (e) => {
          this.handleMsg(e.data);
        };
      } else {
        DiminaServiceBridge.onMessage = this.handleMsg.bind(this);
      }
    }
    handleMsg(msg) {
      console.log("[Service] receive msg: ", isWebWorker ? msg : JSON.stringify(msg));
      const { type, body } = msg;
      this.event.emit(type, body);
    }
    // 向逻辑层注册消息监听
    on(type, callback2) {
      this.event.on(type, callback2);
    }
    off(type) {
      this.event.off(type);
    }
    // 逻辑层透过容器层发送消息
    send(msg) {
      if (isWebWorker) {
        Message.prototype.send = function(msg2) {
          msg2.method = "publish";
          globalThis.postMessage(msg2);
        };
      } else {
        Message.prototype.send = function(msg2) {
          return DiminaServiceBridge.publish(msg2.body.bridgeId || "", msg2);
        };
      }
      return this.send(msg);
    }
    // 逻辑层向容器层发送消息
    invoke(msg) {
      if (isWebWorker) {
        Message.prototype.invoke = function(msg2) {
          msg2.method = "invoke";
          globalThis.postMessage(msg2);
        };
      } else {
        Message.prototype.invoke = function(msg2) {
          return DiminaServiceBridge.invoke(msg2);
        };
      }
      return this.invoke(msg);
    }
  }
  const message = new Message();
  function invokeAPI(name, data, target = "container") {
    let params;
    if (data === void 0 || typeof data === "string" || Array.isArray(data)) {
      params = data;
    } else {
      if (isFunction(data)) {
        params = {
          success: callback.store(data, true)
        };
      } else {
        const { success, fail, complete, ...rest } = data;
        params = rest;
        if (isFunction(success)) {
          params.success = callback.store(success);
        } else {
          params.success = success;
        }
        if (isFunction(fail)) {
          params.fail = callback.store(fail);
        }
        if (isFunction(complete)) {
          params.complete = callback.store(complete);
        }
      }
    }
    const msg = {
      type: "invokeAPI",
      target,
      body: {
        name,
        bridgeId: router.getPageInfo().id,
        params
      }
    };
    if (target === "container") {
      return message.invoke(msg);
    } else {
      return message.send(msg);
    }
  }
  function onError(opts) {
    invokeAPI("onError", opts);
  }
  function offError(opts) {
    invokeAPI("offError", opts);
  }
  function onAppShow(opts) {
    invokeAPI("onAppShow", opts);
  }
  function onAppHide(opts) {
    invokeAPI("onAppHide", opts);
  }
  function offAppShow(opts) {
    invokeAPI("offAppShow", opts);
  }
  function offAppHide(opts) {
    invokeAPI("offAppHide", opts);
  }
  function onUnhandledRejection() {
  }
  function onPageNotFound() {
  }
  function onAppRoute() {
  }
  const __vite_glob_0_0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    offAppHide,
    offAppShow,
    offError,
    onAppHide,
    onAppRoute,
    onAppShow,
    onError,
    onPageNotFound,
    onUnhandledRejection
  }, Symbol.toStringTag, { value: "Module" }));
  function env$1() {
    return {
      USER_DATA_PATH: "difile://"
    };
  }
  function canIUse(opts) {
    if (opts === "getUpdateManager" || opts === "getPerformance") {
      return true;
    }
    return invokeAPI("canIUse", opts);
  }
  const __vite_glob_0_1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    canIUse,
    env: env$1
  }, Symbol.toStringTag, { value: "Module" }));
  function getPerformance() {
    return Performance.getInstance();
  }
  const _Performance = class _Performance {
    // 私有构造函数，防止外部直接实例化
    constructor() {
      if (__privateGet(_Performance, _instance)) {
        throw new Error(
          "Cannot instantiate more than one Performance instance."
        );
      }
      this.entryList = new EntryList();
      __privateSet(_Performance, _instance, this);
    }
    // 静态方法，用于获取单例实例
    static getInstance() {
      if (!__privateGet(_Performance, _instance)) {
        __privateSet(_Performance, _instance, new _Performance());
      }
      return __privateGet(_Performance, _instance);
    }
    createObserver(listener) {
      const observer = new Observer(listener);
      if (listener) {
        const id = callback.store((res) => {
          var _a, _b;
          const list = ((_a = res == null ? void 0 : res.data) == null ? void 0 : _a.entryList) && JSON.parse((_b = res == null ? void 0 : res.data) == null ? void 0 : _b.entryList) || [];
          if (list) {
            this.entryList.push(list);
            observer.notify(list);
          }
        }, true);
        invokeAPI("addPerformanceObserver", {
          success: id
        }, "render");
      }
      return observer;
    }
    getEntries() {
      return this.entryList.getEntries();
    }
    getEntriesByName(name, entryType) {
      return this.entryList.getEntriesByName(name, entryType);
    }
    getEntriesByType(entryType) {
      return this.entryList.getEntriesByType(entryType);
    }
    setBufferSize(size) {
      this.entryList.maxEntrySize = size;
    }
  };
  _instance = new WeakMap();
  __privateAdd(_Performance, _instance, null);
  let Performance = _Performance;
  class EntryList {
    constructor() {
      this._list = [];
      this.maxEntrySize = 30;
    }
    push(entries) {
      for (const entry of entries) {
        if (this._list.length >= this.maxEntrySize) {
          this._list.shift();
        }
        this._list.push(entry);
      }
    }
    getEntriesByName(name, entryType) {
      return this._entryFilter(name, entryType);
    }
    getEntriesByType(entryType) {
      return this._entryFilter(null, entryType);
    }
    _entryFilter(name, entryType) {
      return this._list.filter((entry) => {
        if (name && name !== entry.name) {
          return false;
        }
        if (entryType && entryType !== entry.entryType) {
          return false;
        }
        return true;
      });
    }
    getEntries() {
      return this._list;
    }
  }
  class Observer {
    constructor(callback2) {
      this.entryTypes = [];
      this.callback = callback2;
    }
    observe(options) {
      this.connected = true;
      this.entryTypes = options.entryTypes;
    }
    notify(data) {
      if (this.connected) {
        const entryList = new EntryList();
        entryList.push(data.filter((entry) => {
          let flag = false;
          if (this.entryTypes && this.entryTypes.length > 0) {
            this.entryTypes.forEach((value) => {
              if (entry.entryType === value) {
                flag = true;
              }
            });
          }
          return flag;
        }));
        this.callback(entryList);
      }
    }
    disconnect() {
      this.connected = false;
    }
  }
  const __vite_glob_0_2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getPerformance
  }, Symbol.toStringTag, { value: "Module" }));
  function preDownloadSubpackage(opts) {
    invokeAPI("preDownloadSubpackage", opts);
  }
  function loadSubpackage(opts) {
    invokeAPI("loadSubpackage", opts);
  }
  const __vite_glob_0_3 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    loadSubpackage,
    preDownloadSubpackage
  }, Symbol.toStringTag, { value: "Module" }));
  function openSystemBluetoothSetting(opts) {
    invokeAPI("openSystemBluetoothSetting", opts);
  }
  function getWindowInfo(opts) {
    return invokeAPI("getWindowInfo", opts);
  }
  function openAppAuthorizeSetting(opts) {
    invokeAPI("openAppAuthorizeSetting", opts);
  }
  function getSystemInfo(opts) {
    return new Promise((resolve) => {
      resolve(invokeAPI("getSystemInfo", opts));
    });
  }
  function getSystemInfoSync() {
    return invokeAPI("getSystemInfoSync");
  }
  function getSystemInfoAsync(opts) {
    invokeAPI("getSystemInfoAsync", opts);
  }
  const __vite_glob_0_4 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getSystemInfo,
    getSystemInfoAsync,
    getSystemInfoSync,
    getWindowInfo,
    openAppAuthorizeSetting,
    openSystemBluetoothSetting
  }, Symbol.toStringTag, { value: "Module" }));
  function getUpdateManager() {
    return UpdateManager.getInstance();
  }
  const _UpdateManager = class _UpdateManager {
    // 私有构造函数，防止外部直接实例化
    constructor() {
      if (__privateGet(_UpdateManager, _instance2)) {
        throw new Error(
          "Cannot instantiate more than one UpdateManager instance."
        );
      }
      this.hasApplyUpdate = false;
      this.updateFailFlag = null;
      this.updateFailCbQueue = [];
      this.updateReadyCbQueue = [];
      this.updateReadyStatus = null;
      this.updateReadyFlag = false;
      this.updateStatus = null;
      this.updateStatusCbQueue = [];
      message.on("onUpdateStatusChange", (msg) => {
        const { event, strategy } = msg;
        if (event === "updatefail") {
          this.updateFailFlag = {};
          this.flashUpdateFailCb();
        } else if (event === "updateready") {
          this.updateReadyFlag = true;
          this.updateReadyStatus = { strategy };
          this.flushUpdateReadyCb();
        } else if (event === "noupdate") {
          this.updateStatus = {
            hasUpdate: true
          };
          this.flushUpdateStatusCb();
        } else if (event === "updating") {
          this.updateStatus = {
            hasUpdate: false
          };
          this.flushUpdateStatusCb();
        }
      });
      __privateSet(_UpdateManager, _instance2, this);
    }
    flashUpdateFailCb() {
      this.updateFailCbQueue.forEach((cb) => {
        typeof cb === "function" && cb();
      });
      this.updateFailCbQueue.length = 0;
    }
    flushUpdateStatusCb() {
      this.updateStatusCbQueue.forEach((cb) => {
        typeof cb === "function" && cb(this.updateStatus);
      });
      this.updateStatusCbQueue.length = 0;
    }
    flushUpdateReadyCb() {
      this.updateReadyCbQueue.forEach((cb) => {
        typeof cb === "function" && cb(this.updateReadyStatus);
      });
      this.updateReadyCbQueue.length = 0;
    }
    // 静态方法，用于获取单例实例
    static getInstance() {
      if (!__privateGet(_UpdateManager, _instance2)) {
        __privateSet(_UpdateManager, _instance2, new _UpdateManager());
      }
      return __privateGet(_UpdateManager, _instance2);
    }
    /**
     * 强制小程序重启并使用新版本。在小程序新版本下载完成后（即收到 onUpdateReady 回调）调用。
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.applyUpdate.html
     */
    applyUpdate() {
      if (this.updateReadyFlag && this.hasApplyUpdate) {
        console.error("[applyUpdate]: applyUpdate has been called");
      } else if (!this.updateReadyFlag) {
        console.error("[applyUpdate]: update is not ready");
      } else {
        invokeAPI("applyUpdate");
      }
    }
    /**
     * 监听向微信后台请求检查更新结果事件。微信在小程序每次启动（包括热启动）时自动检查更新，不需由开发者主动触发。
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onCheckForUpdate.html
     */
    onCheckForUpdate(cb) {
      this.updateStatus ? typeof cb === "function" && cb(this.updateStatus) : this.updateStatusCbQueue.push(cb);
    }
    /**
     * 监听小程序更新失败事件。小程序有新版本，客户端主动触发下载（无需开发者触发），下载失败（可能是网络原因等）后回调
     * https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateFailed.html
     */
    onUpdateFailed(cb) {
      this.updateFailFlag ? typeof cb === "function" && cb(this.updateFailFlag) : this.updateFailCbQueue.push(cb);
    }
    /**
     * 监听小程序有版本更新事件。客户端主动触发下载（无需开发者触发），下载成功后回调
     *	https://developers.weixin.qq.com/miniprogram/dev/api/base/update/UpdateManager.onUpdateReady.html
     */
    onUpdateReady(cb) {
      this.updateReadyFlag ? typeof cb === "function" && cb(this.updateReadyStatus) : this.updateReadyCbQueue.push(cb);
    }
  };
  _instance2 = new WeakMap();
  // 私有静态变量，用于存储单例实例
  __privateAdd(_UpdateManager, _instance2, null);
  let UpdateManager = _UpdateManager;
  const __vite_glob_0_5 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getUpdateManager
  }, Symbol.toStringTag, { value: "Module" }));
  function createCameraContext() {
    return new CameraContext();
  }
  class CameraContext {
    constructor() {
      this.bridgeId = router.getPageInfo().id;
    }
    takePhoto(data) {
      invokeAPI("takePhoto", data);
    }
    startRecord() {
      invokeAPI("startRecord");
    }
    stopRecord() {
      invokeAPI("startRecord");
    }
  }
  const __vite_glob_0_6 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createCameraContext
  }, Symbol.toStringTag, { value: "Module" }));
  function reportAnalytics(...opts) {
    invokeAPI("reportAnalytics", opts);
  }
  function reportEvent(eventId, data) {
    invokeAPI("reportAnalytics", { eventId, data });
  }
  const __vite_glob_0_7 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    reportAnalytics,
    reportEvent
  }, Symbol.toStringTag, { value: "Module" }));
  function writeBLECharacteristicValue(opts) {
    invokeAPI("writeBLECharacteristicValue", opts);
  }
  function setBLEMTU(opts) {
    invokeAPI("setBLEMTU", opts);
  }
  function readBLECharacteristicValue(opts) {
    invokeAPI("readBLECharacteristicValue", opts);
  }
  function onBLEConnectionStateChange(opts) {
    invokeAPI("onBLEConnectionStateChange", opts);
  }
  function onBLECharacteristicValueChange(opts) {
    invokeAPI("onBLECharacteristicValueChange", opts);
  }
  function offBLEConnectionStateChange(opts) {
    invokeAPI("offBLEConnectionStateChange", opts);
  }
  function offBLECharacteristicValueChange() {
    invokeAPI("offBLECharacteristicValueChange");
  }
  function notifyBLECharacteristicValueChange(opts) {
    invokeAPI("notifyBLECharacteristicValueChange", opts);
  }
  function getBLEDeviceServices(opts) {
    invokeAPI("getBLEDeviceServices", opts);
  }
  function getBLEDeviceRSSI(opts) {
    invokeAPI("getBLEDeviceRSSI", opts);
  }
  function getBLEDeviceCharacteristics(opts) {
    invokeAPI("getBLEDeviceCharacteristics", opts);
  }
  function createBLEConnection(opts) {
    invokeAPI("createBLEConnection", opts);
  }
  function closeBLEConnection(opts) {
    invokeAPI("closeBLEConnection", opts);
  }
  const __vite_glob_0_8 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    closeBLEConnection,
    createBLEConnection,
    getBLEDeviceCharacteristics,
    getBLEDeviceRSSI,
    getBLEDeviceServices,
    notifyBLECharacteristicValueChange,
    offBLECharacteristicValueChange,
    offBLEConnectionStateChange,
    onBLECharacteristicValueChange,
    onBLEConnectionStateChange,
    readBLECharacteristicValue,
    setBLEMTU,
    writeBLECharacteristicValue
  }, Symbol.toStringTag, { value: "Module" }));
  function stopBluetoothDevicesDiscovery(opts) {
    invokeAPI("stopBluetoothDevicesDiscovery", opts);
  }
  function startBluetoothDevicesDiscovery(opts) {
    invokeAPI("startBluetoothDevicesDiscovery", opts);
  }
  function openBluetoothAdapter(opts) {
    invokeAPI("openBluetoothAdapter", opts);
  }
  function onBluetoothDeviceFound(opts) {
    invokeAPI("onBluetoothDeviceFound", opts);
  }
  function onBluetoothAdapterStateChange(opts) {
    invokeAPI("onBluetoothAdapterStateChange", opts);
  }
  function offBluetoothDeviceFound() {
    invokeAPI("offBluetoothDeviceFound");
  }
  function offBluetoothAdapterStateChange() {
    invokeAPI("offBluetoothAdapterStateChange");
  }
  function getConnectedBluetoothDevices(opts) {
    invokeAPI("getConnectedBluetoothDevices", opts);
  }
  function getBluetoothDevices(opts) {
    invokeAPI("getBluetoothDevices", opts);
  }
  function getBluetoothAdapterState(opts) {
    invokeAPI("getBluetoothAdapterState", opts);
  }
  function closeBluetoothAdapter(opts) {
    invokeAPI("closeBluetoothAdapter", opts);
  }
  const __vite_glob_0_9 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    closeBluetoothAdapter,
    getBluetoothAdapterState,
    getBluetoothDevices,
    getConnectedBluetoothDevices,
    offBluetoothAdapterStateChange,
    offBluetoothDeviceFound,
    onBluetoothAdapterStateChange,
    onBluetoothDeviceFound,
    openBluetoothAdapter,
    startBluetoothDevicesDiscovery,
    stopBluetoothDevicesDiscovery
  }, Symbol.toStringTag, { value: "Module" }));
  function setClipboardData(opts) {
    invokeAPI("setClipboardData", opts);
  }
  function getClipboardData(opts) {
    invokeAPI("getClipboardData", opts);
  }
  const __vite_glob_0_10 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getClipboardData,
    setClipboardData
  }, Symbol.toStringTag, { value: "Module" }));
  function chooseContact(opts) {
    invokeAPI("chooseContact", opts);
  }
  function addPhoneContact(opts) {
    invokeAPI("addPhoneContact", opts);
  }
  const __vite_glob_0_11 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    addPhoneContact,
    chooseContact
  }, Symbol.toStringTag, { value: "Module" }));
  function hideKeyboard(opts) {
    invokeAPI("hideKeyboard", opts);
  }
  const __vite_glob_0_12 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideKeyboard
  }, Symbol.toStringTag, { value: "Module" }));
  function onMemoryWarning(opts) {
    invokeAPI("onMemoryWarning", opts);
  }
  function offMemoryWarning(opts) {
    invokeAPI("offMemoryWarning", opts);
  }
  const __vite_glob_0_13 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    offMemoryWarning,
    onMemoryWarning
  }, Symbol.toStringTag, { value: "Module" }));
  function getNetworkType(opts) {
    invokeAPI("getNetworkType", opts);
  }
  const __vite_glob_0_14 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getNetworkType
  }, Symbol.toStringTag, { value: "Module" }));
  function makePhoneCall(opts) {
    invokeAPI("makePhoneCall", opts);
  }
  const __vite_glob_0_15 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    makePhoneCall
  }, Symbol.toStringTag, { value: "Module" }));
  function scanCode(opts) {
    invokeAPI("scanCode", opts);
  }
  const __vite_glob_0_16 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    scanCode
  }, Symbol.toStringTag, { value: "Module" }));
  function vibrateShort(opts) {
    invokeAPI("vibrateShort", opts);
  }
  function vibrateLong(opts) {
    invokeAPI("vibrateLong", opts);
  }
  const __vite_glob_0_17 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    vibrateLong,
    vibrateShort
  }, Symbol.toStringTag, { value: "Module" }));
  function extBridge({ event, module, data = {}, success, fail, complete }, extraCallback) {
    let overrideSuccess;
    let overrideFail;
    let overrideComplete;
    if (isFunction(extraCallback)) {
      overrideSuccess = extraCallback;
      overrideFail = extraCallback;
    } else {
      overrideSuccess = success;
      overrideFail = fail;
      overrideComplete = complete;
    }
    invokeAPI(event, {
      module,
      data,
      success: overrideSuccess,
      fail: overrideFail,
      complete: overrideComplete
    });
  }
  function extOnBridge({ event, module, callBack }) {
    if (!module || module === "DMServiceBridgeModule") {
      console.error(`[ERROR]: extOnBridge 参数 module ${module ? `值${module}不合法` : "为空"}`);
      return;
    }
    if (!event) {
      console.error("[ERROR]: extOnBridge 参数 event 为空");
      return;
    }
    if (!callBack) {
      console.error("[ERROR]: extOnBridge 参数 callBack 为空");
      return;
    }
    const eventName = `${module}_${event}`;
    invokeAPI(eventName, {
      success: callBack
    });
  }
  function extOffBridge({ event, module, callBack }) {
    if (!module || module === "DMServiceBridgeModule") {
      console.error(`[ERROR]: extOffBridge 参数 module ${module ? `值${module}不合法` : "为空"}`);
      return;
    }
    if (!event) {
      console.error("[ERROR]: extOffBridge 参数 event 为空");
      return;
    }
    const eventName = `${module}_${event}`;
    invokeAPI(eventName, {
      success: callBack
    });
  }
  function onLoginStatusChanged(callback2) {
    message.on("notifyLoginStatusChanged", (msg) => {
      callback2 == null ? void 0 : callback2(msg);
    });
  }
  function offLoginStatusChanged() {
    message.off("notifyLoginStatusChanged");
  }
  const __vite_glob_0_18 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    extBridge,
    extOffBridge,
    extOnBridge,
    offLoginStatusChanged,
    onLoginStatusChanged
  }, Symbol.toStringTag, { value: "Module" }));
  const lifecycleMethods = ["onLaunch", "onShow", "onHide"];
  class App {
    constructor(appModule, options) {
      this.appModule = appModule;
      this.options = options;
      this.init();
    }
    init() {
      this.initLifecycle();
      this.initCustomMethods();
      this.invokeSomeLifecycle();
    }
    initLifecycle() {
      lifecycleMethods.forEach((method) => {
        const lifecycleMethod = this.appModule.moduleInfo[method];
        if (!isFunction(lifecycleMethod)) {
          return;
        }
        this[method] = lifecycleMethod.bind(this);
      });
    }
    // 开发者自定义函数
    initCustomMethods() {
      const moduleInfo = this.appModule.moduleInfo;
      for (const attr in moduleInfo) {
        if (!lifecycleMethods.includes(attr) && isFunction(moduleInfo[attr])) {
          this[attr] = moduleInfo[attr].bind(this);
        }
      }
    }
    invokeSomeLifecycle() {
      var _a, _b;
      (_a = this.onLaunch) == null ? void 0 : _a.call(this, this.options);
      (_b = this.onShow) == null ? void 0 : _b.call(this, this.options);
    }
    appShow() {
      var _a;
      (_a = this.onShow) == null ? void 0 : _a.call(this, this.options);
    }
    appHide() {
      var _a;
      (_a = this.onHide) == null ? void 0 : _a.call(this);
    }
  }
  function addComputedData(self) {
    var _a, _b;
    if ((_b = (_a = self.__mpxProxy) == null ? void 0 : _a.options) == null ? void 0 : _b.computed) {
      Object.keys(self.__mpxProxy.options.computed).forEach((ck) => {
        if (ck !== "_l" && ck !== "_fl") {
          if (!Object.prototype.hasOwnProperty.call(self.data, ck)) {
            self.data[ck] = null;
          }
        }
      });
    }
  }
  function filterData(obj) {
    if (isNil(obj)) {
      return obj;
    }
    return Object.entries(obj).reduce((acc, [key, value]) => {
      if (key.startsWith("$") || key.startsWith("_l")) {
        return acc;
      } else if (isFunction(value)) {
        console.warn("[Service] 暂不支持函数引用传值");
        return acc;
      } else if (Array.isArray(value)) {
        acc[key] = value.map((item) => typeof item === "object" ? filterData(item) : item);
      } else if (value && typeof value === "object" && !Array.isArray(value)) {
        acc[key] = filterData(value);
      } else {
        acc[key] = value;
      }
      return acc;
    }, {});
  }
  function serializeProps(properties) {
    if (properties) {
      const props = {};
      for (const key in properties) {
        const item = properties[key];
        props[key] = props[key] || {};
        const transType = Object.prototype.hasOwnProperty.call(item, "type") ? convertToStringType(item.type) : convertToStringType(item);
        let array = null;
        if (Array.isArray(transType)) {
          array = [...transType];
        } else {
          array = [transType];
        }
        if (item.optionalTypes) {
          const oTransType = convertToStringType(item.optionalTypes);
          if (Array.isArray(oTransType)) {
            array = [...oTransType];
          } else {
            array.push(oTransType);
          }
        }
        props[key].type = array;
        if (props[key].type.length > 0) {
          if (isFunction(item.value)) {
            props[key].default = item.value();
          } else if (item.type) {
            props[key].default = item.value;
          }
        }
      }
      return props;
    }
  }
  const TYPE_TO_STRING_MAP = /* @__PURE__ */ new Map([
    [String, "s"],
    [Number, "n"],
    [Boolean, "b"],
    [Object, "o"],
    [Array, "a"],
    [Function, "f"]
  ]);
  function convertToStringType(type) {
    if (Array.isArray(type)) {
      return type.map((item) => convertToStringType(item));
    } else {
      if (type === null || type === "") {
        return null;
      }
      const stringType = TYPE_TO_STRING_MAP.get(type);
      if (stringType) {
        return stringType;
      }
      console.warn(`[Service] ignore unknown props type ${type}`);
      return null;
    }
  }
  function filterInvokeObserver(changedKey, observers, data, ctx) {
    for (const observerKey in observers) {
      const observerFn = observers[observerKey];
      const keys = observerKey.split(",").map((k) => k.trim());
      if (keys.includes(changedKey)) {
        const args = keys.map((key) => get(data, key));
        observerFn.call(ctx, ...args);
        continue;
      }
      if (observerKey === "**") {
        observerFn.call(ctx, data);
        continue;
      }
      const observerKeyParts = observerKey.split(".");
      const changedKeyParts = changedKey.split(".");
      let matched = true;
      for (let i = 0; i < observerKeyParts.length; i++) {
        if (observerKeyParts[i] === "**" || changedKeyParts[i] === void 0) {
          break;
        } else if (observerKeyParts[i] !== changedKeyParts[i]) {
          matched = false;
          break;
        }
      }
      if (matched) {
        let targetData = data;
        for (const part of observerKeyParts) {
          if (part !== "**") {
            targetData = targetData[part];
          }
        }
        observerFn.call(ctx, targetData);
        continue;
      }
      const arrayMatch = observerKey.match(/^(.+)\[(\d+)\]$/);
      if (arrayMatch) {
        const arrayKey = arrayMatch[1];
        const index2 = Number.parseInt(arrayMatch[2], 10);
        if (arrayKey === changedKey.split("[")[0] && data[arrayKey] && data[arrayKey][index2] !== void 0) {
          observerFn.call(ctx, data[arrayKey][index2]);
          continue;
        }
      }
      if (changedKey.startsWith(observerKey)) {
        const targetData = observerKey.split(".").reduce((acc, key) => acc && acc[key], data);
        if (targetData !== void 0) {
          observerFn.call(ctx, targetData);
          continue;
        }
      }
    }
  }
  function mergeBehaviors(obj, behaviors) {
    if (!Array.isArray(behaviors)) {
      return;
    }
    const processedBehaviors = /* @__PURE__ */ new WeakMap();
    function merge(target, behavior) {
      if (processedBehaviors.has(behavior)) {
        return;
      }
      processedBehaviors.set(behavior, true);
      if (behavior.properties) {
        target.properties = { ...behavior.properties, ...target.properties };
      }
      if (behavior.data) {
        target.data = { ...behavior.data, ...target.data };
      }
      const lifetimes = ["created", "attached", "ready", "detached"];
      target.behaviorLifetimes = target.behaviorLifetimes || {};
      for (const lifetime of lifetimes) {
        if (isFunction(behavior[lifetime])) {
          target.behaviorLifetimes[lifetime] = target.behaviorLifetimes[lifetime] || [];
          target.behaviorLifetimes[lifetime].push(behavior[lifetime]);
        }
      }
      if (behavior.methods) {
        target.methods = { ...behavior.methods, ...target.methods };
      }
      if (Array.isArray(behavior.behaviors)) {
        behavior.behaviors.forEach((b) => merge(target, b));
      }
    }
    behaviors.forEach((behavior) => merge(obj, behavior));
  }
  function isChildComponent(component, parentId, allComponents) {
    let parent = component;
    while (parent && parent.__parentId__) {
      if (parent.__parentId__ === parentId) {
        return true;
      }
      parent = allComponents.find((item) => item.__id__ === parent.__parentId__);
    }
    return false;
  }
  function matchComponent(selector, item) {
    var _a;
    const idOrClass = selector.slice(1);
    if (selector.startsWith(".")) {
      return ((_a = item.__targetInfo__) == null ? void 0 : _a.class) && item.__targetInfo__.class.split(" ").includes(idOrClass);
    } else if (selector.startsWith("#")) {
      return item.id === idOrClass;
    }
    return false;
  }
  class Page {
    constructor(module, opts) {
      __privateAdd(this, _Page_instances);
      this.initd = false;
      this.opts = opts;
      this.is = opts.path;
      this.bridgeId = opts.bridgeId;
      this.data = cloneDeep(module.noReferenceData);
      this.__type__ = module.type;
      this.__id__ = opts.moduleId;
      this.__info__ = module.moduleInfo;
      __privateMethod(this, _Page_instances, init_fn).call(this);
    }
    setData(data) {
      const fData = filterData(data);
      for (const key in fData) {
        set(this.data, key, fData[key]);
      }
      if (!this.initd) {
        return;
      }
      message.send({
        type: "u",
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          moduleId: this.__id__,
          data: fData
        }
      });
    }
    /**
     * 页面显示/切入前台时触发。该时机不能保证页面渲染完成，如有页面/组件元素相关操作建议在 onReady 中处理
     */
    pageShow() {
      var _a;
      (_a = this.onShow) == null ? void 0 : _a.call(this);
    }
    pageHide() {
      var _a;
      (_a = this.onHide) == null ? void 0 : _a.call(this);
    }
    pageReady() {
      var _a;
      (_a = this.onReady) == null ? void 0 : _a.call(this);
    }
    pageUnload() {
      var _a;
      (_a = this.onUnload) == null ? void 0 : _a.call(this);
      this.initd = false;
    }
    pageScrollTop(opts) {
      var _a;
      const { scrollTop } = opts;
      (_a = this.onPageScroll) == null ? void 0 : _a.call(this, { scrollTop });
    }
  }
  _Page_instances = new WeakSet();
  init_fn = function() {
    __privateMethod(this, _Page_instances, initMembers_fn).call(this);
    __privateMethod(this, _Page_instances, invokeInitLifecycle_fn).call(this).then(() => {
      addComputedData(this);
      message.send({
        type: this.__id__,
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          path: this.is,
          data: this.data
        }
      });
    });
  };
  // 开发者自定义函数
  initMembers_fn = function() {
    for (const attr in this.__info__) {
      const member = this.__info__[attr];
      if (isFunction(member)) {
        this[attr] = member.bind(this);
      } else {
        this[attr] = member;
      }
    }
  };
  invokeInitLifecycle_fn = async function() {
    var _a;
    await ((_a = this.onLoad) == null ? void 0 : _a.call(this, this.opts.query || {}));
    this.initd = true;
  };
  function createSelectorQuery() {
    return new SelectorQuery();
  }
  class SelectorQuery {
    constructor() {
      this.__componentId = router.getPageInfo().id;
      this.__taskQueue = [];
      this.__cbQueue = [];
    }
    /**
     * 将选择器的选取范围更改为自定义组件 component 内。（初始时，选择器仅选取页面范围的节点，不会选取任何自定义组件中的节点）。
     * @param {Component} com
     * @returns {SelectorQuery} SelectorQuery
     */
    in(com) {
      this.__componentId = com.__id__;
      return this;
    }
    /**
     * 在当前页面下选择第一个匹配选择器 selector 的节点。返回一个 NodesRef 对象实例，可以用于获取节点信息。
     * @param {string} selector
     * @returns {NodesRef} NodesRef
     */
    select(selector) {
      return new NodesRef(this, this.__componentId, selector, true);
    }
    /**
     * 在当前页面下选择匹配选择器 selector 的所有节点。
     * @param {string} selector
     * @returns {NodesRef} NodesRef
     */
    selectAll(selector) {
      return new NodesRef(this, this.__componentId, selector, false);
    }
    /**
     * 选择显示区域。可用于获取显示区域的尺寸、滚动位置等信息。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/SelectorQuery.selectViewport.html
     * @returns {NodesRef} NodesRef
     */
    selectViewport() {
      return new NodesRef(this, router.getPageInfo().id, "", true);
    }
    /**
     *
     * @param {*} selector
     * @param {*} moduleId
     * @param {*} single
     * @param {*} fields
     * @param {*} callback
     */
    __push(selector, moduleId, single, fields, callback2) {
      this.__taskQueue.push({
        moduleId,
        selector,
        single,
        fields
      });
      this.__cbQueue.push(callback2);
    }
    /**
     * 执行所有的请求。请求结果按请求次序构成数组，在callback的第一个参数中返回。
     * @param {Function} callback
     */
    exec(callback2) {
      const self = this;
      const data = {
        tasks: this.__taskQueue,
        success: (res) => {
          res.forEach((nodeInfo, index2) => {
            const cb = self.__cbQueue[index2];
            if (isFunction(cb)) {
              cb.call(self, nodeInfo);
            }
          });
          if (isFunction(callback2)) {
            callback2.call(self, res);
          }
        }
      };
      invokeAPI("selectorQuery", data, "render");
    }
  }
  class NodesRef {
    constructor(selectorQuery, componentId, selector, single) {
      this.__selectorQuery = selectorQuery;
      this.__moduleId = componentId;
      this.__selector = selector;
      this.__single = single;
    }
    /**
     * 获取节点的相关信息。需要获取的字段在fields中指定。返回值是 nodesRef 对应的 selectorQuery
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.fields.html
     */
    fields(fields, callback2) {
      this.__selectorQuery.__push(this.__selector, this.__moduleId, this.__single, fields, callback2);
      return this.__selectorQuery;
    }
    /**
     * 添加节点的布局位置的查询请求。相对于显示区域，以像素为单位。其功能类似于 DOM 的 getBoundingClientRect。返回 NodesRef 对应的 SelectorQuery
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.boundingClientRect.html
     */
    boundingClientRect(callback2) {
      return this.fields(
        {
          id: true,
          dataset: true,
          rect: true,
          size: true
        },
        callback2
      );
    }
    /**
     * 添加节点的 Context 对象查询请求。
     * 目前支持 VideoContext、CanvasContext、LivePlayerContext、EditorContext和 MapContext 的获取。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.context.html
     */
    context(callback2) {
      return this.fields(
        {
          context: true
        },
        callback2
      );
    }
    /**
     * 获取 Node 节点实例
     * 目前支持 Canvas 和 ScrollViewContext 的获取。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.node.html
     */
    node(callback2) {
      return this.fields(
        {
          node: true
        },
        callback2
      );
    }
    /**
     * 添加节点的滚动位置查询请求。以像素为单位。节点必须是 scroll-view 或者 viewport，返回 NodesRef 对应的 SelectorQuery。
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/NodesRef.scrollOffset.html
     */
    scrollOffset(callback2) {
      return this.fields(
        {
          id: true,
          dataset: true,
          scrollOffset: true
        },
        callback2
      );
    }
  }
  const __vite_glob_0_49 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createSelectorQuery
  }, Symbol.toStringTag, { value: "Module" }));
  const componentLifetimes = ["created", "attached", "ready", "moved", "detached", "error"];
  const pageLifetimes = ["show", "hide", "resize", "routeDone"];
  class Component {
    constructor(module, opts) {
      __privateAdd(this, _Component_instances);
      this.initd = false;
      this.opts = opts;
      if (opts.targetInfo) {
        this.id = opts.targetInfo.id;
        this.dataset = opts.targetInfo.dataset;
        this.__targetInfo__ = opts.targetInfo;
      }
      this.is = opts.path;
      this.renderer = "webview";
      this.bridgeId = opts.bridgeId;
      this.behaviors = module.behaviors;
      this.data = cloneDeep(module.noReferenceData);
      this.__isComponent__ = module.isComponent;
      this.__type__ = module.type;
      this.__id__ = this.opts.moduleId;
      this.__info__ = module.moduleInfo;
      this.__eventAttr__ = opts.eventAttr;
      this.__pageId__ = opts.pageId;
      this.__parentId__ = opts.parentId;
      __privateMethod(this, _Component_instances, init_fn2).call(this);
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/performance/tips/runtime_setData.html
     * @param {*} data
     */
    setData(data) {
      const fData = filterData(data);
      for (const key in fData) {
        set(this.data, key, fData[key]);
      }
      if (!this.initd) {
        return;
      }
      message.send({
        type: "u",
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          moduleId: this.__id__,
          data: fData
        }
      });
    }
    /**
     * 触发观察者函数
     * triggerObserver
     */
    tO(data) {
      var _a, _b;
      for (const [prop, val] of Object.entries(data)) {
        if (this.__info__.observers) {
          filterInvokeObserver(prop, this.__info__.observers, data, this);
        }
        const observer = (_a = this.__info__.properties[prop]) == null ? void 0 : _a.observer;
        if (isString(observer)) {
          (_b = this[observer]) == null ? void 0 : _b.call(this, val);
        } else if (isFunction(observer)) {
          observer.call(this, val);
        }
      }
    }
    getPageId() {
      return this.__id__;
    }
    /**
     * 检查组件是否具有 behavior （检查时会递归检查被直接或间接引入的所有behavior）
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
     */
    hasBehavior(behavior) {
      const _hasBehavior = function(behaviors) {
        if (behaviors.includes(behavior)) {
          return true;
        }
        for (const b of behaviors) {
          if (_hasBehavior(b.behaviors)) {
            return true;
          }
        }
        return false;
      };
      return _hasBehavior(this.behaviors);
    }
    /**
     * 创建一个 SelectorQuery 对象，选择器选取范围为这个组件实例内
     */
    createSelectorQuery() {
      return createSelectorQuery().in(this);
    }
    /**
     * 使用选择器选取子组件实例对象，返回匹配到的第一个组件实例对象
     */
    selectComponent(selector) {
      const children = Object.values(runtime.instances[this.bridgeId]);
      return children.find(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      ) || null;
    }
    /**
     * 使用选择器选取子组件实例对象，返回匹配到的全部组件实例对象组成的数组
     */
    selectAllComponents(selector) {
      const children = Object.values(runtime.instances[this.bridgeId]);
      return children.filter(
        (item) => isChildComponent(item, this.__id__, children) && matchComponent(selector, item)
      );
    }
    /**
     * 选取当前组件节点所在的组件实例（即组件的引用者），返回它的组件实例对象
     */
    selectOwnerComponent() {
      const children = Object.values(runtime.instances[this.bridgeId]);
      for (const item of children) {
        if (item.id === this.__parentId__) {
          return item;
        }
      }
      return null;
    }
    /**
     * TODO: 创建一个 IntersectionObserver 对象，选择器选取范围为这个组件实例内
     */
    createIntersectionObserver() {
      console.warn("[Service] 暂不支持 createIntersectionObserver");
    }
    /**
     * TODO: 创建一个 MediaQueryObserver 对象
     */
    createMediaQueryObserver() {
      console.warn("[Service] 暂不支持 createMediaQueryObserver");
    }
    /**
     * TODO: 获取这个关系所对应的所有关联节点
     */
    getRelationNodes() {
      console.warn("[Service] 暂不支持 getRelationNodes");
    }
    /**
     * TODO: 执行关键帧动画
     */
    animate() {
      console.warn("[Service] 暂不支持 animate");
    }
    /**
     * TODO: 清除关键帧动画
     */
    clearAnimation() {
      console.warn("[Service] 暂不支持 clearAnimation");
    }
    /**
     * 触发组件所在页面的事件逻辑
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/events.html
     * @param {*} methodName
     * @param {*} detail // detail���象，提供给事件监听函数
     * @param {*} options // 触发事件的选项
     */
    async triggerEvent(methodName, detail, options = {}) {
      const type = methodName.trim();
      await runtime.triggerEvent({
        bridgeId: this.bridgeId,
        moduleId: this.__pageId__,
        methodName: this.__eventAttr__[type],
        event: {
          type,
          detail,
          currentTarget: {
            id: this.id,
            dataset: this.dataset
          },
          target: {
            id: this.id,
            dataset: this.dataset
          }
        }
      });
      if (options.bubbles) {
        const parentInstance = runtime.instances[this.bridgeId][this.__parentId__];
        await (parentInstance == null ? void 0 : parentInstance.triggerEvent(methodName, detail));
      }
      if (options.composed) ;
      if (options.capturePhase) ;
    }
    pageReady() {
      var _a;
      if (!this.__isComponent__) {
        (_a = this.ready) == null ? void 0 : _a.call(this);
      }
    }
    /**
     * 页面退出时执行
     */
    pageUnload() {
      var _a;
      if (!this.__isComponent__) {
        (_a = this.onUnload) == null ? void 0 : _a.call(this);
      }
    }
    pageScrollTop(opts) {
      var _a;
      if (!this.__isComponent__) {
        const { scrollTop } = opts;
        (_a = this.onPageScroll) == null ? void 0 : _a.call(this, { scrollTop });
      }
    }
    // --- 组件所在页面的生命周期 ---
    /**
     * 组件所在的页面被展示时执行
     */
    pageShow() {
      var _a;
      (_a = this.onShow) == null ? void 0 : _a.call(this);
    }
    /**
     * 组件所在的页面被隐藏时执行
     */
    pageHide() {
      var _a;
      (_a = this.onHide) == null ? void 0 : _a.call(this);
    }
    /**
     * 组件所在的页面尺寸变化时执行
     * @param {object} size
     */
    pageResize(size) {
      var _a;
      (_a = this.resize) == null ? void 0 : _a.call(this, size);
    }
    // 组件所在页面路由动画完成时执行
    componentRouteDone() {
      var _a;
      (_a = this.routeDone) == null ? void 0 : _a.call(this);
    }
    // --- 组件的生命周期 ---
    /**
     * 在组件实例刚刚被创建时执行
     */
    async componentCreated() {
      var _a, _b, _c;
      (_b = (_a = this.__info__.behaviorLifetimes) == null ? void 0 : _a.created) == null ? void 0 : _b.forEach((method) => method.call(this));
      await ((_c = this.created) == null ? void 0 : _c.call(this));
    }
    /**
     * 在组件实例进入页面节点树时执行
     */
    async componentAttached() {
      var _a, _b, _c;
      (_b = (_a = this.__info__.behaviorLifetimes) == null ? void 0 : _a.attached) == null ? void 0 : _b.forEach((method) => method.call(this));
      await ((_c = this.attached) == null ? void 0 : _c.call(this));
    }
    /**
     * 在组件在视图层布局完成后执行
     */
    componentReadied() {
      var _a, _b, _c;
      (_b = (_a = this.__info__.behaviorLifetimes) == null ? void 0 : _a.ready) == null ? void 0 : _b.forEach((method) => method.call(this));
      (_c = this.ready) == null ? void 0 : _c.call(this);
    }
    /**
     * 在组件实例被���动到节点树另一个位置时执行
     */
    componentMoved() {
      var _a;
      (_a = this.moved) == null ? void 0 : _a.call(this);
    }
    /**
     * 在组件实例被从页面节点树移除时执行
     */
    componentDetached() {
      var _a, _b, _c;
      (_b = (_a = this.__info__.behaviorLifetimes) == null ? void 0 : _a.detached) == null ? void 0 : _b.forEach((method) => method.call(this));
      (_c = this.detached) == null ? void 0 : _c.call(this);
      this.initd = false;
    }
    /**
     * 每当组件方法抛出错误时执行
     * @param {*} error
     */
    componentError(error) {
      var _a;
      (_a = this.error) == null ? void 0 : _a.call(this, error);
    }
  }
  _Component_instances = new WeakSet();
  init_fn2 = function() {
    if (this.__isComponent__) {
      for (const key in this.__info__.properties) {
        if (!Object.prototype.hasOwnProperty.call(this.opts.properties, key) || this.opts.properties[key] === void 0) {
          this.data[key] = this.__info__.properties[key].value;
        } else {
          this.data[key] = this.opts.properties[key];
        }
      }
    }
    __privateMethod(this, _Component_instances, initLifecycle_fn).call(this);
    __privateMethod(this, _Component_instances, initCustomMethods_fn).call(this);
    __privateMethod(this, _Component_instances, invokeInitLifecycle_fn2).call(this).then(() => {
      addComputedData(this);
      message.send({
        type: this.__id__,
        target: "render",
        body: {
          bridgeId: this.bridgeId,
          path: this.is,
          data: this.data
        }
      });
    });
  };
  /**
   * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
   */
  initLifecycle_fn = function() {
    componentLifetimes.forEach((method) => {
      var _a;
      const lifecycleMethod = ((_a = this.__info__.lifetimes) == null ? void 0 : _a[method]) || this.__info__[method];
      if (!isFunction(lifecycleMethod)) {
        return;
      }
      this[method] = lifecycleMethod.bind(this);
    });
    if (this.__isComponent__) {
      pageLifetimes.forEach((method) => {
        var _a;
        const lifecycleMethod = (_a = this.__info__.pageLifetimes) == null ? void 0 : _a[method];
        if (!isFunction(lifecycleMethod)) {
          return;
        }
        if (method === "show") {
          method = "onShow";
        } else if (method === "hide") {
          method = "onHide";
        }
        this[method] = lifecycleMethod.bind(this);
      });
    }
  };
  /**
   * 开发者自定义函数
   * Component 构造器的主要区别是：方法需要放在 methods: { } 里面
   */
  initCustomMethods_fn = function() {
    const methods = this.__info__.methods;
    for (const attr in methods) {
      if (isFunction(methods[attr])) {
        this[attr] = methods[attr].bind(this);
      }
    }
  };
  invokeInitLifecycle_fn2 = async function() {
    var _a;
    if (this.__isComponent__) {
      await this.componentCreated();
      await this.componentAttached();
    } else {
      await this.componentCreated();
      await this.componentAttached();
      await ((_a = this.onLoad) == null ? void 0 : _a.call(this, this.opts.query || {}));
    }
    this.initd = true;
  };
  const _ComponentModule = class _ComponentModule {
    /**
     *
     * @param {{data: object, lifetimes: object, pageLifetimes: object, methods: object, options: object, properties: object}} moduleInfo
     */
    constructor(moduleInfo, extraInfo) {
      this.moduleInfo = moduleInfo;
      this.extraInfo = extraInfo;
      this.type = _ComponentModule.type;
      this.isComponent = this.extraInfo.component;
      this.behaviors = this.moduleInfo.behaviors;
      this.usingComponents = this.extraInfo.usingComponents;
      this.noReferenceData = filterData(this.moduleInfo.data || {});
      mergeBehaviors(this.moduleInfo, this.behaviors);
    }
    getProps() {
      let props = serializeProps(this.moduleInfo.properties);
      if (Array.isArray(this.moduleInfo.externalClasses) && this.moduleInfo.externalClasses.length > 0) {
        if (!props) {
          props = {};
        }
        for (const externalClass of this.moduleInfo.externalClasses) {
          props[externalClass] = {
            type: ["s"],
            cls: true
          };
        }
      }
      return props;
    }
  };
  __publicField(_ComponentModule, "type", "component");
  let ComponentModule = _ComponentModule;
  const _PageModule = class _PageModule {
    constructor(moduleInfo, extraInfo) {
      this.moduleInfo = moduleInfo;
      this.extraInfo = extraInfo;
      this.type = _PageModule.type;
      this.usingComponents = this.extraInfo.usingComponents;
      this.noReferenceData = filterData(this.moduleInfo.data || {});
    }
  };
  __publicField(_PageModule, "type", "page");
  let PageModule = _PageModule;
  class AppModule {
    constructor(moduleInfo) {
      this.moduleInfo = moduleInfo;
    }
  }
  __publicField(AppModule, "type", "app");
  class Loader {
    constructor() {
      this.staticModules = {};
    }
    /**
     * [Container] loadResource -> [Service] loadResource
     * @param {*} opts
     */
    loadResource(opts) {
      const { appId, bridgeId, pagePath, root } = opts;
      if (isWebWorker) {
        this.isScriptLoaded = this.isScriptLoaded || {};
        if (!this.isScriptLoaded[root]) {
          const logicResourcePath = `/${appId}/${root}/logic.js`;
          globalThis.importScripts(logicResourcePath);
          this.isScriptLoaded[root] = true;
        }
      }
      router.setInitId(bridgeId);
      modRequire("app");
      modRequire(pagePath);
      message.invoke({
        type: "serviceResourceLoaded",
        target: "service",
        body: {
          bridgeId
        }
      });
    }
    /**
     * 创建逻辑层 App 映射实例
     * @param {*} moduleInfo
     */
    createAppModule(moduleInfo) {
      const appModule = new AppModule(moduleInfo);
      this.staticModules[AppModule.type] = appModule;
    }
    /**
     *创建逻辑层 Page/Component 映射实例
     * [Container]loadResource -> [Service]loadResource -> globalThis.Page/globalThis.Component -> create
     * @param {*} moduleInfo {{data: object, method: object}} 模块逻辑信息
     * @param {*} extraInfo {{path: string, component: boolean, usingComponents: object}} 模块额外信息
     * @param {*} type {{type: string}} type
     */
    createModule(moduleInfo, extraInfo, type) {
      const { path, usingComponents } = extraInfo;
      if (this.staticModules[path]) {
        return;
      }
      if (usingComponents) {
        for (const componentPath of Object.values(usingComponents)) {
          modRequire(componentPath);
        }
      }
      if (type === PageModule.type) {
        const pageModule = new PageModule(moduleInfo, extraInfo);
        this.staticModules[path] = pageModule;
      } else if (type === ComponentModule.type) {
        const componentModule = new ComponentModule(moduleInfo, extraInfo);
        this.staticModules[path] = componentModule;
      } else {
        console.error(`[Service] createModule ${type} error`);
      }
    }
    getPropsByPath(usingComponents) {
      const res = {};
      this.getComponentProps(res, usingComponents);
      return res;
    }
    getComponentProps(res, usingComponents) {
      if (!usingComponents) {
        return;
      }
      for (const componentPath of Object.values(usingComponents)) {
        const component = this.staticModules[componentPath];
        if (!component) {
          continue;
        }
        res[componentPath] = component.getProps();
        this.getComponentProps(res, component.usingComponents);
      }
    }
    getAppModule() {
      return this.staticModules[AppModule.type];
    }
    getModuleByPath(path) {
      return this.staticModules[path];
    }
  }
  const loader = new Loader();
  class Runtime {
    constructor() {
      this.app = null;
      this.instances = {};
    }
    createApp(opts) {
      if (this.app) {
        console.log("[Service] app instance already existed");
        return;
      }
      const { scene, pagePath: path, query } = opts;
      const appModule = loader.getAppModule();
      if (!appModule) {
        console.log("[Service] app instance is not exist");
        return;
      }
      console.log("[Service] create app instance");
      this.app = new App(appModule, {
        scene,
        path,
        query
      });
    }
    appShow() {
      var _a;
      (_a = this.app) == null ? void 0 : _a.appShow();
    }
    appHide() {
      var _a;
      (_a = this.app) == null ? void 0 : _a.appHide();
    }
    stackShow(stackId) {
      router.pushStack(stackId);
    }
    stackHide(stackId) {
      router.popStack(stackId);
    }
    /**
     * 渲染层创建映射实例
     * [Render]componentCreated -> [Container]createInstance ->[Service]createInstance
     * @param {*} opts
     */
    createInstance(opts) {
      const { bridgeId, moduleId, path, query, eventAttr, pageId, parentId, properties, targetInfo, stackId } = opts;
      const module = loader.getModuleByPath(path);
      if (!module) {
        console.error(`[Service] ${path} not exist`);
        return;
      }
      console.log(`[Service] create instance ${path}`);
      this.instances[bridgeId] = this.instances[bridgeId] || {};
      if (module.type === ComponentModule.type) {
        if (!module.isComponent) {
          router.push({
            id: bridgeId,
            path,
            query
          }, stackId);
        }
        const component = new Component(module, {
          bridgeId,
          moduleId,
          path,
          query,
          eventAttr,
          pageId,
          parentId,
          properties,
          targetInfo
        });
        this.instances[bridgeId][moduleId] = component;
        return component;
      } else if (module.type === PageModule.type) {
        router.push({
          id: bridgeId,
          path,
          query
        }, stackId);
        const page = new Page(module, {
          bridgeId,
          moduleId,
          path,
          query
        });
        this.instances[bridgeId][moduleId] = page;
        return page;
      } else {
        console.error(`[Service] ${module.type} instance is not exist.`);
      }
    }
    moduleAttached(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentAttached();
      }
    }
    moduleReady(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentReadied();
      }
    }
    moduleUnmounted(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentDetached();
      }
      delete this.instances[bridgeId][moduleId];
    }
    pageShow(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      if (!instances) {
        return;
      }
      const pageInstances = [];
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === PageModule.type) {
          pageInstances.push(instance);
        } else if (instance.__type__ === ComponentModule.type) {
          if (!instance.__isComponent__) {
            pageInstances.push(instance);
          } else {
            instance.pageShow();
          }
        }
      });
      pageInstances.forEach((instance) => {
        instance.pageShow();
      });
    }
    pageReady(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      this.pageShow(opts);
      instance.pageReady();
    }
    pageHide(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      const pageInstances = [];
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === PageModule.type) {
          pageInstances.push(instance);
        } else if (instance.__type__ === ComponentModule.type) {
          if (!instance.__isComponent__) {
            pageInstances.push(instance);
          } else {
            instance.pageHide();
          }
        }
      });
      pageInstances.forEach((instance) => {
        if (!instance) {
          return;
        }
        instance.pageHide();
      });
    }
    pageUnload(opts) {
      const { bridgeId } = opts;
      const instances = this.instances[bridgeId];
      if (!instances) {
        return;
      }
      Object.values(instances).forEach((instance) => {
        if (!instance) {
          return;
        }
        if (instance.__type__ === ComponentModule.type) {
          instance.componentDetached();
        }
        instance.pageUnload();
      });
      router.pop();
      delete this.instances[bridgeId];
    }
    pageScroll(opts) {
      const { bridgeId, moduleId, scrollTop } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      instance.pageScrollTop({ scrollTop });
    }
    pageResize(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      instance.pageResize();
    }
    componentError(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentError();
      }
    }
    componentRouteDone(opts) {
      const { bridgeId, moduleId } = opts;
      const instance = this.instances[bridgeId][moduleId];
      if (!instance) {
        return;
      }
      if (instance.__type__ === ComponentModule.type) {
        instance.componentRouteDone();
      }
    }
    /**
     * 调用业务 js 方法
     * @param {*} opts
     */
    async triggerEvent(opts) {
      const { bridgeId, moduleId, methodName, event } = opts;
      if (methodName === void 0) {
        return;
      }
      const instances = this.instances[bridgeId];
      if (!instances) {
        console.warn(`[Service] No instances found for bridgeId: ${bridgeId}`);
        return;
      }
      const instance = instances[moduleId];
      if (!instance) {
        console.warn(`[Service] triggerEvent ${bridgeId} ${moduleId} ${methodName}, instance is not exist`);
        return;
      }
      if (isFunction(instance[methodName])) {
        return await instance[methodName](event);
      } else {
        console.warn(`[Service] triggerEvent ${bridgeId} ${moduleId}, is: ${instance.is}, method: ${methodName} is not exist`);
      }
    }
  }
  const runtime = new Runtime();
  function getLaunchOptionsSync() {
    var _a;
    return (_a = runtime.app) == null ? void 0 : _a.options;
  }
  function getEnterOptionsSync() {
    var _a;
    return (_a = runtime.app) == null ? void 0 : _a.options;
  }
  const __vite_glob_0_19 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getEnterOptionsSync,
    getLaunchOptionsSync
  }, Symbol.toStringTag, { value: "Module" }));
  function getLocation(opts) {
    invokeAPI("getLocation", opts);
  }
  function startLocationUpdate(opts) {
    invokeAPI("startLocationUpdate", opts);
  }
  function openLocation(opts) {
    invokeAPI("openLocation", opts);
  }
  function stopLocationUpdate(opts) {
    invokeAPI("stopLocationUpdate", opts);
  }
  function onLocationChange(listener) {
    if (listener) {
      const id = callback.store(listener, true);
      invokeAPI("onLocationChange", {
        success: id
      });
    }
  }
  function offLocationChange(listener) {
    if (listener) {
      const id = callback.store(listener, true);
      invokeAPI("offLocationChange", {
        success: id
      });
      callback.remove(id);
    } else {
      invokeAPI("offLocationChange");
      callback.remove();
    }
  }
  const __vite_glob_0_20 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getLocation,
    offLocationChange,
    onLocationChange,
    openLocation,
    startLocationUpdate,
    stopLocationUpdate
  }, Symbol.toStringTag, { value: "Module" }));
  function createMapContext(mapId, obj) {
    return new MapContext({ mapId, obj });
  }
  class MapContext {
    constructor(opts) {
      this.opts = opts;
    }
    addMarkers(data) {
      invokeAPI("addMarkers", data);
    }
    removeMarkers(data) {
      invokeAPI("removeMarkers", data);
    }
    includePoints(data) {
      invokeAPI("includePoints", data);
    }
    setCenterOffset(data) {
      invokeAPI("setCenterOffset", data);
    }
    getCenterLocation(data) {
      invokeAPI("getCenterLocation", data);
    }
    getScale(data) {
      invokeAPI("getScale", data);
    }
    moveToLocation(data) {
      invokeAPI("moveToLocation", data);
    }
    translateMarker(data) {
      invokeAPI("translateMarker", data);
    }
    addArc(data) {
      invokeAPI("addArc", data);
    }
    removeArc(data) {
      invokeAPI("removeArc", data);
    }
  }
  const __vite_glob_0_21 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createMapContext
  }, Symbol.toStringTag, { value: "Module" }));
  function saveImageToPhotosAlbum(opts) {
    invokeAPI("saveImageToPhotosAlbum", opts);
  }
  function previewImage(opts) {
    invokeAPI("previewImage", opts);
  }
  function compressImage(opts) {
    invokeAPI("compressImage", opts);
  }
  function chooseImage(opts) {
    invokeAPI("chooseImage", opts);
  }
  const __vite_glob_0_22 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    chooseImage,
    compressImage,
    previewImage,
    saveImageToPhotosAlbum
  }, Symbol.toStringTag, { value: "Module" }));
  function chooseVideo(opts) {
    invokeAPI("chooseVideo", opts);
  }
  function chooseMedia(opts) {
    invokeAPI("chooseMedia", opts);
  }
  const __vite_glob_0_23 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    chooseMedia,
    chooseVideo
  }, Symbol.toStringTag, { value: "Module" }));
  function restartMiniProgram(opts) {
    invokeAPI("restartMiniProgram", opts);
  }
  function navigateToMiniProgram(opts) {
    invokeAPI("navigateToMiniProgram", opts);
  }
  function navigateBackMiniProgram(opts) {
    invokeAPI("navigateBackMiniProgram", opts);
  }
  function exitMiniProgram(opts) {
    invokeAPI("exitMiniProgram", opts);
  }
  const __vite_glob_0_24 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    exitMiniProgram,
    navigateBackMiniProgram,
    navigateToMiniProgram,
    restartMiniProgram
  }, Symbol.toStringTag, { value: "Module" }));
  function downloadFile(opts) {
    invokeAPI("downloadFile", opts);
  }
  const __vite_glob_0_25 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    downloadFile
  }, Symbol.toStringTag, { value: "Module" }));
  function request(opts) {
    invokeAPI("request", opts);
  }
  const __vite_glob_0_26 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    request
  }, Symbol.toStringTag, { value: "Module" }));
  function uploadFile(opts) {
    invokeAPI("uploadFile", opts);
  }
  const __vite_glob_0_27 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    uploadFile
  }, Symbol.toStringTag, { value: "Module" }));
  function getAccountInfoSync() {
    return invokeAPI("getAccountInfoSync");
  }
  const __vite_glob_0_28 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getAccountInfoSync
  }, Symbol.toStringTag, { value: "Module" }));
  function authorize(opts) {
    invokeAPI("authorize", opts);
  }
  const __vite_glob_0_29 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    authorize
  }, Symbol.toStringTag, { value: "Module" }));
  function login$1(opts) {
    invokeAPI("login", opts);
  }
  const __vite_glob_0_30 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    login: login$1
  }, Symbol.toStringTag, { value: "Module" }));
  function login(opts) {
    invokeAPI("login", opts);
  }
  const __vite_glob_0_31 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    login
  }, Symbol.toStringTag, { value: "Module" }));
  function getPrivacySetting(opts) {
    invokeAPI("getPrivacySetting", opts);
  }
  const __vite_glob_0_32 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getPrivacySetting
  }, Symbol.toStringTag, { value: "Module" }));
  function openSetting(opts) {
    invokeAPI("openSetting", opts);
  }
  function getSetting(opts) {
    invokeAPI("getSetting", opts);
  }
  const __vite_glob_0_33 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getSetting,
    openSetting
  }, Symbol.toStringTag, { value: "Module" }));
  function getUserInfo(opts) {
    invokeAPI("getUserInfo", opts);
  }
  const __vite_glob_0_34 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getUserInfo
  }, Symbol.toStringTag, { value: "Module" }));
  function requestPayment(opts) {
    invokeAPI("requestPayment", opts);
  }
  const __vite_glob_0_35 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    requestPayment
  }, Symbol.toStringTag, { value: "Module" }));
  function switchTab(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("switchTab", opts);
  }
  function reLaunch(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("reLaunch", opts);
  }
  function redirectTo(opts) {
    const url = parsePath(router.getPageInfo().route, opts.url);
    if (router.getPageInfo().route === url) {
      return;
    }
    opts.url = url;
    invokeAPI("redirectTo", opts);
  }
  function navigateTo(opts) {
    opts.url = parsePath(router.getPageInfo().route, opts.url);
    invokeAPI("navigateTo", opts);
  }
  function navigateBack(opts) {
    invokeAPI("navigateBack", opts);
  }
  const __vite_glob_0_36 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    navigateBack,
    navigateTo,
    reLaunch,
    redirectTo,
    switchTab
  }, Symbol.toStringTag, { value: "Module" }));
  function showShareMenu(opts) {
    invokeAPI("shareShareMenu", opts);
  }
  function showShareImageMenu(opts) {
    invokeAPI("showShareImageMenu", opts);
  }
  function hideShareMenu(opts) {
    invokeAPI("hideShareMenu", opts);
  }
  const __vite_glob_0_37 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideShareMenu,
    showShareImageMenu,
    showShareMenu
  }, Symbol.toStringTag, { value: "Module" }));
  function setStorageSync(...opts) {
    invokeAPI("setStorageSync", opts);
  }
  function getStorageSync(opts) {
    return invokeAPI("getStorageSync", opts);
  }
  function removeStorageSync(...opts) {
    return invokeAPI("removeStorageSync", opts);
  }
  function clearStorageSync() {
    invokeAPI("clearStorageSync");
  }
  function setStorage(opts) {
    invokeAPI("setStorage", opts);
  }
  function getStorage(opts) {
    invokeAPI("getStorage", opts);
  }
  function removeStorage(opts) {
    invokeAPI("removeStorage", opts);
  }
  function clearStorage() {
    invokeAPI("clearStorage");
  }
  function getStorageInfoSync(...opts) {
    return invokeAPI("getStorageInfoSync", opts);
  }
  function getStorageInfo(opts) {
    invokeAPI("getStorageInfo", opts);
  }
  const __vite_glob_0_38 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    clearStorage,
    clearStorageSync,
    getStorage,
    getStorageInfo,
    getStorageInfoSync,
    getStorageSync,
    removeStorage,
    removeStorageSync,
    setStorage,
    setStorageSync
  }, Symbol.toStringTag, { value: "Module" }));
  function createAnimation(opts = {}) {
    return new Animation(opts);
  }
  class Animation {
    constructor({ duration = 400, timingFunction = "linear", delay = 0, transformOrigin = "50% 50% 0" } = {}) {
      this.actions = [];
      this.currentTransform = {};
      this.currentStepAnimates = [];
      this.option = {
        transition: {
          duration,
          timingFunction,
          delay
        },
        transformOrigin
      };
    }
    /**
     * 导出动画队列。export 方法每次调用后会清掉之前的动画操作。
     * https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.export.html
     */
    export() {
      const actions = this.actions;
      this.actions = [];
      return { actions };
    }
    /**
     * 表示一组动画完成。可以在一组动画中调用任意多个动画方法，一组动画中的所有动画会同时开始，一组动画完成后才会进行下一组动画。
     * https://developers.weixin.qq.com/miniprogram/dev/api/ui/animation/Animation.step.html
     */
    step(option = {}) {
      for (const stepAnimate of this.currentStepAnimates) {
        if (stepAnimate.type === "style") {
          this.currentTransform[`${stepAnimate.type}.${stepAnimate.args[0]}`] = stepAnimate;
        } else {
          this.currentTransform[stepAnimate.type] = stepAnimate;
        }
      }
      this.actions.push({
        animates: Object.keys(this.currentTransform).reduce((prev, current) => {
          return [].concat(...prev, [this.currentTransform[current]]);
        }, []),
        option: {
          transformOrigin: option.transformOrigin !== void 0 ? option.transformOrigin : this.option.transformOrigin,
          transition: {
            duration: option.duration !== void 0 ? option.duration : this.option.transition.duration,
            timingFunction: option.timingFunction !== void 0 ? option.timingFunction : this.option.transition.timingFunction,
            delay: option.delay !== void 0 ? option.delay : this.option.transition.delay
          }
        }
      });
      this.currentStepAnimates = [];
      return this;
    }
    backgroundColor(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["background-color", value]
      });
      return this;
    }
    bottom(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["bottom", value]
      });
      return this;
    }
    height(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["height", value]
      });
      return this;
    }
    left(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["left", value]
      });
      return this;
    }
    matrix(a = 1, b = 0, c = 0, d = 1, tx = 1, ty = 1) {
      this.currentStepAnimates.push({
        type: "matrix",
        args: [a, b, c, d, tx, ty]
      });
      return this;
    }
    matrix3d(a1 = 1, b1 = 0, c1 = 0, d1 = 0, a2 = 0, b2 = 1, c2 = 0, d2 = 0, a3 = 0, b3 = 0, c3 = 1, d3 = 0, a4 = 0, b4 = 0, c4 = 0, d4 = 1) {
      this.currentStepAnimates.push({
        type: "matrix3d",
        args: [
          a1,
          b1,
          c1,
          d1,
          a2,
          b2,
          c2,
          d2,
          a3,
          b3,
          c3,
          d3,
          a4,
          b4,
          c4,
          d4
        ]
      });
      return this;
    }
    opacity(value) {
      this.currentStepAnimates.push({
        type: "style",
        args: ["opacity", value]
      });
      return this;
    }
    right(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["right", value]
      });
      return this;
    }
    rotate(angle = 0) {
      this.currentStepAnimates.push({
        type: "rotate",
        args: [angle]
      });
      return this;
    }
    rotate3d(x = 0, y = 0, z = 0, angle = 0) {
      this.currentStepAnimates.push({
        type: "rotate3d",
        args: [x, y, z, angle]
      });
      return this;
    }
    rotateX(angle) {
      this.currentStepAnimates.push({
        type: "rotateX",
        args: [angle]
      });
      return this;
    }
    rotateY(angle) {
      this.currentStepAnimates.push({
        type: "rotateY",
        args: [angle]
      });
      return this;
    }
    rotateZ(angle) {
      this.currentStepAnimates.push({
        type: "rotateZ",
        args: [angle]
      });
      return this;
    }
    scale(x = 1, y = 1) {
      this.currentStepAnimates.push({
        type: "scale",
        args: [x, y]
      });
      return this;
    }
    scale3d(sx = 1, sy = 1, sz = 1) {
      this.currentStepAnimates.push({
        type: "scale3d",
        args: [sx, sy, sz]
      });
      return this;
    }
    scaleX(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleX",
        args: [scale]
      });
      return this;
    }
    scaleY(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleY",
        args: [scale]
      });
      return this;
    }
    scaleZ(scale = 1) {
      this.currentStepAnimates.push({
        type: "scaleZ",
        args: [scale]
      });
      return this;
    }
    skew(ax = 0, ay = 0) {
      this.currentStepAnimates.push({
        type: "skew",
        args: [ax, ay]
      });
      return this;
    }
    skewX(angle = 0) {
      this.currentStepAnimates.push({
        type: "skewX",
        args: [angle]
      });
      return this;
    }
    skewY(angle = 0) {
      this.currentStepAnimates.push({
        type: "skewY",
        args: [angle]
      });
      return this;
    }
    top(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["top", value]
      });
      return this;
    }
    translate(tx = 0, ty = 0) {
      this.currentStepAnimates.push({
        type: "translate",
        args: [tx, ty]
      });
      return this;
    }
    translate3d(tx = 0, ty = 0, tz = 0) {
      this.currentStepAnimates.push({
        type: "translate3d",
        args: [tx, ty, tz]
      });
      return this;
    }
    translateX(translation = 0) {
      this.currentStepAnimates.push({
        type: "translateX",
        args: [translation]
      });
      return this;
    }
    translateY(translation = 0) {
      this.currentStepAnimates.push({
        type: "translateY",
        args: [translation]
      });
      return this;
    }
    width(value) {
      isNumber(value) && (value = `${value}px`);
      this.currentStepAnimates.push({
        type: "style",
        args: ["width", value]
      });
      return this;
    }
  }
  const __vite_glob_0_39 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createAnimation
  }, Symbol.toStringTag, { value: "Module" }));
  function setBackgroundTextStyle(opts) {
    invokeAPI("setBackgroundTextStyle", opts);
  }
  function setBackgroundColor(opts) {
    invokeAPI("setBackgroundColor", opts);
  }
  const __vite_glob_0_40 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    setBackgroundColor,
    setBackgroundTextStyle
  }, Symbol.toStringTag, { value: "Module" }));
  let nextTickCallbackList = [];
  let nextTickTimer = null;
  function callNextTick() {
    const cbs = nextTickCallbackList;
    nextTickCallbackList = [];
    nextTickTimer = null;
    for (let i = 0; i < cbs.length; i++) {
      cbs[i]();
    }
  }
  function nextTick(callback2) {
    if (isFunction(callback2)) {
      nextTickCallbackList.push(callback2);
      if (!nextTickTimer) {
        nextTickTimer = setTimeout(callNextTick, 0);
      }
    }
  }
  const __vite_glob_0_41 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    nextTick
  }, Symbol.toStringTag, { value: "Module" }));
  function showToast(opts) {
    invokeAPI("showToast", opts);
  }
  function hideToast(opts) {
    invokeAPI("hideToast", opts);
  }
  function showModal(opts) {
    invokeAPI("showModal", opts);
  }
  function showLoading(opts) {
    invokeAPI("showLoading", opts);
  }
  function showActionSheet(opts) {
    invokeAPI("showActionSheet", opts);
  }
  function hideLoading(opts) {
    invokeAPI("hideLoading", opts);
  }
  function enableAlertBeforeUnload(opts) {
    invokeAPI("enableAlertBeforeUnload", opts);
  }
  function disableAlertBeforeUnload(opts) {
    invokeAPI("disableAlertBeforeUnload", opts);
  }
  const __vite_glob_0_42 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    disableAlertBeforeUnload,
    enableAlertBeforeUnload,
    hideLoading,
    hideToast,
    showActionSheet,
    showLoading,
    showModal,
    showToast
  }, Symbol.toStringTag, { value: "Module" }));
  function getMenuButtonBoundingClientRect() {
    return invokeAPI("getMenuButtonBoundingClientRect");
  }
  const __vite_glob_0_43 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    getMenuButtonBoundingClientRect
  }, Symbol.toStringTag, { value: "Module" }));
  function showNavigationBarLoading(opts) {
    invokeAPI("showNavigationBarLoading", opts);
  }
  function setNavigationBarTitle(opts) {
    invokeAPI("setNavigationBarTitle", opts);
  }
  function setNavigationBarColor(opts) {
    invokeAPI("setNavigationBarColor", opts);
  }
  function hideNavigationBarLoading(opts) {
    invokeAPI("hideNavigationBarLoading", opts);
  }
  const __vite_glob_0_44 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hideNavigationBarLoading,
    setNavigationBarColor,
    setNavigationBarTitle,
    showNavigationBarLoading
  }, Symbol.toStringTag, { value: "Module" }));
  function stopPullDownRefresh(opts) {
    invokeAPI("stopPullDownRefresh", opts);
  }
  function startPullDownRefresh(opts) {
    invokeAPI("startPullDownRefresh", opts);
  }
  const __vite_glob_0_45 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    startPullDownRefresh,
    stopPullDownRefresh
  }, Symbol.toStringTag, { value: "Module" }));
  function pageScrollTo(opts) {
    invokeAPI("pageScrollTo", opts);
  }
  const __vite_glob_0_46 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    pageScrollTo
  }, Symbol.toStringTag, { value: "Module" }));
  function onWindowResize(listener) {
    if (listener) {
      invokeAPI("onWindowResize", {
        success: listener
      });
    }
  }
  const __vite_glob_0_47 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    onWindowResize
  }, Symbol.toStringTag, { value: "Module" }));
  function createIntersectionObserver(component, options = {}) {
    const {
      thresholds = [0],
      // 设定默认值 [0]
      initialRatio = 0,
      // 设定默认值 0
      observeAll = false
      // 设定默认值 false
    } = options;
    return new IntersectionObserver(component, { thresholds, initialRatio, observeAll });
  }
  class IntersectionObserver {
    constructor(component, options) {
      this._component = component;
      this._options = options;
      this._relativeInfo = [];
      this._observerId = null;
      this._disconnected = false;
    }
    /**
     * 使用选择器指定一个节点，作为参照区域之一
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeTo.html
     */
    relativeTo(selector, margins = { left: 0, right: 0, top: 0, bottom: 0 }) {
      if (this._observerId !== null) {
        throw new Error('Relative nodes cannot be added after "observe" call in IntersectionObserver');
      }
      this._relativeInfo.push({
        selector,
        margins: ["left", "right", "top", "bottom"].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
      });
      return this;
    }
    /**
     * 指定页面显示区域作为参照区域之一
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.relativeToViewport.html
     */
    relativeToViewport(margins = { left: 0, right: 0, top: 0, bottom: 0 }) {
      if (this._observerId !== null) {
        throw new Error('Relative nodes cannot be added after "observe" call in IntersectionObserver');
      }
      this._relativeInfo.push({
        selector: null,
        margins: ["left", "right", "top", "bottom"].map((key) => `${margins[key] === void 0 ? 0 : margins[key]}px`).join(" ")
      });
      return this;
    }
    /**
     * 指定目标节点并开始监听相交状态变化情况
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.observe.html
     */
    observe(targetSelector, listener) {
      const self = this;
      const id = callback.store((res) => {
        if (!self._disconnected) {
          self._observerId = res.observerId;
        }
        if (res.info) {
          listener.call(self, res.info);
        }
      }, true);
      invokeAPI("addIntersectionObserver", {
        moduleId: this._component.__id__,
        targetSelector,
        relativeInfo: this._relativeInfo,
        options: this._options,
        success: id
      }, "render");
    }
    /**
     * 停止监听。回调函数将不再触发
     * https://developers.weixin.qq.com/miniprogram/dev/api/wxml/IntersectionObserver.disconnect.html
     */
    disconnect() {
      invokeAPI("removeIntersectionObserver", {
        observerId: this._observerId
      }, "render");
      this._disconnected = true;
    }
  }
  const __vite_glob_0_48 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    createIntersectionObserver
  }, Symbol.toStringTag, { value: "Module" }));
  const apiInfo = /* @__PURE__ */ Object.assign({ "./core/base/app-event/index.js": __vite_glob_0_0, "./core/base/index.js": __vite_glob_0_1, "./core/base/performance/index.js": __vite_glob_0_2, "./core/base/subpackage/index.js": __vite_glob_0_3, "./core/base/system/index.js": __vite_glob_0_4, "./core/base/update/index.js": __vite_glob_0_5, "./core/camera/index.js": __vite_glob_0_6, "./core/data-analysis/index.js": __vite_glob_0_7, "./core/device/bluetooth-ble/index.js": __vite_glob_0_8, "./core/device/bluetooth/index.js": __vite_glob_0_9, "./core/device/clipboard/index.js": __vite_glob_0_10, "./core/device/contact/index.js": __vite_glob_0_11, "./core/device/keyboard/index.js": __vite_glob_0_12, "./core/device/memory/index.js": __vite_glob_0_13, "./core/device/network/index.js": __vite_glob_0_14, "./core/device/phone/index.js": __vite_glob_0_15, "./core/device/scan/index.js": __vite_glob_0_16, "./core/device/vibrate/index.js": __vite_glob_0_17, "./core/ext/index.js": __vite_glob_0_18, "./core/life-cycle/index.js": __vite_glob_0_19, "./core/location/index.js": __vite_glob_0_20, "./core/map/index.js": __vite_glob_0_21, "./core/media/image/index.js": __vite_glob_0_22, "./core/media/video/index.js": __vite_glob_0_23, "./core/navigate/index.js": __vite_glob_0_24, "./core/network/download/index.js": __vite_glob_0_25, "./core/network/request/index.js": __vite_glob_0_26, "./core/network/upload/index.js": __vite_glob_0_27, "./core/open-api/account-info/index.js": __vite_glob_0_28, "./core/open-api/authorize/index.js": __vite_glob_0_29, "./core/open-api/index.js": __vite_glob_0_30, "./core/open-api/login/index.js": __vite_glob_0_31, "./core/open-api/privacy/index.js": __vite_glob_0_32, "./core/open-api/setting/index.js": __vite_glob_0_33, "./core/open-api/user-info/index.js": __vite_glob_0_34, "./core/payment/index.js": __vite_glob_0_35, "./core/route/index.js": __vite_glob_0_36, "./core/share/index.js": __vite_glob_0_37, "./core/storage/index.js": __vite_glob_0_38, "./core/ui/animation/index.js": __vite_glob_0_39, "./core/ui/background/index.js": __vite_glob_0_40, "./core/ui/custom-component/index.js": __vite_glob_0_41, "./core/ui/interaction/index.js": __vite_glob_0_42, "./core/ui/menu/index.js": __vite_glob_0_43, "./core/ui/navigation-bar/index.js": __vite_glob_0_44, "./core/ui/pull-down-refresh/index.js": __vite_glob_0_45, "./core/ui/scroll/index.js": __vite_glob_0_46, "./core/ui/window/index.js": __vite_glob_0_47, "./core/wxml/intersection-observer/index.js": __vite_glob_0_48, "./core/wxml/selector-query/index.js": __vite_glob_0_49 });
  const api = {};
  for (const f of Object.values(apiInfo)) {
    for (const [k, v] of Object.entries(f)) {
      api[k] = v;
    }
  }
  const handler = {
    get(target, prop, receiver) {
      const origMethod = Reflect.get(target, prop, receiver);
      return (...args) => {
        if (typeof origMethod === "function") {
          return origMethod(...args);
        } else {
          return invokeAPI(prop, ...args);
        }
      };
    }
  };
  const globalApi = new Proxy(api, handler);
  class Env {
    constructor() {
      this.init();
    }
    init() {
      globalThis.dd = globalThis.wx = globalApi;
      globalThis.modRequire = modRequire;
      globalThis.modDefine = modDefine;
      globalThis.App = (moduleInfo) => loader.createAppModule(moduleInfo);
      globalThis.Page = (moduleInfo) => {
        loader.createModule(moduleInfo, globalThis.__extraInfo, PageModule.type);
      };
      globalThis.Component = (moduleInfo) => {
        loader.createModule(moduleInfo, globalThis.__extraInfo, ComponentModule.type);
      };
      globalThis.Behavior = (behaviorInfo) => {
        return behaviorInfo;
      };
      globalThis.getApp = () => {
        var _a;
        return (_a = loader.getAppModule()) == null ? void 0 : _a.moduleInfo;
      };
      globalThis.getCurrentPages = () => router.stack();
    }
  }
  const env = new Env();
  const actionMap = { navigateBack, navigateTo, reLaunch, redirectTo, switchTab };
  class Service {
    constructor() {
      console.log("[Service] init");
      this.env = env;
      this.message = message;
      this.init();
    }
    init() {
      this.message.on("loadResource", (msg) => {
        const { appId, bridgeId, pagePath, root = "." } = msg;
        loader.loadResource({ appId, bridgeId, pagePath, root });
      });
      this.message.on("t", async (msg) => {
        const { bridgeId, moduleId, methodName, event, success } = msg;
        if (methodName === void 0) {
          return;
        }
        const data = await runtime.triggerEvent({ bridgeId, moduleId, methodName, event });
        if (data !== void 0) {
          this.message.send({
            type: "triggerCallback",
            target: "render",
            body: {
              bridgeId,
              moduleId,
              success,
              data
            }
          });
        }
      });
      this.message.on("triggerCallback", (msg) => {
        const { id, args } = msg;
        callback.invoke(id, args);
      });
      this.onAppMsg();
      this.onModuleMsg();
    }
    onAppMsg() {
      this.message.on("resourceLoaded", (msg) => {
        const { bridgeId, scene, pagePath, query, stackId } = msg;
        runtime.createApp({ scene, pagePath, query });
        const module = loader.getModuleByPath(pagePath);
        if (!module) {
          console.error(`[Service] resourceLoaded: module not found, pagePath: ${pagePath}`);
          return;
        }
        const initialProps = loader.getPropsByPath(module.usingComponents);
        const pageId = `page_${uuid()}`;
        runtime.createInstance({ bridgeId, moduleId: pageId, path: pagePath, query, stackId });
        message.send({
          type: "firstRender",
          target: "render",
          body: {
            bridgeId,
            pageId,
            pagePath,
            initialProps,
            query
          }
        });
      });
      this.message.on("appShow", () => {
        runtime.appShow();
      });
      this.message.on("appHide", () => {
        runtime.appHide();
      });
      this.message.on("stackShow", ({ stackId }) => {
        runtime.stackShow(stackId);
      });
      this.message.on("stackHide", ({ stackId }) => {
        runtime.stackHide(stackId);
      });
    }
    /**
     * https://developers.weixin.qq.com/miniprogram/dev/framework/app-service/page-life-cycle.html
     * https://developers.weixin.qq.com/miniprogram/dev/framework/custom-component/lifetimes.html
     */
    onModuleMsg() {
      this.message.on("mC", (msg) => {
        runtime.createInstance(msg);
      });
      this.message.on("mR", (msg) => {
        runtime.moduleReady(msg);
      });
      this.message.on("mU", (msg) => {
        runtime.moduleUnmounted(msg);
      });
      this.message.on("pageUnload", (msg) => {
        runtime.pageUnload(msg);
      });
      this.message.on("pageShow", (msg) => {
        runtime.pageShow(msg);
      });
      this.message.on("pageReady", (msg) => {
        runtime.pageReady(msg);
      });
      this.message.on("pageHide", (msg) => {
        runtime.pageHide(msg);
      });
      this.message.on("pagePullDownRefresh", () => {
      });
      this.message.on("pageReachBottom", () => {
      });
      this.message.on("pageShareAppMessage", () => {
      });
      this.message.on("pageScroll", (msg) => {
        runtime.pageScroll(msg);
      });
      this.message.on("pageResize", (msg) => {
        runtime.pageResize(msg);
      });
      this.message.on("onTabItemTap", () => {
      });
      this.message.on("pageRouteDone", (msg) => {
        const { bridgeId } = msg;
        runtime.componentRouteDone({ bridgeId });
      });
      this.message.on("componentError", (msg) => {
        runtime.componentError(msg);
      });
      this.message.on("h5SdkAction", async (msg = {}) => {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i;
        const actionName = (_a = msg == null ? void 0 : msg.name) == null ? void 0 : _a.replace(/h5/i, "");
        const { url } = ((_c = (_b = msg == null ? void 0 : msg.params) == null ? void 0 : _b.data) == null ? void 0 : _c.params) || {};
        msg.params && (msg.params.data = {
          ...(_d = msg.params) == null ? void 0 : _d.data,
          ...((_f = (_e = msg.params) == null ? void 0 : _e.data) == null ? void 0 : _f.params) || {}
        });
        if (actionName === "postMessage" && msg.parentWebViewId) {
          const { moduleId, attrs, params } = msg;
          const event = { detail: { data: [(_h = (_g = params == null ? void 0 : params.data) == null ? void 0 : _g.params) == null ? void 0 : _h.data] } };
          const methodName = attrs.message;
          const parentWebViewId = msg.parentWebViewId;
          const data = await runtime.triggerEvent({ bridgeId: parentWebViewId, moduleId, methodName, event });
          if (data !== void 0) {
            this.message.send({
              type: "triggerCallback",
              target: "service",
              body: {
                bridgeId: parentWebViewId,
                moduleId,
                success: params == null ? void 0 : params.success,
                data
              }
            });
          }
        }
        (_i = actionMap[actionName]) == null ? void 0 : _i.call(actionMap, { url, ...msg.params });
      });
    }
  }
  const index = new Service();
  return index;
}();
